"""Main application entry point for the Alpha voice assistant."""

import sys
import signal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

from PySide6.QtWidgets import QApplication, QMenu, QStyle, QSystemTrayIcon
from PySide6.QtCore import QLockFile, QTimer
from PySide6.QtGui import QAction, QFont

from alpha.config.settings import ConfigManager
from alpha.utils.logger import setup_logger, get_logger
from alpha.utils.sounds import (
    POWER_OFF_DURATION_SECONDS,
    POWER_ON_DURATION_SECONDS,
    play_power_off,
    play_power_on,
)
from alpha.core.assistant import AlphaAssistant
from alpha.system import HotkeyRequestService
from alpha.ui.island_window import AlphaIslandWindow


def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    config_mgr = ConfigManager.instance()
    config = config_mgr.config
    setup_logger(config.log_file, config.log_level)
    log = get_logger("app")
    log.info("Starting %s in compact voice-only mode...", config.personality.name)

    # Prevent two background copies from competing for the microphone.
    instance_lock = QLockFile(str(config.data_dir / "alpha-instance.lock"))
    instance_lock.setStaleLockTime(10_000)
    if not instance_lock.tryLock(100):
        log.warning("%s is already running; leaving the existing instance active", config.personality.name)
        return

    qt_app = QApplication(sys.argv)
    qt_app.setApplicationName(config.personality.name)
    qt_app.setApplicationDisplayName(f"{config.personality.name} AI")
    qt_app.setQuitOnLastWindowClosed(False)
    qt_app.setFont(QFont(config.theme.font_family, 10))

    assistant = AlphaAssistant(config)
    window = AlphaIslandWindow(config)
    hotkey_requests = HotkeyRequestService(config.data_dir)

    # A tray exit is important when Alpha is launched with pythonw at login:
    # the compact Tool window intentionally has no taskbar button or title bar.
    tray = None
    if QSystemTrayIcon.isSystemTrayAvailable():
        tray = QSystemTrayIcon(
            qt_app.style().standardIcon(QStyle.SP_ComputerIcon),
            qt_app,
        )
        tray.setToolTip('Alpha - dormant until exact wake word "Alpha"')
        tray_menu = QMenu()
        stop_action = QAction("Stop current response", tray_menu)
        stop_action.triggered.connect(assistant.cancel_current)
        quit_action = QAction("Quit Alpha", tray_menu)
        tray_menu.addAction(stop_action)
        tray_menu.addSeparator()
        tray_menu.addAction(quit_action)
        tray.setContextMenu(tray_menu)
        tray.show()

    def on_state(state): window.set_state(state)
    def on_audio(level): window.set_audio_level(level)
    def on_transcript(speaker, text): window.add_transcript(speaker, text)
    def on_confirmation(message): window.show_confirmation(message)
    def on_activation(source):
        window.activation_notice(source)

    shutdown_started = False
    activation_pending = False

    def request_activation():
        """Finish the power-on cue before opening command recording."""

        nonlocal activation_pending
        if activation_pending or shutdown_started:
            return
        activation_pending = True
        play_power_on()

        def activate_after_sound():
            nonlocal activation_pending
            activation_pending = False
            assistant.activate()

        QTimer.singleShot(
            int(POWER_ON_DURATION_SECONDS * 1000) + 40,
            activate_after_sound,
        )

    def request_full_quit():
        """Play the shutdown cue completely before ending the process."""

        nonlocal shutdown_started
        if shutdown_started:
            return
        shutdown_started = True
        hotkey_requests.stop()
        assistant.cancel_current()
        play_power_off()
        QTimer.singleShot(
            int(POWER_OFF_DURATION_SECONDS * 1000) + 80,
            qt_app.quit,
        )

    if tray is not None:
        quit_action.triggered.connect(request_full_quit)

    assistant.on_state_change(on_state)
    assistant.on_audio_level(on_audio)
    assistant.on_transcript(on_transcript)
    assistant.on_activation(on_activation)
    assistant.set_confirmation_listener(on_confirmation)
    assistant.set_confirmation_clear_listener(window.clear_confirmation)
    window.cancel_requested.connect(assistant.cancel_current)
    hotkey_requests.activate_requested.connect(request_activation)
    hotkey_requests.quit_requested.connect(request_full_quit)

    dash_timer = QTimer()
    dash_timer.setInterval(2000)
    def refresh():
        data = assistant.dashboard_data()
        window.set_dashboard_data(data)
    dash_timer.timeout.connect(refresh)
    dash_timer.start()
    QTimer.singleShot(500, refresh)

    assistant.start()
    hotkey_requests.start()

    # Ghost mode: stay completely hidden until a wake phrase is recognized.
    QTimer.singleShot(300, window.hide_window)
    log.info("%s is starting silently; waiting for microphone readiness.", config.personality.name)

    exit_code = qt_app.exec()
    hotkey_requests.stop()
    assistant.stop()
    config_mgr.save()
    instance_lock.unlock()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
