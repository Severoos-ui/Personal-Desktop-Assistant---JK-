"""Screen-awareness features for Alpha."""

from alpha.vision.screen import ScreenVision

__all__ = ["ScreenVision"]
