"""Privacy-conscious, voice-triggered screen understanding."""

from __future__ import annotations

import time
import uuid
from pathlib import Path

from alpha.automation.desktop import DesktopController
from alpha.core.llm import LLMClient
from alpha.utils.logger import get_logger


log = get_logger("vision.screen")


class ScreenVision:
    """Capture, analyze, and immediately delete one screen image."""

    def __init__(
        self,
        desktop: DesktopController,
        llm: LLMClient,
        data_dir: str | Path,
    ):
        self.desktop = desktop
        self.llm = llm
        self.cache_dir = Path(data_dir) / "cache"

    def analyze(self) -> str:
        """Describe the active screen and read its important visible text."""

        screenshot_path = self.cache_dir / (
            f"screen_vision_{int(time.time())}_{uuid.uuid4().hex[:8]}.png"
        )
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            self.desktop.capture_screen_image(screenshot_path)
            response = self.llm.analyze_image(
                screenshot_path,
                (
                    "You are Alpha's screen-awareness assistant. Briefly "
                    "identify the active application, describe what is visible, "
                    "and read only the important text needed to help the user. "
                    "Mention obvious warnings or next actions. Do not reproduce "
                    "passwords, API keys, authentication tokens, payment data, "
                    "or other secret-looking values. Keep the answer concise "
                    "and natural for text-to-speech."
                ),
            )
            return response.text
        except Exception as exc:
            log.error(f"Screen capture failed: {exc}")
            return "I couldn't capture the screen right now."
        finally:
            try:
                screenshot_path.unlink(missing_ok=True)
            except Exception as exc:
                log.warning(
                    f"Could not remove temporary screen image: {exc}"
                )
