"""Encrypted SQLite memory store for conversation history, preferences, tasks, reminders."""

import sqlite3
import json
import re
import time
import threading
import hashlib
import secrets
from pathlib import Path
from typing import Any, Dict, List, Optional
from contextlib import contextmanager
from dataclasses import dataclass

from alpha.utils.logger import get_logger, log_mem

log = get_logger("memory")


class MemoryStore:
    """
    Thread-safe, optionally encrypted SQLite store for:
      - conversations (long-term)
      - preferences (key-value)
      - commands_history
      - reminders
      - notes
      - tasks
      - user_profile
    Uses Fernet symmetric encryption if available; otherwise hashed access control.
    """

    SCHEMA_VERSION = 1

    def __init__(self, db_path: str, encrypted: bool = True, key_path: str = ""):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._fernet = None
        self._cipher = None
        self._init_encryption(encrypted, key_path)
        self._init_db()

    def _init_encryption(self, encrypted: bool, key_path: str):
        if not encrypted:
            return
        try:
            from cryptography.fernet import Fernet
            kp = Path(key_path) if key_path else self.db_path.parent / ".secret"
            if kp.exists():
                key = kp.read_bytes()
            else:
                key = Fernet.generate_key()
                kp.write_bytes(key)
                try:
                    import os; os.chmod(str(kp), 0o600)
                except Exception:
                    pass
            self._fernet = Fernet(key)
            log.info("Memory store encryption enabled (Fernet)")
        except ImportError:
            log.info("cryptography not installed; memory stored in plaintext (local DB only)")

    def _encrypt(self, value: str) -> str:
        if self._fernet and value:
            return self._fernet.encrypt(value.encode("utf-8")).decode("utf-8")
        return value

    def _decrypt(self, value: str) -> str:
        if self._fernet and value:
            try:
                return self._fernet.decrypt(value.encode("utf-8")).decode("utf-8")
            except Exception:
                return value
        return value

    @property
    def encryption_enabled(self) -> bool:
        return self._fernet is not None

    @staticmethod
    def _safe_command_text(value: str) -> str:
        """Keep secret-bearing voice commands out of plaintext history."""

        text = str(value or "")
        if re.search(
            r"\b(?:password|passcode|pin|security\s+code|api\s+key|"
            r"auth(?:entication)?\s+token|secret|credit\s+card|cvv)\b",
            text,
            re.IGNORECASE,
        ):
            return "[REDACTED SENSITIVE COMMAND]"
        return text

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(str(self.db_path), timeout=5, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self):
        with self._lock, self._connect() as c:
            c.executescript("""
                CREATE TABLE IF NOT EXISTS schema_meta (
                    key TEXT PRIMARY KEY, value TEXT
                );
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    timestamp REAL NOT NULL,
                    metadata TEXT DEFAULT '{}'
                );
                CREATE INDEX IF NOT EXISTS idx_conv_session ON conversations(session_id);
                CREATE INDEX IF NOT EXISTS idx_conv_ts ON conversations(timestamp);

                CREATE TABLE IF NOT EXISTS preferences (
                    key TEXT PRIMARY KEY,
                    value TEXT,
                    updated_at REAL
                );

                CREATE TABLE IF NOT EXISTS command_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    command_text TEXT NOT NULL,
                    command_name TEXT,
                    success INTEGER DEFAULT 1,
                    response TEXT,
                    timestamp REAL NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_cmd_ts ON command_history(timestamp);

                CREATE TABLE IF NOT EXISTS reminders (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    due_at REAL,
                    created_at REAL,
                    completed INTEGER DEFAULT 0,
                    notes TEXT
                );

                CREATE TABLE IF NOT EXISTS notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT,
                    content TEXT,
                    created_at REAL,
                    updated_at REAL,
                    tags TEXT DEFAULT '[]'
                );

                CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',
                    priority INTEGER DEFAULT 0,
                    due_at REAL,
                    created_at REAL,
                    completed_at REAL,
                    notes TEXT
                );

                CREATE TABLE IF NOT EXISTS user_profile (
                    key TEXT PRIMARY KEY,
                    value TEXT
                );

                CREATE TABLE IF NOT EXISTS learned_phrases (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    phrase TEXT UNIQUE,
                    intent TEXT,
                    count INTEGER DEFAULT 1,
                    last_seen REAL
                );
            """)
            c.execute(
                "INSERT OR IGNORE INTO schema_meta (key, value) VALUES (?, ?)",
                ("version", str(self.SCHEMA_VERSION))
            )
        log.info(f"Memory store initialized at {self.db_path}")

    # ---- Conversations ----

    def add_message(self, session_id: str, role: str, content: str,
                    metadata: Optional[Dict] = None):
        enc_content = self._encrypt(content)
        meta_json = json.dumps(metadata or {})
        with self._lock, self._connect() as c:
            c.execute(
                "INSERT INTO conversations (session_id, role, content, timestamp, metadata) "
                "VALUES (?, ?, ?, ?, ?)",
                (session_id, role, enc_content, time.time(), meta_json)
            )

    def get_conversation(self, session_id: str, limit: int = 50) -> List[Dict]:
        with self._lock, self._connect() as c:
            rows = c.execute(
                "SELECT * FROM conversations WHERE session_id=? ORDER BY timestamp ASC LIMIT ?",
                (session_id, limit)
            ).fetchall()
        return [
            {"role": r["role"], "content": self._decrypt(r["content"]),
             "timestamp": r["timestamp"], "metadata": json.loads(r["metadata"] or "{}")}
            for r in rows
        ]

    def recent_conversations(self, limit: int = 20) -> List[Dict]:
        with self._lock, self._connect() as c:
            rows = c.execute(
                "SELECT session_id, MAX(timestamp) as ts FROM conversations "
                "GROUP BY session_id ORDER BY ts DESC LIMIT ?",
                (limit,)
            ).fetchall()
        return [{"session_id": r["session_id"], "last_time": r["ts"]} for r in rows]

    def search_conversations(self, query: str, limit: int = 20) -> List[Dict]:
        with self._lock, self._connect() as c:
            rows = c.execute(
                "SELECT * FROM conversations ORDER BY timestamp DESC"
            ).fetchall()
        needle = str(query or "").casefold()
        matches = []
        for row in rows:
            content = self._decrypt(row["content"])
            if needle in content.casefold():
                matches.append({
                    "role": row["role"],
                    "content": content,
                    "timestamp": row["timestamp"],
                })
                if len(matches) >= limit:
                    break
        return matches

    def clear_session(self, session_id: str):
        with self._lock, self._connect() as c:
            c.execute("DELETE FROM conversations WHERE session_id=?", (session_id,))

    def prune_old(self, retention_days: int = 90):
        cutoff = time.time() - retention_days * 86400
        with self._lock, self._connect() as c:
            c.execute("DELETE FROM conversations WHERE timestamp < ?", (cutoff,))

    # ---- Preferences (key-value) ----

    def set_pref(self, key: str, value: Any):
        payload = self._encrypt(json.dumps(value))
        with self._lock, self._connect() as c:
            c.execute(
                "INSERT OR REPLACE INTO preferences (key, value, updated_at) VALUES (?, ?, ?)",
                (key, payload, time.time())
            )

    def get_pref(self, key: str, default: Any = None) -> Any:
        with self._lock, self._connect() as c:
            row = c.execute("SELECT value FROM preferences WHERE key=?", (key,)).fetchone()
        if not row:
            return default
        try:
            return json.loads(self._decrypt(row["value"]))
        except Exception:
            return self._decrypt(row["value"])

    def all_prefs(self) -> Dict[str, Any]:
        with self._lock, self._connect() as c:
            rows = c.execute("SELECT key, value FROM preferences").fetchall()
        out = {}
        for r in rows:
            try:
                out[r["key"]] = json.loads(self._decrypt(r["value"]))
            except Exception:
                out[r["key"]] = self._decrypt(r["value"])
        return out

    def delete_pref(self, key: str) -> bool:
        with self._lock, self._connect() as c:
            cur = c.execute("DELETE FROM preferences WHERE key=?", (key,))
            return cur.rowcount > 0

    # ---- Command History ----

    def log_command(self, text: str, name: str = "", success: bool = True, response: str = ""):
        with self._lock, self._connect() as c:
            c.execute(
                "INSERT INTO command_history (command_text, command_name, success, response, timestamp) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    self._safe_command_text(text),
                    name,
                    1 if success else 0,
                    self._safe_command_text(response),
                    time.time(),
                )
            )

    def recent_commands(self, limit: int = 50) -> List[Dict]:
        with self._lock, self._connect() as c:
            rows = c.execute(
                "SELECT * FROM command_history ORDER BY timestamp DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    # ---- Reminders ----

    def add_reminder(self, title: str, due_at: Optional[float] = None, notes: str = "") -> int:
        with self._lock, self._connect() as c:
            cur = c.execute(
                "INSERT INTO reminders (title, due_at, created_at, notes) VALUES (?, ?, ?, ?)",
                (
                    self._encrypt(title),
                    due_at,
                    time.time(),
                    self._encrypt(notes),
                )
            )
            return cur.lastrowid

    def get_due_reminders(self) -> List[Dict]:
        now = time.time()
        with self._lock, self._connect() as c:
            rows = c.execute(
                "SELECT * FROM reminders WHERE completed=0 AND due_at IS NOT NULL AND due_at <= ?",
                (now,)
            ).fetchall()
        return [self._decode_reminder(r) for r in rows]

    def complete_reminder(self, rid: int):
        with self._lock, self._connect() as c:
            c.execute("UPDATE reminders SET completed=1 WHERE id=?", (rid,))

    def list_reminders(self, include_completed: bool = False) -> List[Dict]:
        with self._lock, self._connect() as c:
            if include_completed:
                rows = c.execute("SELECT * FROM reminders ORDER BY due_at ASC").fetchall()
            else:
                rows = c.execute(
                    "SELECT * FROM reminders WHERE completed=0 ORDER BY due_at ASC"
                ).fetchall()
        return [self._decode_reminder(r) for r in rows]

    def _decode_reminder(self, row) -> Dict:
        item = dict(row)
        item["title"] = self._decrypt(item.get("title") or "")
        item["notes"] = self._decrypt(item.get("notes") or "")
        return item

    # ---- Notes ----

    def add_note(self, title: str, content: str, tags: Optional[List[str]] = None) -> int:
        now = time.time()
        with self._lock, self._connect() as c:
            cur = c.execute(
                "INSERT INTO notes (title, content, created_at, updated_at, tags) VALUES (?, ?, ?, ?, ?)",
                (
                    self._encrypt(title),
                    self._encrypt(content),
                    now,
                    now,
                    self._encrypt(json.dumps(tags or [])),
                )
            )
            return cur.lastrowid

    def search_notes(self, query: str, limit: int = 20) -> List[Dict]:
        with self._lock, self._connect() as c:
            rows = c.execute(
                "SELECT * FROM notes ORDER BY updated_at DESC"
            ).fetchall()
        needle = str(query or "").casefold()
        matches = []
        for row in rows:
            item = self._decode_note(row)
            if (
                needle in item["title"].casefold()
                or needle in item["content"].casefold()
            ):
                matches.append(item)
                if len(matches) >= limit:
                    break
        return matches

    def list_notes(self, limit: int = 20) -> List[Dict]:
        with self._lock, self._connect() as c:
            rows = c.execute(
                "SELECT * FROM notes ORDER BY updated_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._decode_note(row) for row in rows]

    def _decode_note(self, row) -> Dict:
        item = dict(row)
        item["title"] = self._decrypt(item.get("title") or "")
        item["content"] = self._decrypt(item.get("content") or "")
        raw_tags = self._decrypt(item.get("tags") or "[]")
        try:
            item["tags"] = json.loads(raw_tags)
        except Exception:
            item["tags"] = []
        return item

    # ---- Tasks ----

    def add_task(
        self,
        title: str,
        priority: int = 0,
        due_at: Optional[float] = None,
        notes: str = "",
    ) -> int:
        with self._lock, self._connect() as c:
            cur = c.execute(
                "INSERT INTO tasks "
                "(title, priority, due_at, created_at, notes) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    self._encrypt(title),
                    priority,
                    due_at,
                    time.time(),
                    self._encrypt(notes),
                )
            )
            return cur.lastrowid

    def complete_task(self, tid: int):
        with self._lock, self._connect() as c:
            c.execute("UPDATE tasks SET status='done', completed_at=? WHERE id=?",
                      (time.time(), tid))

    def list_tasks(self, status: str = "pending") -> List[Dict]:
        with self._lock, self._connect() as c:
            rows = c.execute(
                "SELECT * FROM tasks WHERE status=? ORDER BY priority DESC, due_at ASC",
                (status,)
            ).fetchall()
        return [self._decode_task(r) for r in rows]

    def _decode_task(self, row) -> Dict:
        item = dict(row)
        item["title"] = self._decrypt(item.get("title") or "")
        item["notes"] = self._decrypt(item.get("notes") or "")
        return item

    # ---- User Profile ----

    def set_profile(self, key: str, value: str):
        with self._lock, self._connect() as c:
            c.execute("INSERT OR REPLACE INTO user_profile (key, value) VALUES (?, ?)",
                      (key, self._encrypt(value)))

    def get_profile(self, key: str) -> Optional[str]:
        with self._lock, self._connect() as c:
            row = c.execute("SELECT value FROM user_profile WHERE key=?", (key,)).fetchone()
        return self._decrypt(row["value"]) if row else None

    # ---- Learned Phrases ----

    def learn_phrase(self, phrase: str, intent: str):
        with self._lock, self._connect() as c:
            existing = c.execute(
                "SELECT id, count FROM learned_phrases WHERE phrase=?", (phrase.lower(),)
            ).fetchone()
            if existing:
                c.execute("UPDATE learned_phrases SET count=count+1, intent=?, last_seen=? WHERE id=?",
                          (intent, time.time(), existing["id"]))
            else:
                c.execute(
                    "INSERT INTO learned_phrases (phrase, intent, last_seen) VALUES (?, ?, ?)",
                    (phrase.lower(), intent, time.time())
                )
