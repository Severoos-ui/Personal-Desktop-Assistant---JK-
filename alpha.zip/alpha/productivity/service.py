"""Local reminders, timers, tasks, notes, and user preferences."""

from __future__ import annotations

import re
import threading
import time
from datetime import datetime, timedelta
from typing import Callable, Optional

from alpha.memory.store import MemoryStore
from alpha.utils.logger import get_logger
from alpha.utils.local_time import nepal_from_timestamp, nepal_now

log = get_logger("productivity")


class ProductivityService:
    """Voice-friendly productivity layer backed by Alpha's local database."""

    _SENSITIVE = re.compile(
        r"\b(?:password|passcode|pin|security\s+code|api\s+key|"
        r"auth(?:entication)?\s+token|secret|credit\s+card|cvv)\b",
        re.IGNORECASE,
    )
    _PRIORITIES = {
        "low": 1,
        "normal": 2,
        "medium": 2,
        "high": 3,
        "urgent": 4,
    }

    def __init__(
        self,
        memory: MemoryStore,
        due_callback: Optional[Callable[[dict], bool]] = None,
        poll_interval: float = 5.0,
    ):
        self.memory = memory
        self._due_callback = due_callback
        self._poll_interval = max(1.0, float(poll_interval))
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._deferred_until: dict[int, float] = {}

    def set_due_callback(self, callback: Callable[[dict], bool]) -> None:
        self._due_callback = callback

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            daemon=True,
            name="alpha-reminders",
        )
        self._thread.start()
        log.info("Local reminder scheduler started")

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)
        self._thread = None

    def _run(self) -> None:
        while not self._stop_event.wait(self._poll_interval):
            self._check_due_reminders()

    def _check_due_reminders(self) -> int:
        delivered = 0
        callback = self._due_callback
        if callback is None:
            return delivered
        now = time.time()
        for reminder in self.memory.get_due_reminders():
            reminder_id = int(reminder["id"])
            if now < self._deferred_until.get(reminder_id, 0.0):
                continue
            try:
                accepted = bool(callback(reminder))
            except Exception as exc:
                log.error("Reminder callback failed: %s", exc)
                accepted = False
            if accepted:
                self.memory.complete_reminder(reminder_id)
                self._deferred_until.pop(reminder_id, None)
                delivered += 1
            else:
                self._deferred_until[reminder_id] = now + 15.0
        return delivered

    @staticmethod
    def reminder_message(reminder: dict) -> str:
        if str(reminder.get("notes") or "").casefold() == "timer":
            return "Your timer is finished."
        return f"Reminder: {reminder.get('title', 'Your reminder')}."

    # ---- Time parsing ----

    @classmethod
    def parse_when(
        cls,
        phrase: str,
        now: Optional[float] = None,
    ) -> Optional[float]:
        """Parse common local reminder phrases without an online service."""

        base = nepal_from_timestamp(
            now if now is not None else time.time()
        )
        text = " ".join(str(phrase or "").casefold().strip().split())
        text = re.sub(r"^(?:for\s+)?", "", text)

        relative = re.fullmatch(
            r"in\s+(?P<count>\d+|a|an|one|two|three|four|five|six|"
            r"seven|eight|nine|ten|fifteen|twenty|thirty)\s+"
            r"(?P<unit>seconds?|minutes?|hours?|days?)",
            text,
        )
        if relative:
            count = cls._number(relative.group("count"))
            unit = relative.group("unit")
            seconds = count
            if unit.startswith("minute"):
                seconds *= 60
            elif unit.startswith("hour"):
                seconds *= 3600
            elif unit.startswith("day"):
                seconds *= 86400
            return (base + timedelta(seconds=seconds)).timestamp()

        day_offset = 0
        if text.startswith("tomorrow"):
            day_offset = 1
            text = text[len("tomorrow"):].strip()
        elif text.startswith("today"):
            text = text[len("today"):].strip()

        clock_match = re.fullmatch(
            r"(?:at\s+)?(?P<hour>\d{1,2})"
            r"(?::(?P<minute>\d{2}))?\s*(?P<period>a\.?m\.?|p\.?m\.?)?",
            text,
        )
        if clock_match:
            hour = int(clock_match.group("hour"))
            minute = int(clock_match.group("minute") or 0)
            period = (clock_match.group("period") or "").replace(".", "")
            if minute > 59 or hour > 23 or (period and not 1 <= hour <= 12):
                return None
            if period == "pm" and hour != 12:
                hour += 12
            elif period == "am" and hour == 12:
                hour = 0
            target = (base + timedelta(days=day_offset)).replace(
                hour=hour,
                minute=minute,
                second=0,
                microsecond=0,
            )
            if day_offset == 0 and target <= base:
                target += timedelta(days=1)
            return target.timestamp()

        return None

    @staticmethod
    def _number(value: str) -> int:
        words = {
            "a": 1,
            "an": 1,
            "one": 1,
            "two": 2,
            "three": 3,
            "four": 4,
            "five": 5,
            "six": 6,
            "seven": 7,
            "eight": 8,
            "nine": 9,
            "ten": 10,
            "fifteen": 15,
            "twenty": 20,
            "thirty": 30,
        }
        return words.get(value, int(value) if value.isdigit() else 1)

    @staticmethod
    def _format_due(timestamp: Optional[float]) -> str:
        if timestamp is None:
            return "without a notification time"
        due = nepal_from_timestamp(timestamp)
        today = nepal_now().date()
        if due.date() == today:
            day = "today"
        elif due.date() == today + timedelta(days=1):
            day = "tomorrow"
        else:
            day = due.strftime("%A, %B %d")
        return f"{day} at {due.strftime('%I:%M %p').lstrip('0')}"

    # ---- Reminders and timers ----

    def add_reminder(self, title: str, when: str) -> str:
        clean_title = self._clean(title)
        if not clean_title:
            return "Tell me what you want to be reminded about."
        if self._contains_sensitive(clean_title):
            return "I won't store secrets in a spoken reminder."
        due_at = self.parse_when(when)
        if due_at is None:
            return (
                "I couldn't understand the reminder time. Try in ten "
                "minutes, tomorrow at nine A M, or at five P M."
            )
        self.memory.add_reminder(clean_title, due_at=due_at)
        return (
            f"Reminder set for {self._format_due(due_at)}: "
            f"{clean_title}."
        )

    def add_timer(self, duration: str) -> str:
        due_at = self.parse_when(f"in {duration.strip()}")
        if due_at is None:
            return "Try saying set a timer for ten minutes."
        self.memory.add_reminder("Timer", due_at=due_at, notes="timer")
        return f"Timer set for {duration.strip()}."

    def list_reminders(self) -> str:
        reminders = self.memory.list_reminders()
        if not reminders:
            return "You have no active reminders."
        lines = [
            f"{index + 1}, {item['title']}, "
            f"{self._format_due(item.get('due_at'))}"
            for index, item in enumerate(reminders[:5])
        ]
        prefix = f"You have {len(reminders)} active reminder"
        if len(reminders) != 1:
            prefix += "s"
        return prefix + ". " + "; ".join(lines) + "."

    def complete_reminder(self, target: str) -> str:
        reminder = self._find_item(
            self.memory.list_reminders(),
            target,
        )
        if reminder is None:
            return f"I couldn't find an active reminder matching {target}."
        self.memory.complete_reminder(int(reminder["id"]))
        return f"Completed reminder: {reminder['title']}."

    # ---- Tasks ----

    def add_task(self, title: str, priority: str = "normal") -> str:
        clean_title = self._clean(title)
        if not clean_title:
            return "Tell me what task to add."
        if self._contains_sensitive(clean_title):
            return "I won't store secrets in a spoken task."
        priority_name = str(priority or "normal").casefold().strip()
        priority_value = self._PRIORITIES.get(priority_name, 2)
        self.memory.add_task(clean_title, priority=priority_value)
        return f"Added {clean_title} to your {priority_name} priority tasks."

    def list_tasks(self) -> str:
        tasks = self.memory.list_tasks("pending")
        if not tasks:
            return "Your task list is clear."
        lines = [
            f"{index + 1}, {task['title']}"
            for index, task in enumerate(tasks[:7])
        ]
        return (
            f"You have {len(tasks)} pending task"
            f"{'' if len(tasks) == 1 else 's'}. "
            + "; ".join(lines)
            + "."
        )

    def complete_task(self, target: str) -> str:
        task = self._find_item(self.memory.list_tasks("pending"), target)
        if task is None:
            return f"I couldn't find a pending task matching {target}."
        self.memory.complete_task(int(task["id"]))
        return f"Completed task: {task['title']}."

    # ---- Notes ----

    def add_note(self, content: str) -> str:
        clean_content = self._clean(content)
        if not clean_content:
            return "Tell me what you want the note to say."
        if self._contains_sensitive(clean_content):
            return "I won't store secrets from a spoken note."
        words = clean_content.split()
        title = " ".join(words[:6])
        if len(words) > 6:
            title += "..."
        self.memory.add_note(title, clean_content)
        return f"Saved your note: {title}."

    def search_notes(self, query: str) -> str:
        clean_query = self._clean(query)
        notes = self.memory.search_notes(clean_query, limit=5)
        if not notes:
            return f"I couldn't find a note about {clean_query}."
        snippets = [
            f"{index + 1}, {note['content']}"
            for index, note in enumerate(notes)
        ]
        return "I found: " + "; ".join(snippets) + "."

    def list_notes(self) -> str:
        notes = self.memory.list_notes(limit=5)
        if not notes:
            return "You have no saved notes."
        return "Your recent notes are: " + "; ".join(
            f"{index + 1}, {note['title']}"
            for index, note in enumerate(notes)
        ) + "."

    # ---- Preferences ----

    def remember_preference(self, key: str, value: str) -> str:
        clean_key = self._clean(key).casefold()
        clean_value = self._clean(value)
        if not clean_key or not clean_value:
            return "Tell me the preference you want me to remember."
        if self._contains_sensitive(f"{clean_key} {clean_value}"):
            return "I won't store passwords, codes, API keys, or other secrets."
        self.memory.set_pref(clean_key, clean_value)
        return f"I'll remember that your {clean_key} is {clean_value}."

    def recall_preference(self, key: str) -> str:
        clean_key = self._clean(key).casefold()
        value = self.memory.get_pref(clean_key)
        if value is None:
            return f"I don't have a saved preference for {clean_key}."
        return f"Your {clean_key} is {value}."

    def forget_preference(self, key: str) -> str:
        clean_key = self._clean(key).casefold()
        if self.memory.delete_pref(clean_key):
            return f"I forgot your saved {clean_key}."
        return f"I didn't have a saved preference for {clean_key}."

    def daily_briefing(self) -> str:
        tasks = self.memory.list_tasks("pending")
        reminders = self.memory.list_reminders()
        due_today = [
            item
            for item in reminders
            if item.get("due_at")
            and nepal_from_timestamp(item["due_at"]).date()
            <= nepal_now().date()
        ]
        return (
            f"Good {self._day_period()}. You have {len(tasks)} pending "
            f"task{'' if len(tasks) == 1 else 's'}, {len(reminders)} active "
            f"reminder{'' if len(reminders) == 1 else 's'}, and "
            f"{len(due_today)} reminder"
            f"{'' if len(due_today) == 1 else 's'} due today."
        )

    @staticmethod
    def _day_period() -> str:
        hour = nepal_now().hour
        if hour < 12:
            return "morning"
        if hour < 18:
            return "afternoon"
        return "evening"

    @classmethod
    def _contains_sensitive(cls, value: str) -> bool:
        return bool(cls._SENSITIVE.search(str(value or "")))

    @staticmethod
    def _clean(value: str) -> str:
        return " ".join(str(value or "").strip().strip(" .,!?:;").split())

    @staticmethod
    def _find_item(items: list[dict], target: str) -> Optional[dict]:
        clean_target = " ".join(
            str(target or "").casefold().strip(" .,!?:;").split()
        )
        if clean_target.isdigit():
            wanted_id = int(clean_target)
            for item in items:
                if int(item["id"]) == wanted_id:
                    return item
            # Spoken list numbers usually refer to the displayed position.
            if 1 <= wanted_id <= len(items):
                return items[wanted_id - 1]
        for item in items:
            title = str(item.get("title") or "").casefold()
            if clean_target == title or clean_target in title:
                return item
        return None
