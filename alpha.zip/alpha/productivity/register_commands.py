"""Voice command registration for Alpha's local productivity service."""

from alpha.commands.registry import (
    CommandDef,
    CommandRegistry,
    ParamDef,
    ParamType,
)
from alpha.productivity.service import ProductivityService


def register_productivity_commands(
    registry: CommandRegistry,
    productivity: ProductivityService,
) -> None:
    duration = (
        r"\d+\s+(?:seconds?|minutes?|hours?)|"
        r"(?:a|an|one|two|three|four|five|six|seven|eight|nine|ten|"
        r"fifteen|twenty|thirty)\s+(?:seconds?|minutes?|hours?)"
    )
    when = (
        rf"in\s+(?:{duration})|"
        r"(?:today|tomorrow)(?:\s+at\s+\d{1,2}(?::\d{2})?"
        r"\s*(?:a\.?m\.?|p\.?m\.?)?)?|"
        r"at\s+\d{1,2}(?::\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)?"
    )

    registry.register(CommandDef(
        name="add_reminder",
        handler=lambda title, when: productivity.add_reminder(title, when),
        description="create a persistent local reminder",
        category="productivity",
        triggers=["remind me to", "set a reminder"],
        params=[
            ParamDef("title", ParamType.STRING, required=True),
            ParamDef("when", ParamType.STRING, required=True),
        ],
        patterns=[
            rf"remind\s+me\s+to\s+(?P<title>.+?)\s+(?P<when>{when})\s*$",
            rf"remind\s+me\s+(?P<when>{when})\s+to\s+(?P<title>.+?)\s*$",
            rf"set\s+(?:a\s+)?reminder\s+(?:to|for)\s+"
            rf"(?P<title>.+?)\s+(?P<when>{when})\s*$",
        ],
        examples=[
            "Alpha, remind me to submit the report in thirty minutes",
            "Alpha, remind me tomorrow at 9 AM to study",
        ],
    ))

    registry.register(CommandDef(
        name="set_timer",
        handler=lambda duration: productivity.add_timer(duration),
        description="set a local timer",
        category="productivity",
        triggers=["set a timer", "start a timer"],
        params=[ParamDef("duration", ParamType.STRING, required=True)],
        patterns=[
            rf"(?:set|start)\s+(?:a\s+)?timer(?:\s+for)?\s+"
            rf"(?P<duration>{duration})\s*$",
        ],
        examples=["Alpha, set a timer for ten minutes"],
    ))

    registry.register(CommandDef(
        name="list_reminders",
        handler=productivity.list_reminders,
        description="list active reminders",
        category="productivity",
        triggers=[
            "list my reminders",
            "what are my reminders",
            "show my reminders",
        ],
        examples=["Alpha, what are my reminders"],
    ))

    registry.register(CommandDef(
        name="complete_reminder",
        handler=lambda target: productivity.complete_reminder(target),
        description="complete or dismiss a reminder",
        category="productivity",
        triggers=["complete reminder", "dismiss reminder"],
        params=[ParamDef("target", ParamType.STRING, required=True)],
        patterns=[
            r"(?:complete|dismiss|remove)\s+(?:the\s+)?reminder\s+"
            r"(?P<target>.+?)\s*$",
        ],
    ))

    registry.register(CommandDef(
        name="add_task",
        handler=lambda title, priority="normal": productivity.add_task(
            title,
            priority,
        ),
        description="add a persistent task",
        category="productivity",
        triggers=["add task", "create task", "add to my task list"],
        params=[
            ParamDef("title", ParamType.STRING, required=True),
            ParamDef("priority", ParamType.STRING, default="normal"),
        ],
        patterns=[
            r"(?:add|create)\s+(?:a\s+)?task\s+(?P<title>.+?)"
            r"(?:\s+(?:with\s+)?(?P<priority>"
            r"low|normal|medium|high|urgent)\s+priority)?\s*$",
            r"add\s+(?P<title>.+?)\s+to\s+(?:my\s+)?task\s+list\s*$",
        ],
        examples=["Alpha, add task finish the report with high priority"],
    ))

    registry.register(CommandDef(
        name="list_tasks",
        handler=productivity.list_tasks,
        description="list pending tasks",
        category="productivity",
        triggers=[
            "list my tasks",
            "show my tasks",
            "what are my tasks",
            "what is on my task list",
        ],
        examples=["Alpha, what are my tasks"],
    ))

    registry.register(CommandDef(
        name="complete_task",
        handler=lambda target: productivity.complete_task(target),
        description="complete a pending task",
        category="productivity",
        triggers=["complete task", "finish task", "mark task done"],
        params=[ParamDef("target", ParamType.STRING, required=True)],
        patterns=[
            r"(?:complete|finish)\s+(?:the\s+)?task\s+"
            r"(?P<target>.+?)\s*$",
            r"mark\s+(?:the\s+)?task\s+(?P<target>.+?)\s+"
            r"(?:as\s+)?done\s*$",
        ],
    ))

    registry.register(CommandDef(
        name="add_note",
        handler=lambda content: productivity.add_note(content),
        description="save a private local note",
        category="productivity",
        triggers=["take a note", "save a note", "note that"],
        params=[ParamDef("content", ParamType.STRING, required=True)],
        patterns=[
            r"(?:take|save|create)\s+(?:a\s+)?note"
            r"(?:\s+(?:that|saying))?\s+(?P<content>.+?)\s*$",
            r"note\s+that\s+(?P<content>.+?)\s*$",
        ],
        examples=["Alpha, take a note that the project demo is Friday"],
    ))

    registry.register(CommandDef(
        name="search_notes",
        handler=lambda query: productivity.search_notes(query),
        description="search saved notes by content",
        category="productivity",
        triggers=["search my notes", "find a note", "find notes"],
        params=[ParamDef("query", ParamType.QUERY, required=True)],
        patterns=[
            r"(?:search|find)\s+(?:a\s+)?(?:my\s+)?notes?"
            r"(?:\s+for|\s+about)?\s+(?P<query>.+?)\s*$",
            r"what\s+did\s+i\s+note\s+about\s+(?P<query>.+?)\s*$",
        ],
    ))

    registry.register(CommandDef(
        name="list_notes",
        handler=productivity.list_notes,
        description="list recent notes",
        category="productivity",
        triggers=["list my notes", "show my notes", "recent notes"],
    ))

    registry.register(CommandDef(
        name="remember_preference",
        handler=lambda key, value: productivity.remember_preference(
            key,
            value,
        ),
        description="remember a non-secret user preference",
        category="memory",
        triggers=["remember that my", "remember my preference"],
        params=[
            ParamDef("key", ParamType.STRING, required=True),
            ParamDef("value", ParamType.STRING, required=True),
        ],
        patterns=[
            r"remember\s+(?:that\s+)?my\s+(?P<key>.+?)\s+is\s+"
            r"(?P<value>.+?)\s*$",
        ],
        examples=["Alpha, remember that my favorite browser is Brave"],
    ))

    registry.register(CommandDef(
        name="recall_preference",
        handler=lambda key: productivity.recall_preference(key),
        description="recall a saved user preference",
        category="memory",
        triggers=["what do you remember about my", "do you remember my"],
        params=[ParamDef("key", ParamType.STRING, required=True)],
        patterns=[
            r"(?:what\s+do\s+you\s+remember\s+about|"
            r"do\s+you\s+remember)\s+my\s+(?P<key>.+?)\s*$",
        ],
    ))

    registry.register(CommandDef(
        name="forget_preference",
        handler=lambda key: productivity.forget_preference(key),
        description="forget a saved user preference",
        category="memory",
        triggers=["forget my"],
        params=[ParamDef("key", ParamType.STRING, required=True)],
        patterns=[
            r"forget\s+(?:that\s+)?my\s+(?P<key>.+?)\s*$",
        ],
    ))

    registry.register(CommandDef(
        name="daily_briefing",
        handler=productivity.daily_briefing,
        description="give a local task and reminder briefing",
        category="productivity",
        triggers=[
            "daily briefing",
            "morning briefing",
            "give me my briefing",
        ],
    ))
