"""Ambient microphone ownership and optional custom wake-model support."""

import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, List, Optional

import numpy as np

from alpha.utils.logger import get_logger, log_voice
from alpha import WAKE_PHRASE

log = get_logger("wakeword")


@dataclass
class WakeWordMatch:
    phrase: str
    confidence: float
    timestamp: float
    audio_chunk: Optional[np.ndarray] = None


class WakeWordDetector:
    """Own Alpha's single always-on ambient microphone stream.

    Frames are supplied to the voice engine for local ``Alpha`` wake-word
    spotting. The stream is paused before command capture or TTS so multiple
    Windows microphone consumers never compete.
    """

    def __init__(
        self,
        model_path: Optional[str] = None,
        threshold: float = 0.5,
        sample_rate: int = 16000,
        frame_size: int = 1280,
        input_device=None,
        cooldown_sec: float = 1.5,
        performance=None,
    ):
        self.sample_rate = sample_rate
        self.frame_size = frame_size
        self.input_device = input_device
        self.threshold = threshold
        self.cooldown_sec = cooldown_sec
        self.performance = performance

        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._pause = threading.Event()
        self._paused_ack = threading.Event()
        self._listening = False
        self._last_detect = 0.0
        self._callbacks: List[Callable[[WakeWordMatch], None]] = []
        self._frame_callbacks: List[Callable[[np.ndarray, float], None]] = []

        self._model = None
        self._audio_stream = None
        self._audio_backend: Optional[str] = None
        self._pa = None
        self._audio_available = False
        self._last_audio_error = ""
        self._last_logged_audio_error = ""
        self._next_audio_retry = 0.0
        self._init_engine(model_path)

    def _init_engine(self, model_path: Optional[str]):
        if not model_path or not Path(str(model_path)).is_file():
            log.info(f'Using local always-on STT phrase spotting for "{WAKE_PHRASE}"')
            return
        try:
            from openwakeword.model import Model

            path = Path(str(model_path))
            framework = "onnx" if path.suffix.lower() == ".onnx" else "tflite"
            self._model = Model(
                wakeword_models=[str(path)],
                inference_framework=framework,
            )
            log.info(f'Custom "{WAKE_PHRASE}" wake model loaded: {path.name}')
        except Exception as exc:
            self._model = None
            log.warning(f"Custom wake-word model unavailable: {exc}")

    # ---- Subscriptions ----

    def on_detected(self, callback: Callable[[WakeWordMatch], None]):
        self._callbacks.append(callback)

    def on_audio_frame(self, callback: Callable[[np.ndarray, float], None]):
        self._frame_callbacks.append(callback)

    # ---- Lifecycle / stream ownership ----

    def start(self):
        if self._listening:
            return
        self._stop.clear()
        self._pause.clear()
        self._paused_ack.clear()
        self._listening = True
        self._thread = threading.Thread(
            target=self._listen_loop,
            daemon=True,
            name="wake-monitor",
        )
        self._thread.start()
        log_voice(f'Always-on ambient monitor started for "{WAKE_PHRASE}"')

    def stop(self):
        self._stop.set()
        self._pause.clear()
        if self._thread:
            self._thread.join(timeout=2.0)
        self._close_audio()
        self._listening = False
        self._paused_ack.clear()
        log_voice("Ambient voice monitor stopped")

    def pause(self, timeout: float = 1.5) -> bool:
        if not self._listening:
            return True
        self._pause.set()
        return self._paused_ack.wait(timeout=max(0.0, timeout))

    def resume(self):
        self._pause.clear()

    @property
    def listening(self) -> bool:
        return self._listening

    @property
    def audio_available(self) -> bool:
        return self._audio_available

    @property
    def last_audio_error(self) -> str:
        return self._last_audio_error

    def _open_audio(self) -> bool:
        if self._audio_stream is not None:
            return True

        started = time.perf_counter()
        errors = []
        try:
            import sounddevice as sd

            stream = sd.InputStream(
                device=self.input_device,
                channels=1,
                samplerate=self.sample_rate,
                blocksize=self.frame_size,
                dtype="int16",
            )
            stream.start()
            self._audio_stream = stream
            self._audio_backend = "sounddevice"
            self._audio_available = True
            self._last_audio_error = ""
            log.info(
                "Ambient microphone ready via sounddevice"
                + (
                    f" (device={self.input_device})"
                    if self.input_device is not None
                    else " (Windows default input)"
                )
            )
            if self.performance is not None:
                self.performance.record(
                    "microphone_open",
                    (time.perf_counter() - started) * 1000,
                    True,
                    "sounddevice",
                )
            return True
        except Exception as exc:
            errors.append(f"sounddevice: {exc}")

        try:
            import pyaudio

            pa = pyaudio.PyAudio()
            open_args = dict(
                format=pyaudio.paInt16,
                channels=1,
                rate=self.sample_rate,
                input=True,
                frames_per_buffer=self.frame_size,
            )
            input_index = self._pyaudio_input_index(pa)
            if input_index is not None:
                open_args["input_device_index"] = input_index
            stream = pa.open(**open_args)
            self._pa = pa
            self._audio_stream = stream
            self._audio_backend = "pyaudio"
            self._audio_available = True
            self._last_audio_error = ""
            log.info(
                "Ambient microphone ready via pyaudio"
                + (
                    f" (device={input_index})"
                    if input_index is not None
                    else " (Windows default input)"
                )
            )
            if self.performance is not None:
                self.performance.record(
                    "microphone_open",
                    (time.perf_counter() - started) * 1000,
                    True,
                    "pyaudio",
                )
            return True
        except Exception as exc:
            errors.append(f"pyaudio: {exc}")
            if self._pa is not None:
                try:
                    self._pa.terminate()
                except Exception:
                    pass
                self._pa = None

        self._audio_available = False
        self._last_audio_error = "; ".join(errors)
        message = (
            f"No microphone backend available ({self._last_audio_error}); "
            "ambient activation will retry"
        )
        if self._last_audio_error != self._last_logged_audio_error:
            log.warning(message)
            self._last_logged_audio_error = self._last_audio_error
        else:
            log.debug(message)
        if self.performance is not None:
            self.performance.record(
                "microphone_open",
                (time.perf_counter() - started) * 1000,
                False,
                "no backend",
            )
        return False

    def _pyaudio_input_index(self, pa) -> Optional[int]:
        if self.input_device is None:
            return None
        if isinstance(self.input_device, int):
            return self.input_device
        text = str(self.input_device).strip()
        if text.isdigit():
            return int(text)
        needle = text.casefold()
        for index in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(index)
            if (
                int(info.get("maxInputChannels", 0)) > 0
                and needle in str(info.get("name", "")).casefold()
            ):
                return index
        raise ValueError(f"Microphone device not found: {self.input_device}")

    def _close_audio(self):
        stream = self._audio_stream
        self._audio_stream = None
        self._audio_backend = None
        if stream is not None:
            try:
                if hasattr(stream, "stop"):
                    stream.stop()
            except Exception:
                pass
            try:
                if hasattr(stream, "close"):
                    stream.close()
            except Exception:
                pass
        if self._pa is not None:
            try:
                self._pa.terminate()
            except Exception:
                pass
            self._pa = None
        self._audio_available = False

    def _read_frame(self) -> Optional[np.ndarray]:
        stream = self._audio_stream
        if stream is None:
            return None
        try:
            if self._audio_backend == "pyaudio":
                data = stream.read(self.frame_size, exception_on_overflow=False)
                return np.frombuffer(data, dtype=np.int16).copy()
            frame, _overflowed = stream.read(self.frame_size)
            return frame.reshape(-1).astype(np.int16, copy=True)
        except Exception as exc:
            self._last_audio_error = str(exc)
            log.warning(f"Ambient microphone read failed: {exc}")
            return None

    # ---- Detection loop ----

    def _listen_loop(self):
        try:
            while not self._stop.is_set():
                if self._pause.is_set():
                    self._close_audio()
                    self._paused_ack.set()
                    while self._pause.is_set() and not self._stop.wait(0.05):
                        pass
                    self._paused_ack.clear()
                    continue

                if self._audio_stream is None:
                    now = time.monotonic()
                    if now < self._next_audio_retry:
                        self._stop.wait(min(0.20, self._next_audio_retry - now))
                        continue
                    if not self._open_audio():
                        self._next_audio_retry = time.monotonic() + 2.0
                        self._stop.wait(0.20)
                        continue

                frame = self._read_frame()
                if frame is None:
                    self._close_audio()
                    self._next_audio_retry = time.monotonic() + 1.0
                    continue

                now = time.monotonic()
                for callback in tuple(self._frame_callbacks):
                    try:
                        callback(frame, now)
                    except Exception as exc:
                        log.error(f"Audio-frame callback error: {exc}")

                # Optional custom model path only. Keep int16 PCM because
                # OpenWakeWord rejects normalized float input.
                if self._model is not None:
                    try:
                        prediction = self._model.predict(frame)
                        best_conf = 0.0
                        for scores in prediction.values():
                            if hasattr(scores, "__len__"):
                                confidence = (
                                    float(np.max(scores)) if len(scores) else 0.0
                                )
                            else:
                                confidence = float(scores)
                            best_conf = max(best_conf, confidence)
                        if (
                            best_conf >= self.threshold
                            and now - self._last_detect > self.cooldown_sec
                        ):
                            self._last_detect = now
                            match = WakeWordMatch(
                                phrase=WAKE_PHRASE,
                                confidence=best_conf,
                                timestamp=time.time(),
                                audio_chunk=frame,
                            )
                            for callback in tuple(self._callbacks):
                                try:
                                    callback(match)
                                except Exception as exc:
                                    log.error(f"Wakeword callback error: {exc}")
                            self._model.reset()
                    except Exception as exc:
                        log.debug(f"Custom wake model frame rejected: {exc}")
        finally:
            self._close_audio()
            self._paused_ack.set()
            self._listening = False
            log.debug("Ambient monitor loop exiting")

    def trigger_mock(self):
        match = WakeWordMatch(
            phrase=WAKE_PHRASE,
            confidence=1.0,
            timestamp=time.time(),
        )
        for callback in tuple(self._callbacks):
            try:
                callback(match)
            except Exception as exc:
                log.error(f"Mock trigger callback error: {exc}")
