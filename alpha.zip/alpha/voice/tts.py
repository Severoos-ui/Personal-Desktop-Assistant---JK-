"""Offline text-to-speech using Piper TTS with cross-platform audio playback."""

import threading
import queue
import time
import struct
import wave
import tempfile
import os
import re
from pathlib import Path
from typing import Optional, Callable, List, IO

from alpha.utils.logger import get_logger, log_voice
from alpha.language import (
    UNSUPPORTED_LANGUAGE_MESSAGE,
    contains_unsupported_script,
)

log = get_logger("tts")
_STREAM_END = object()


class TextToSpeech:
    """
    Offline neural TTS using Piper (fast, high quality, ONNX runtime).
    Falls back to pyttsx3 (system TTS), then to a silent mock for sandbox/dev.
    """

    def __init__(
        self,
        voice_model: str = "en_US-amy-medium",
        rate: float = 1.0,
        volume: float = 1.0,
        data_dir: Optional[Path] = None,
        online_nepali: bool = True,
        nepali_voice: str = "ne-NP-SagarNeural",
        performance=None,
    ):
        self.voice_model = voice_model
        self.rate = rate
        self.volume = volume
        self.data_dir = data_dir or (Path.home() / ".config" / "alpha" / "models")
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.piper = None
        self._pyttsx = None
        self._pyttsx_owner_thread_id = None
        self.engine_type = None
        self._play_queue: queue.Queue = queue.Queue()
        self._play_thread: Optional[threading.Thread] = None
        self._interrupt_event = threading.Event()
        self._shutdown_event = threading.Event()
        self._stream_open = threading.Event()
        self._is_speaking = threading.Event()
        self._speech_idle = threading.Event()
        self._speech_idle.set()
        self._on_start: List[Callable] = []
        self._on_end: List[Callable] = []
        self._on_audio_chunk: List[Callable[[bytes], None]] = []
        self._default_voice_id = None
        self._nepali_voice_id = None
        self._warned_missing_nepali_voice = False
        self._online_nepali = bool(online_nepali)
        self._nepali_voice = str(nepali_voice)
        self._edge_tts_available = False
        self._active_mci_alias = ""
        self.performance = performance
        if self._online_nepali:
            try:
                import edge_tts  # noqa: F401

                self._edge_tts_available = True
            except ImportError:
                log.warning(
                    "Online Nepali TTS is enabled but edge-tts is not installed"
                )
        self._load_engine()
        self._start_playback()

    def _load_engine(self):
        # 1) Try piper-tts
        try:
            from piper import PiperVoice
            model_path, config_path = self._ensure_piper_model()
            if model_path and model_path.exists():
                self.piper = PiperVoice.load(str(model_path), config_path=str(config_path) if config_path else None)
                self.engine_type = "piper"
                log.info(f"Piper TTS loaded: {self.voice_model}")
                return
        except ImportError:
            log.info("piper-tts not installed, trying pyttsx3")
        except Exception as e:
            log.warning(f"Piper load failed: {e}")
        # 2) Fallback to pyttsx3 (cross-platform system TTS)
        try:
            import pyttsx3  # noqa: F401

            # Windows SAPI/COM speech objects are thread-affine. The actual
            # engine is therefore initialized later by the persistent playback
            # thread, which remains its sole owner for Alpha's whole lifetime.
            self.engine_type = "pyttsx3"
            log.info("pyttsx3 available; speech worker will initialize it")
            return
        except Exception as e:
            log.warning(f"pyttsx3 unavailable: {e}")
        # 3) Mock
        self.engine_type = "mock"
        log.warning("No TTS engine available. Running in SILENT mode.")

    def _ensure_piper_model(self):
        """Check if model onnx exists; returns (model_path, config_path). Does not download (offline-first)."""
        base = self.data_dir
        model = base / f"{self.voice_model}.onnx"
        config = base / f"{self.voice_model}.onnx.json"
        if model.exists():
            return model, (config if config.exists() else None)
        # check for any .onnx voice
        onnx_files = list(base.glob("*.onnx"))
        if onnx_files:
            cfg = onnx_files[0].with_suffix(".onnx.json")
            return onnx_files[0], (cfg if cfg.exists() else None)
        return None, None

    # ---- Event hooks ----

    def on_start(self, cb: Callable): self._on_start.append(cb)
    def on_end(self, cb: Callable): self._on_end.append(cb)
    def on_audio_chunk(self, cb: Callable[[bytes], None]): self._on_audio_chunk.append(cb)

    @property
    def speaking(self) -> bool:
        return self._is_speaking.is_set()

    # ---- Public API ----

    def say(self, text: str, interrupt: bool = True):
        """Queue text to be spoken."""
        if not text or not text.strip():
            return
        if contains_unsupported_script(text):
            log.warning("Unsupported response script blocked before TTS")
            text = UNSUPPORTED_LANGUAGE_MESSAGE
        text = self._clean_text(text)
        if interrupt:
            self.stop()
        self._play_queue.put(text)

    def begin_stream(self) -> None:
        """Keep one speaking session open while response chunks arrive."""

        self.stop()
        self._stream_open.set()

    def end_stream(self) -> None:
        """Close a streamed response after every queued chunk is spoken."""

        if not self._stream_open.is_set():
            return
        self._stream_open.clear()
        self._play_queue.put(_STREAM_END)

    def stop(self):
        """Stop current speech and clear queue."""
        self._interrupt_event.set()
        self._stream_open.clear()
        while not self._play_queue.empty():
            try:
                self._play_queue.get_nowait()
            except queue.Empty:
                break
        if getattr(self, "_active_mci_alias", "") and os.name == "nt":
            try:
                import ctypes

                ctypes.windll.winmm.mciSendStringW(
                    f"stop {self._active_mci_alias}",
                    None,
                    0,
                    None,
                )
            except Exception:
                pass
        # Let the playback owner thread stop its own SAPI engine. Calling
        # pyttsx3.stop() from this (usually UI/runtime) thread corrupts the
        # Windows speech driver's state and causes later answers to be silent.
        speech_idle = getattr(self, "_speech_idle", None)
        if (
            speech_idle is not None
            and self._is_speaking.is_set()
        ):
            speech_idle.wait(timeout=1.0)
        self._interrupt_event.clear()

    def shutdown(self):
        self.stop()
        self._shutdown_event.set()
        self._play_queue.put(None)
        if self._play_thread:
            self._play_thread.join(timeout=2.0)

    # ---- Internals ----

    def _clean_text(self, text: str) -> str:
        # Remove command tags before speaking
        text = re.sub(r"\[\[CMD:[^\]]*\]\]", "", text).strip()
        # Remove markdown
        text = re.sub(r"[*_`#>]", "", text)
        # Collapse whitespace
        text = re.sub(r"\s+", " ", text).strip()
        return text

    def _start_playback(self):
        if not hasattr(self, "_stream_open"):
            self._stream_open = threading.Event()
        if not hasattr(self, "_speech_idle"):
            self._speech_idle = threading.Event()
            self._speech_idle.set()
        if not hasattr(self, "_pyttsx"):
            self._pyttsx = None
        if not hasattr(self, "_pyttsx_owner_thread_id"):
            self._pyttsx_owner_thread_id = None
        if not hasattr(self, "performance"):
            self.performance = None
        self._play_thread = threading.Thread(target=self._play_loop, daemon=True, name="tts-playback")
        self._play_thread.start()

    def _play_loop(self):
        if self.engine_type == "pyttsx3":
            try:
                self._initialize_pyttsx_engine()
            except Exception as exc:
                log.warning(f"pyttsx3 worker initialization failed: {exc}")
                self._pyttsx = None
                self.engine_type = "mock"
        while not self._shutdown_event.is_set():
            try:
                text = self._play_queue.get(timeout=0.3)
            except queue.Empty:
                continue
            if text is None:
                break
            if text is _STREAM_END:
                if self._is_speaking.is_set():
                    self._finish_speaking()
                continue
            if not self._is_speaking.is_set():
                self._speech_idle.clear()
                self._is_speaking.set()
                for cb in self._on_start:
                    try: cb()
                    except Exception: pass
            started = time.perf_counter()
            succeeded = False
            try:
                is_nepali = bool(re.search(r"[\u0900-\u097F]", text))
                used_nepali_neural = (
                    is_nepali
                    and not self._nepali_voice_id
                    and self._online_nepali
                    and self._edge_tts_available
                    and self._speak_nepali_neural(text)
                )
                if used_nepali_neural:
                    pass
                elif self.engine_type == "piper":
                    self._speak_piper(text)
                elif self.engine_type == "pyttsx3":
                    self._speak_pyttsx(text)
                else:
                    self._speak_mock(text)
                succeeded = True
            except Exception as e:
                log.error(f"TTS playback error: {e}")
            finally:
                performance = getattr(self, "performance", None)
                if performance is not None:
                    performance.record(
                        "tts",
                        (time.perf_counter() - started) * 1000,
                        succeeded,
                        self.engine_type or "unknown",
                    )
            if not self._stream_open.is_set() and self._play_queue.empty():
                self._finish_speaking()

    def _finish_speaking(self) -> None:
        self._is_speaking.clear()
        self._speech_idle.set()
        for callback in self._on_end:
            try:
                callback()
            except Exception:
                pass

    def _speak_piper(self, text: str):
        import numpy as np
        import sounddevice as sd
        synthesize_args = {
            "speaker_id": None,
            "length_scale": 1.0 / self.rate,
        }
        try:
            stream = sd.OutputStream(samplerate=22050, channels=1, dtype="int16")
            stream.start()
            for audio_bytes in self.piper.synthesize_stream_raw(text, **synthesize_args):
                if (
                    self._interrupt_event.is_set()
                    or self._shutdown_event.is_set()
                ):
                    break
                arr = np.frombuffer(audio_bytes, dtype=np.int16)
                arr = (arr * self.volume).astype(np.int16)
                stream.write(arr)
                for cb in self._on_audio_chunk:
                    try: cb(audio_bytes)
                    except Exception: pass
            stream.stop(); stream.close()
            log_voice(f"TTS(piper): '{text[:80]}...' " if len(text) > 80 else f"TTS(piper): '{text}'")
        except Exception as e:
            log.error(f"Piper playback error: {e}")

    def _initialize_pyttsx_engine(self) -> None:
        """Create the system speech engine on its permanent owner thread."""

        import pyttsx3

        self._pyttsx_owner_thread_id = threading.get_ident()
        self._pyttsx = pyttsx3.init()
        self._pyttsx.setProperty("rate", int(180 * self.rate))
        self._pyttsx.setProperty("volume", self.volume)
        self._default_voice_id = self._pyttsx.getProperty("voice")
        for voice in self._pyttsx.getProperty("voices") or []:
            language_text = " ".join(
                str(item)
                for item in getattr(voice, "languages", []) or []
            ).casefold()
            identity = (
                f"{getattr(voice, 'id', '')} "
                f"{getattr(voice, 'name', '')} {language_text}"
            ).casefold()
            if (
                "ne-np" in identity
                or "ne_np" in identity
                or "nepali" in identity
            ):
                self._nepali_voice_id = voice.id
                break
        if self._nepali_voice_id:
            log.info("pyttsx3 TTS ready with English/Nepali voices")
        else:
            log.info("pyttsx3 TTS ready (English system voice)")

    def _speak_pyttsx(self, text: str):
        if (
            self._pyttsx is None
            or self._pyttsx_owner_thread_id != threading.get_ident()
        ):
            raise RuntimeError(
                "pyttsx3 speech attempted outside its playback owner thread"
            )

        is_nepali = bool(re.search(r"[\u0900-\u097F]", text))
        if is_nepali and self._nepali_voice_id:
            self._pyttsx.setProperty(
                "voice",
                self._nepali_voice_id,
            )
        elif self._default_voice_id:
            self._pyttsx.setProperty(
                "voice",
                self._default_voice_id,
            )
        if (
            is_nepali
            and not self._nepali_voice_id
            and not self._warned_missing_nepali_voice
        ):
            log.warning(
                "Nepali response text is enabled, but Windows has no "
                "offline Nepali speech voice installed"
            )
            self._warned_missing_nepali_voice = True

        # Drive the SAPI message loop from this owner thread so interruption
        # remains responsive without creating a fresh COM thread per chunk.
        loop_started = False
        try:
            self._pyttsx.say(text)
            self._pyttsx.startLoop(False)
            loop_started = True
            while (
                self._pyttsx.isBusy()
                and not self._shutdown_event.is_set()
            ):
                if self._interrupt_event.is_set():
                    self._pyttsx.stop()
                    break
                self._pyttsx.iterate()
                time.sleep(0.01)
        finally:
            if loop_started:
                try:
                    self._pyttsx.endLoop()
                except Exception:
                    pass
        log_voice(f"TTS(pyttsx3): '{text[:80]}...'")

    def _speak_nepali_neural(self, text: str) -> bool:
        """Synthesize Nepali online, then play the temporary MP3 on Windows."""

        if os.name != "nt":
            return False
        media_path = ""
        alias = f"alpha_nepali_{threading.get_ident()}"
        try:
            import asyncio
            import ctypes
            import edge_tts

            with tempfile.NamedTemporaryFile(
                suffix=".mp3",
                delete=False,
            ) as temporary:
                media_path = temporary.name

            async def _synthesize():
                communicator = edge_tts.Communicate(
                    text=text,
                    voice=self._nepali_voice,
                    rate=f"{int((self.rate - 1.0) * 100):+d}%",
                    volume=f"{int((self.volume - 1.0) * 100):+d}%",
                )
                await communicator.save(media_path)

            asyncio.run(_synthesize())
            if self._interrupt_event.is_set() or self._shutdown_event.is_set():
                return True

            quoted_path = media_path.replace('"', '""')
            self._active_mci_alias = alias
            open_result = ctypes.windll.winmm.mciSendStringW(
                f'open "{quoted_path}" type mpegvideo alias {alias}',
                None,
                0,
                None,
            )
            if open_result:
                raise RuntimeError(f"Windows MCI open failed ({open_result})")
            play_result = ctypes.windll.winmm.mciSendStringW(
                f"play {alias} wait",
                None,
                0,
                None,
            )
            if play_result and not self._interrupt_event.is_set():
                raise RuntimeError(f"Windows MCI playback failed ({play_result})")
            log_voice(
                f"TTS(ne-NP neural): '{text[:80]}...' "
                "(response text sent to Microsoft speech service)"
            )
            return True
        except Exception as exc:
            log.warning("Nepali neural TTS failed; using local fallback: %s", exc)
            return False
        finally:
            if self._active_mci_alias:
                try:
                    import ctypes

                    ctypes.windll.winmm.mciSendStringW(
                        f"close {self._active_mci_alias}",
                        None,
                        0,
                        None,
                    )
                except Exception:
                    pass
                self._active_mci_alias = ""
            if media_path:
                try:
                    Path(media_path).unlink(missing_ok=True)
                except Exception:
                    pass

    def _speak_mock(self, text: str):
        log.info(f"[TTS-MOCK would say]: {text}")
        remaining = min(3.0, len(text) * 0.04)
        while (
            remaining > 0
            and not self._interrupt_event.is_set()
            and not self._shutdown_event.is_set()
        ):
            step = min(0.05, remaining)
            time.sleep(step)
            remaining -= step
