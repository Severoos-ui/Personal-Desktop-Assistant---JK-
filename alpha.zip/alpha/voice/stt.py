"""Offline speech-to-text using OpenAI Whisper (faster-whisper preferred)."""

import threading
import time
import wave
import tempfile
import os
from pathlib import Path
from typing import Optional, Callable, List
import numpy as np

from alpha.utils.logger import get_logger, log_voice

log = get_logger("stt")


class SpeechToText:
    """
    Offline speech recognition.
    Preferred engine: faster-whisper (CTranslate2, fast, quantized).
    Fallback: openai-whisper.
    Final fallback: SpeechRecognition + Google (online, for dev only when offline unavailable).
    """

    def __init__(
        self,
        model_size: str = "base",
        sample_rate: int = 16000,
        language: str = "en",
        device: str = "auto",
        compute_type: str = "auto",
        input_device=None,
        speech_threshold: float = 0.015,
        lazy: bool = False,
        log_transcript: bool = True,
        performance=None,
        metric_name: str = "stt",
    ):
        self.sample_rate = sample_rate
        self.language = language
        self.model_size = model_size
        self.input_device = input_device
        self.speech_threshold = max(0.001, float(speech_threshold))
        self.log_transcript = bool(log_transcript)
        self.performance = performance
        self.metric_name = str(metric_name)
        self.model = None
        self.engine = None  # "faster_whisper", "whisper", "sr_google", "mock"
        self.last_detected_language = ""
        self.last_language_probability = 0.0
        self.last_confidence = 0.0
        self._device = device
        self._compute_type = compute_type
        self._load_lock = threading.Lock()
        if not lazy:
            self._load_model(device, compute_type)

    def ensure_loaded(self) -> None:
        """Load a lazy command model only after an exact wake activation."""

        if self.engine is not None:
            return
        with self._load_lock:
            if self.engine is None:
                self._load_model(self._device, self._compute_type)

    def _load_model(self, device: str, compute_type: str):
        # 1) Try faster-whisper
        try:
            from faster_whisper import WhisperModel
            if device == "auto":
                try:
                    import torch
                    device = "cuda" if torch.cuda.is_available() else "cpu"
                except ImportError:
                    device = "cpu"  # no torch -> CPU mode works fine with ctranslate2
            if compute_type == "auto":
                compute_type = "float16" if device == "cuda" else "int8"
            log.info(f"Loading faster-whisper '{self.model_size}' on {device} ({compute_type})...")
            self.model = WhisperModel(self.model_size, device=device, compute_type=compute_type)
            self.engine = "faster_whisper"
            log.info("faster-whisper loaded successfully")
            return
        except ImportError:
            log.info("faster-whisper not installed, trying openai-whisper")
        except Exception as e:
            log.warning(f"faster-whisper failed: {e}")

        # 2) Try openai-whisper
        try:
            import whisper
            import torch
            dev = device if device != "auto" else ("cuda" if torch.cuda.is_available() else "cpu")
            log.info(f"Loading whisper '{self.model_size}' on {dev}...")
            self.model = whisper.load_model(self.model_size, device=dev)
            self.engine = "whisper"
            log.info("openai-whisper loaded")
            return
        except ImportError:
            log.info("openai-whisper not installed")
        except Exception as e:
            log.warning(f"whisper failed: {e}")

        # 3) Online fallback for dev / sandbox testing
        try:
            import speech_recognition as sr
            self._sr = sr.Recognizer()
            self.engine = "sr_google"
            log.warning("Using online Google STT as fallback (install faster-whisper for offline STT)")
        except ImportError:
            self.engine = "mock"
            log.error("No speech-to-text engine is available; voice commands are disabled")

    # ---- Transcription ----

    def transcribe_array(
        self,
        audio: np.ndarray,
        initial_prompt: Optional[str] = None,
        hotwords: Optional[str] = None,
        language_hint: Optional[str] = None,
    ) -> str:
        """Transcribe a float32 numpy array (-1..1) at self.sample_rate."""
        started = time.perf_counter()
        result = ""
        success = False
        try:
            self.ensure_loaded()
            if self.engine == "faster_whisper":
                result = self._transcribe_fw(
                    audio,
                    initial_prompt=initial_prompt,
                    hotwords=hotwords,
                    language_hint=language_hint,
                )
                requested_language = (
                    self.language
                    if language_hint is None
                    else language_hint
                )
                detected = str(self.last_detected_language or "").casefold()
                detected = detected.split("-", 1)[0]
                language_probability = float(
                    self.last_language_probability or 0.0
                )
                # Whisper can assign a short English command to an unrelated
                # language at low confidence, producing garbled Latin text.
                # Retry only that ambiguous case with English constrained;
                # confident non-English/non-Nepali speech is still rejected.
                if (
                    requested_language == "auto"
                    and detected not in {"", "en", "ne"}
                    and language_probability < 0.70
                ):
                    original = (
                        result,
                        self.last_detected_language,
                        self.last_language_probability,
                        self.last_confidence,
                    )
                    retry = self._transcribe_fw(
                        audio,
                        initial_prompt=initial_prompt,
                        hotwords=hotwords,
                        language_hint="en",
                    )
                    if (
                        retry
                        and self.last_confidence
                        >= max(0.12, float(original[3]) * 0.75)
                    ):
                        result = retry
                    else:
                        (
                            result,
                            self.last_detected_language,
                            self.last_language_probability,
                            self.last_confidence,
                        ) = original
            elif self.engine == "whisper":
                result = self._transcribe_whisper(
                    audio,
                    initial_prompt=initial_prompt,
                    language_hint=language_hint,
                )
            success = bool(result) or self.engine == "mock"
            return result
        finally:
            performance = getattr(self, "performance", None)
            if performance is not None:
                performance.record(
                    getattr(self, "metric_name", "stt"),
                    (time.perf_counter() - started) * 1000,
                    success,
                    self.engine or "unavailable",
                )

    def _transcribe_fw(
        self,
        audio: np.ndarray,
        initial_prompt: Optional[str] = None,
        hotwords: Optional[str] = None,
        language_hint: Optional[str] = None,
    ) -> str:
        try:
            requested_language = (
                self.language
                if language_hint is None
                else language_hint
            )
            metric_name = getattr(self, "metric_name", "stt")
            model_size = str(getattr(self, "model_size", ""))
            fast_wake_path = (
                metric_name == "wake_stt"
                or model_size.casefold().startswith("tiny")
            )
            segments, info = self.model.transcribe(
                audio.astype(np.float32),
                language=(
                    requested_language
                    if requested_language != "auto"
                    else None
                ),
                beam_size=1 if fast_wake_path else 3,
                vad_filter=True,
                vad_parameters=dict(
                    min_silence_duration_ms=200 if fast_wake_path else 350
                ),
                initial_prompt=initial_prompt,
                hotwords=hotwords,
                condition_on_previous_text=False,
            )
            segment_list = list(segments)
            text = " ".join(seg.text.strip() for seg in segment_list)
            self.last_detected_language = str(
                getattr(info, "language", "") or ""
            )
            self.last_language_probability = float(
                getattr(info, "language_probability", 0.0) or 0.0
            )
            if segment_list:
                confidences = []
                for segment in segment_list:
                    raw_logprob = getattr(segment, "avg_logprob", None)
                    raw_no_speech = getattr(
                        segment,
                        "no_speech_prob",
                        None,
                    )
                    avg_logprob = float(
                        raw_logprob if raw_logprob is not None else -10.0
                    )
                    no_speech = float(
                        raw_no_speech if raw_no_speech is not None else 1.0
                    )
                    confidences.append(
                        max(0.0, min(1.0, np.exp(avg_logprob)))
                        * max(0.0, 1.0 - no_speech)
                    )
                self.last_confidence = sum(confidences) / len(confidences)
            else:
                self.last_confidence = 0.0
            if self.log_transcript:
                log_voice(
                    "STT(fw, language=%s, confidence=%.2f): '%s'"
                    % (
                        self.last_detected_language or "unknown",
                        self.last_confidence,
                        text,
                    )
                )
            return text
        except Exception as e:
            log.error(f"faster-whisper transcription error: {e}")
            return ""

    def _transcribe_whisper(
        self,
        audio: np.ndarray,
        initial_prompt: Optional[str] = None,
        language_hint: Optional[str] = None,
    ) -> str:
        try:
            requested_language = (
                self.language
                if language_hint is None
                else language_hint
            )
            result = self.model.transcribe(
                audio.astype(np.float32),
                language=(
                    requested_language
                    if requested_language != "auto"
                    else None
                ),
                initial_prompt=initial_prompt,
            )
            text = result.get("text", "").strip()
            self.last_detected_language = str(result.get("language", "") or "")
            segments = result.get("segments") or []
            if segments:
                confidences = []
                for segment in segments:
                    raw_logprob = segment.get("avg_logprob")
                    raw_no_speech = segment.get("no_speech_prob")
                    avg_logprob = float(
                        raw_logprob if raw_logprob is not None else -10.0
                    )
                    no_speech = float(
                        raw_no_speech if raw_no_speech is not None else 1.0
                    )
                    confidences.append(
                        max(0.0, min(1.0, np.exp(avg_logprob)))
                        * max(0.0, 1.0 - no_speech)
                    )
                self.last_confidence = sum(confidences) / len(confidences)
            else:
                self.last_confidence = 0.0
            if self.log_transcript:
                log_voice(f"STT(whisper): '{text}'")
            return text
        except Exception as e:
            log.error(f"whisper transcription error: {e}")
            return ""

    def transcribe_file(self, path: str) -> str:
        if self.engine == "faster_whisper":
            segments, _ = self.model.transcribe(path, vad_filter=True)
            return " ".join(s.text.strip() for s in segments)
        if self.engine == "whisper":
            r = self.model.transcribe(path)
            return r.get("text", "").strip()
        return ""

    def transcribe_once_from_mic(self, duration: float = 7.0,
                                 on_audio_level: Optional[Callable[[float], None]] = None,
                                 silence_after_speech: float = 1.2,
                                 initial_prompt: Optional[str] = None,
                                 hotwords: Optional[str] = None,
                                 ignore_initial_audio: float = 0.0) -> str:
        """
        Record from microphone until silence or max duration, then transcribe.
        Returns transcribed text. In mock mode, returns an empty string.
        """
        self.ensure_loaded()
        if self.engine == "mock":
            log.warning("STT mock mode - microphone transcription is unavailable")
            return ""
        try:
            import sounddevice as sd
        except ImportError:
            try:
                import pyaudio
                return self._record_pyaudio(
                    duration,
                    on_audio_level,
                    silence_after_speech,
                    initial_prompt,
                    hotwords,
                    ignore_initial_audio,
                )
            except Exception:
                return ""
        return self._record_sd(
            duration,
            on_audio_level,
            silence_after_speech,
            initial_prompt,
            hotwords,
            ignore_initial_audio,
        )

    def _record_sd(
        self,
        max_duration: float,
        on_level,
        silence_after: float,
        initial_prompt: Optional[str] = None,
        hotwords: Optional[str] = None,
        ignore_initial_audio: float = 0.0,
    ) -> str:
        import sounddevice as sd
        CHUNK = 1024
        SR = self.sample_rate
        recorded = []
        last_voice = time.time()
        voice_detected = False
        voice_seconds = 0.0
        start = time.time()

        def callback(indata, frames, time_info, status):
            nonlocal last_voice, voice_detected, voice_seconds
            chunk = indata.flatten().astype(np.float32)
            rms = float(np.sqrt(np.mean(chunk ** 2)) + 1e-10)
            if on_level:
                on_level(rms)
            now = time.time()
            # Alpha's asynchronous activation/listening chimes can leak into
            # the microphone. Ignore that short interval so the tone is not
            # mistaken for the user's command and followed by an early timeout.
            if (now - start) < max(0.0, ignore_initial_audio):
                return
            recorded.append(chunk.copy())
            if rms > self.speech_threshold:
                voice_seconds += len(chunk) / float(SR)
                if voice_seconds >= 0.16:
                    voice_detected = True
                    last_voice = now
            elif not voice_detected:
                voice_seconds = 0.0

        with sd.InputStream(
            device=self.input_device,
            samplerate=SR,
            channels=1,
            blocksize=CHUNK,
            dtype="float32",
            callback=callback,
        ):
            while (time.time() - start) < max_duration:
                if voice_detected and (time.time() - last_voice) > silence_after:
                    break
                time.sleep(0.05)

        if not recorded:
            return ""
        audio = np.concatenate(recorded)
        return self.transcribe_array(
            audio,
            initial_prompt=initial_prompt,
            hotwords=hotwords,
        )

    def _record_pyaudio(
        self,
        max_duration: float,
        on_level,
        silence_after: float,
        initial_prompt: Optional[str] = None,
        hotwords: Optional[str] = None,
        ignore_initial_audio: float = 0.0,
    ) -> str:
        import pyaudio
        CHUNK = 1024
        p = pyaudio.PyAudio()
        open_args = dict(
            format=pyaudio.paInt16,
            channels=1,
            rate=self.sample_rate,
            input=True,
            frames_per_buffer=CHUNK,
        )
        input_index = self._pyaudio_input_index(p)
        if input_index is not None:
            open_args["input_device_index"] = input_index
        stream = p.open(**open_args)
        frames = []
        last_voice = time.time()
        voice_detected = False
        voice_seconds = 0.0
        start = time.time()
        while (time.time() - start) < max_duration:
            data = stream.read(CHUNK, exception_on_overflow=False)
            arr = np.frombuffer(data, dtype=np.int16).astype(np.float32) / 32768.0
            rms = float(np.sqrt(np.mean(arr ** 2)) + 1e-10)
            if on_level:
                on_level(rms)
            now = time.time()
            if (now - start) < max(0.0, ignore_initial_audio):
                continue
            frames.append(arr)
            if rms > self.speech_threshold:
                voice_seconds += len(arr) / float(self.sample_rate)
                if voice_seconds >= 0.16:
                    voice_detected = True
                    last_voice = now
            elif not voice_detected:
                voice_seconds = 0.0
            if voice_detected and (now - last_voice) > silence_after:
                break
        stream.stop_stream(); stream.close(); p.terminate()
        if not frames:
            return ""
        audio = np.concatenate(frames)
        return self.transcribe_array(
            audio,
            initial_prompt=initial_prompt,
            hotwords=hotwords,
        )

    def _pyaudio_input_index(self, pa) -> Optional[int]:
        if self.input_device is None:
            return None
        if isinstance(self.input_device, int):
            return self.input_device
        text = str(self.input_device).strip()
        if text.isdigit():
            return int(text)
        needle = text.casefold()
        for index in range(pa.get_device_count()):
            info = pa.get_device_info_by_index(index)
            if (
                int(info.get("maxInputChannels", 0)) > 0
                and needle in str(info.get("name", "")).casefold()
            ):
                return index
        raise ValueError(f"Microphone device not found: {self.input_device}")
