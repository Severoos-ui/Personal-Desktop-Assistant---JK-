"""Always-on local voice engine with an exact Alpha wake-word gate."""

import queue
import re
import threading
import time
from collections import deque
from difflib import SequenceMatcher
from enum import Enum
from typing import Callable, Deque, List, Optional

import numpy as np

from alpha.config.settings import ConfigManager
from alpha import WAKE_PHRASE
from alpha.language import (
    UNSUPPORTED_LANGUAGE_MESSAGE,
    validate_spoken_language,
)
from alpha.utils.logger import get_logger, log_voice
from alpha.voice.stt import SpeechToText
from alpha.voice.tts import TextToSpeech
from alpha.voice.wake_word import WakeWordDetector, WakeWordMatch

log = get_logger("voice.engine")


class VoiceState(Enum):
    IDLE = "idle"
    STARTING = "starting_microphone"
    MIC_ERROR = "microphone_error"
    LISTENING_WAKE = "listening_wake"
    PREPARING_CMD = "preparing_command"
    LISTENING_CMD = "listening_command"
    THINKING = "thinking"
    SPEAKING = "speaking"


class VoiceEngine:
    """Accept only exact, anchored ``Alpha`` and ignore all other speech."""

    _WAKE_PREFIX = re.compile(
        rf"^\s*{re.escape(WAKE_PHRASE)}"
        r"(?=$|[\s,.:;!?\-])[\s,.:;!?\-]*(?P<command>.*)$",
        re.IGNORECASE,
    )
    _STOP_COMMANDS = {
        "stop",
        "stop it",
        "stop talking",
        "cancel",
        "cancel that",
        "quiet",
        "be quiet",
        "shut up",
        "never mind",
        "nevermind",
        "well done alpha",
        "shutdown alpha",
    }
    _END_CONVERSATION_COMMANDS = {
        "bye",
        "bye alpha",
        "goodbye",
        "goodbye alpha",
        "end conversation",
        "end the conversation",
        "stop listening",
        "go to sleep",
        "that is all",
        "that s all",
        "thanks that is all",
        "thank you that is all",
        "बिदा",
        "अब पुग्यो",
        "कुराकानी बन्द गर",
        "सुन्न बन्द गर",
    }

    def __init__(self, config=None, performance=None, events=None):
        cfg = config or ConfigManager.instance().config
        self.cfg = cfg
        self.performance = performance
        self.events = events
        voice_cfg = cfg.voice

        self.state = VoiceState.IDLE
        self._state_listeners: List[Callable[[VoiceState], None]] = []
        self._audio_listeners: List[Callable[[float], None]] = []
        self._transcript_listeners: List[Callable[[str, bool], None]] = []
        self._activation_listeners: List[Callable[[str], None]] = []
        self._cancel_listeners: List[Callable[[str], None]] = []
        self._command_queue: queue.Queue = queue.Queue()

        self._silence_threshold = float(
            getattr(voice_cfg, "silence_threshold", 0.02)
        )
        input_device = getattr(voice_cfg, "input_device", None)
        # Exact transcript validation provides the safety gate, allowing a
        # shorter endpoint delay after the user finishes the wake phrase.
        self._phrase_silence = 0.24
        self._phrase_max_duration = min(
            8.0,
            max(2.0, float(getattr(voice_cfg, "max_speech_duration", 8.0))),
        )

        # The ambient monitor owns the microphone until command STT requests
        # an exclusive hand-off.
        self.wakeword = WakeWordDetector(
            model_path=getattr(voice_cfg, "wake_word_model", None),
            sample_rate=voice_cfg.sample_rate,
            input_device=input_device,
            threshold=0.5,
            performance=performance,
        )
        # A small model verifies the exact wake phrase while dormant. The
        # multilingual command model is loaded lazily only after activation.
        self.wake_stt = SpeechToText(
            model_size=getattr(voice_cfg, "wake_stt_model", "tiny"),
            sample_rate=voice_cfg.sample_rate,
            # The immutable wake phrase itself is English. A multilingual
            # second pass runs only after this strict gate succeeds.
            language="en",
            input_device=input_device,
            speech_threshold=max(
                0.0035,
                self._silence_threshold * 0.25,
            ),
            log_transcript=False,
            lazy=True,
            performance=performance,
            metric_name="wake_stt",
        )
        self.stt = SpeechToText(
            model_size=voice_cfg.stt_model,
            sample_rate=voice_cfg.sample_rate,
            language=getattr(voice_cfg, "stt_language", "auto"),
            input_device=input_device,
            speech_threshold=max(
                0.0035,
                self._silence_threshold * 0.25,
            ),
            lazy=True,
            performance=performance,
            metric_name="command_stt",
        )
        self.tts = TextToSpeech(
            voice_model=voice_cfg.tts_model,
            rate=voice_cfg.tts_rate,
            volume=voice_cfg.tts_volume,
            data_dir=cfg.data_dir / "models",
            online_nepali=getattr(
                voice_cfg,
                "nepali_online_tts",
                True,
            ),
            nepali_voice=getattr(
                voice_cfg,
                "nepali_tts_voice",
                "ne-NP-SagarNeural",
            ),
            performance=performance,
        )

        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._preload_thread: Optional[threading.Thread] = None
        self._cmd_lock = threading.Lock()
        # Wake and command recognition use different model instances. Keeping
        # independent locks prevents the large multilingual model warm-up from
        # blocking the lightweight exact wake-word verifier.
        self._wake_stt_lock = threading.Lock()
        self._command_stt_lock = threading.Lock()
        # Compatibility alias retained for older extensions and tests.
        self._stt_lock = self._command_stt_lock
        self._state_lock = threading.RLock()
        self._phrase_lock = threading.RLock()
        self._current_audio_level = 0.0
        self._ambient_noise_floor = 0.00005
        self._mic_unavailable_since = 0.0

        # Always-on wake-phrase recorder.
        self._pre_roll: Deque[np.ndarray] = deque(maxlen=4)
        self._phrase_frames: List[np.ndarray] = []
        self._phrase_active = False
        self._phrase_started_at = 0.0
        self._phrase_last_voice_at = 0.0
        self._phrase_voice_seconds = 0.0
        self._phrase_transcribing = False
        self._phrase_generation = 0
        self._ignore_phrase_until = 0.0
        self._conversation_active = False
        self._last_spoken_text = ""
        self._suppress_next_tts_end_followup = False
        self._pending_hotkey_activation = False

        self.wakeword.on_audio_frame(self._on_monitor_frame)
        self.tts.on_start(self._on_tts_start)
        self.tts.on_end(self._on_tts_end)

    # ---- Lifecycle ----

    def start(self):
        if self._running:
            return
        self._running = True
        self._conversation_active = False
        self._mic_unavailable_since = time.monotonic()
        self._set_state(VoiceState.STARTING)
        self.wakeword.start()
        self._thread = threading.Thread(
            target=self._loop,
            daemon=True,
            name="voice-engine",
        )
        self._thread.start()
        self._preload_thread = threading.Thread(
            target=self._preload_active_models,
            daemon=True,
            name="alpha-model-preload",
        )
        self._preload_thread.start()
        log.info("Voice engine started; opening the always-on microphone")

    def stop(self):
        self._running = False
        with self._phrase_lock:
            self._phrase_generation += 1
            self._reset_phrase_locked()
            self._phrase_transcribing = False
        self.wakeword.stop()
        self.tts.shutdown()
        if self._thread:
            self._thread.join(timeout=2.0)
        if self._preload_thread and self._preload_thread.is_alive():
            self._preload_thread.join(timeout=0.5)
        self._set_state(VoiceState.IDLE)
        log.info("Voice engine stopped")

    def _preload_active_models(self) -> None:
        """Warm speech models sequentially without blocking mic/UI startup."""

        started = time.perf_counter()
        command_started = started
        success = False
        try:
            with self._wake_stt_lock:
                self.wake_stt.ensure_loaded()
            wake_ready = self.wake_stt.engine not in {None, "mock"}
            log.info("Exact Alpha wake STT preloaded")
            if self.performance is not None:
                self.performance.record(
                    "wake_stt_preload",
                    (time.perf_counter() - started) * 1000,
                    wake_ready,
                    self.wake_stt.model_size,
                )

            command_started = time.perf_counter()
            with self._command_stt_lock:
                self.stt.ensure_loaded()
            success = self.stt.engine not in {None, "mock"}
            log.info("English/Nepali command STT preloaded")
            if self.events is not None:
                self.events.publish(
                    "speech.model_ready",
                    {"engine": self.stt.engine, "model": self.stt.model_size},
                    source="voice",
                )
        except Exception as exc:
            log.warning(
                "Speech model preload failed error_type=%s",
                type(exc).__name__,
            )
        finally:
            if self.performance is not None:
                self.performance.record(
                    "stt_preload",
                    (time.perf_counter() - command_started) * 1000,
                    success,
                    self.stt.model_size,
                )

    # ---- Public API ----

    @property
    def audio_level(self) -> float:
        return self._current_audio_level

    @property
    def audio_available(self) -> bool:
        return self.wakeword.audio_available

    def respond(self, text: str):
        self._last_spoken_text = str(text or "").strip()
        self.tts.say(text)

    def begin_stream_response(self) -> None:
        self._last_spoken_text = ""
        self.tts.begin_stream()

    def queue_response_chunk(self, text: str) -> None:
        chunk = str(text or "").strip()
        if not chunk:
            return
        self._last_spoken_text = (
            f"{self._last_spoken_text} {chunk}".strip()
        )
        self.tts.say(chunk, interrupt=False)

    def end_stream_response(self) -> None:
        self.tts.end_stream()

    def on_state_change(self, callback: Callable[[VoiceState], None]):
        self._state_listeners.append(callback)

    def on_audio_level(self, callback: Callable[[float], None]):
        self._audio_listeners.append(callback)

    def on_transcript(self, callback: Callable[[str, bool], None]):
        self._transcript_listeners.append(callback)

    def on_activation(self, callback: Callable[[str], None]):
        self._activation_listeners.append(callback)

    def on_cancel(self, callback: Callable[[str], None]):
        self._cancel_listeners.append(callback)

    def on_command(self, callback: Callable[[str], None]):
        self._cmd_handler = callback

    def set_command_handler(self, callback: Callable[[str], None]):
        self._cmd_handler = callback

    def activate_from_hotkey(self) -> bool:
        """Wake Alpha without speech after a verified local Alt+F11 request."""

        if not self._running:
            return False
        if self.state in {
            VoiceState.IDLE,
            VoiceState.STARTING,
            VoiceState.MIC_ERROR,
        }:
            self._pending_hotkey_activation = True
            log.info("Alt+F11 activation queued until microphone readiness")
            return True
        if self.state == VoiceState.LISTENING_WAKE:
            self._pending_hotkey_activation = False
            self._conversation_active = bool(
                getattr(
                    self.cfg.voice,
                    "continuous_conversation",
                    True,
                )
            )
            self._notify_activation("hotkey")
            self._begin_command_capture()
            return True
        if self.state in {
            VoiceState.PREPARING_CMD,
            VoiceState.LISTENING_CMD,
        }:
            self._notify_activation("hotkey")
            return True
        log.debug("Alt+F11 ignored while Alpha is %s", self.state.value)
        return False

    def cancel_current(self, source: str = "user"):
        """Interrupt current speech/reasoning and return to wake listening."""

        self._conversation_active = False
        with self._phrase_lock:
            self._phrase_generation += 1
            self._phrase_transcribing = False
            self._reset_phrase_locked()
        while not self._command_queue.empty():
            try:
                self._command_queue.get_nowait()
            except queue.Empty:
                break
        self.tts.stop()
        for callback in tuple(self._cancel_listeners):
            try:
                callback(source)
            except Exception as exc:
                log.error(f"Cancel listener error: {exc}")
        log_voice(f"Current interaction cancelled ({source})")
        self._return_to_wake_listening()

    @classmethod
    def extract_wake_command(
        cls,
        transcript: str,
        allow_short: bool = False,
    ) -> Optional[str]:
        """Return text only after exact, anchored ``Alpha``.

        ``allow_short`` remains in the signature for compatibility but is
        deliberately ignored.
        """

        text = (transcript or "").strip()
        match = cls._WAKE_PREFIX.match(text)
        if match:
            return (match.group("command") or "").strip()
        return None

    @property
    def wake_phrase(self) -> str:
        """Phrase currently required by the ambient listener."""

        voice_config = getattr(getattr(self, "cfg", None), "voice", None)
        return str(getattr(voice_config, "wake_phrase", WAKE_PHRASE))

    @classmethod
    def is_stop_command(cls, text: str) -> bool:
        normalized = re.sub(
            r"[^a-z]+",
            " ",
            (text or "").casefold(),
        ).strip()
        return normalized in cls._STOP_COMMANDS

    @classmethod
    def is_end_conversation_command(cls, text: str) -> bool:
        normalized = re.sub(
            r"[^\w\u0900-\u097F]+",
            " ",
            (text or "").casefold(),
        ).strip()
        return normalized in cls._END_CONVERSATION_COMMANDS

    @staticmethod
    def _normalise_echo_text(text: str) -> str:
        return re.sub(
            r"[^\w\u0900-\u097F]+",
            " ",
            (text or "").casefold(),
        ).strip()

    @classmethod
    def is_likely_tts_echo(
        cls,
        transcript: str,
        spoken_text: str,
        threshold: float = 0.72,
    ) -> bool:
        """Reject Alpha's own loudspeaker audio from the barge-in path."""

        heard = cls._normalise_echo_text(transcript)
        spoken = cls._normalise_echo_text(spoken_text)
        if not heard or not spoken:
            return False
        heard_words = heard.split()
        spoken_words = set(spoken.split())
        if len(heard_words) == 1:
            return heard_words[0] in spoken_words
        word_overlap = sum(
            1 for word in heard_words if word in spoken_words
        ) / len(heard_words)
        similarity = SequenceMatcher(None, heard, spoken).ratio()
        return word_overlap >= threshold or similarity >= threshold

    # ---- State and activation ----

    def _set_state(self, state: VoiceState):
        with self._state_lock:
            self.state = state
        for callback in tuple(self._state_listeners):
            try:
                callback(state)
            except Exception as exc:
                log.error(f"State listener error: {exc}")
        if self.events is not None:
            self.events.publish(
                "voice.state",
                {"state": state.value},
                source="voice",
            )

    def _notify_activation(self, source: str):
        for callback in tuple(self._activation_listeners):
            try:
                callback(source)
            except Exception as exc:
                log.error(f"Activation listener error: {exc}")
        if self.events is not None:
            self.events.publish(
                "voice.activated",
                {"source": source},
                source="voice",
            )

    def _return_to_wake_listening(self):
        if not self._running:
            self._set_state(VoiceState.IDLE)
            return
        with self._phrase_lock:
            self._phrase_generation += 1
            self._phrase_transcribing = False
            self._reset_phrase_locked()
            self._ignore_phrase_until = time.monotonic() + 0.25
        self.wakeword.resume()
        self._set_state(VoiceState.LISTENING_WAKE)
        log_voice(f'Always-on wake listener ready for "{self.wake_phrase}"')

    def _on_tts_start(self):
        with self._phrase_lock:
            self._phrase_generation += 1
            self._phrase_transcribing = False
            self._reset_phrase_locked()
        # Keep the ambient stream alive for live-style barge-in. Transcribed
        # audio must clear confidence and text-echo checks before it can become
        # the next turn, preventing Alpha's loudspeaker from commanding itself.
        self.wakeword.resume()
        self._set_state(VoiceState.SPEAKING)

    def _on_tts_end(self):
        if getattr(self, "_suppress_next_tts_end_followup", False):
            self._suppress_next_tts_end_followup = False
            return
        continuous = bool(
            getattr(
                self.cfg.voice,
                "continuous_conversation",
                True,
            )
        )
        if (
            self._running
            and continuous
            and self._conversation_active
        ):
            self._begin_followup_capture()
            return
        self._return_to_wake_listening()

    def _begin_followup_capture(self):
        """Listen for the next turn without repeating the wake phrase."""

        timeout = min(
            30.0,
            max(
                3.0,
                float(
                    getattr(
                        self.cfg.voice,
                        "continuous_followup_timeout",
                        10.0,
                    )
                ),
            ),
        )
        with self._phrase_lock:
            if not self._running:
                return
            self._phrase_generation += 1
            self._phrase_transcribing = False
            self._reset_phrase_locked()
        log_voice(
            "Continuous conversation active; listening for a follow-up "
            f"for {timeout:g} seconds"
        )
        self._set_state(VoiceState.PREPARING_CMD)
        self._capture_command(followup=True)

    def _interrupt_speech_with_command(self, text: str) -> None:
        """Stop the current response and dispatch clear user barge-in speech."""

        command = (text or "").strip()
        if not command:
            return
        self._conversation_active = True
        self._suppress_next_tts_end_followup = True
        with self._phrase_lock:
            self._phrase_generation += 1
            self._phrase_transcribing = False
            self._reset_phrase_locked()
        self.tts.stop()
        log_voice(f"Live conversation barge-in: '{command}'")
        self._dispatch_command(command)

    def _interrupt_speech_and_listen(self) -> None:
        """Stop talking but keep the active conversation ready for a follow-up."""

        self._conversation_active = True
        self._suppress_next_tts_end_followup = True
        with self._phrase_lock:
            self._phrase_generation += 1
            self._phrase_transcribing = False
            self._reset_phrase_locked()
        self.tts.stop()
        log_voice("Speech stopped by live conversation barge-in")
        self._begin_followup_capture()

    # ---- Always-on wake phrase spotting ----

    def _emit_audio_level(self, rms: float):
        self._current_audio_level = float(min(1.0, max(0.0, rms * 8.0)))
        for callback in tuple(self._audio_listeners):
            try:
                callback(self._current_audio_level)
            except Exception:
                pass

    def _on_monitor_frame(self, frame: np.ndarray, timestamp: float):
        samples = frame.astype(np.float32) / 32768.0
        rms = float(np.sqrt(np.mean(samples * samples)) + 1e-10)
        self._emit_audio_level(rms)

        monitored_states = {
            VoiceState.LISTENING_WAKE,
            VoiceState.THINKING,
            VoiceState.SPEAKING,
        }
        if not self._running or self.state not in monitored_states:
            return

        audio_to_transcribe = None
        generation = 0
        phrase_started_at = 0.0
        frame_seconds = len(frame) / float(self.cfg.voice.sample_rate)
        speech_gate = self._wake_speech_gate()

        with self._phrase_lock:
            if (
                self.state not in monitored_states
                or self._phrase_transcribing
                or timestamp < self._ignore_phrase_until
            ):
                return

            frame_copy = frame.astype(np.int16, copy=True)
            self._pre_roll.append(frame_copy)

            if not self._phrase_active:
                if rms < speech_gate:
                    # Learn only from frames already classified as quiet, so
                    # a user's first syllable can never raise its own gate.
                    current_floor = float(
                        getattr(self, "_ambient_noise_floor", 0.00005)
                    )
                    self._ambient_noise_floor = (
                        current_floor * 0.98 + rms * 0.02
                    )
                    return
                self._phrase_active = True
                self._phrase_started_at = timestamp
                self._phrase_last_voice_at = timestamp
                self._phrase_voice_seconds = frame_seconds
                self._phrase_frames = list(self._pre_roll)
                return

            self._phrase_frames.append(frame_copy)
            if rms >= speech_gate:
                self._phrase_last_voice_at = timestamp
                self._phrase_voice_seconds += frame_seconds

            elapsed = timestamp - self._phrase_started_at
            silence = timestamp - self._phrase_last_voice_at
            enough_voice = self._phrase_voice_seconds >= 0.12
            should_finish = elapsed >= self._phrase_max_duration or (
                enough_voice and silence >= self._phrase_silence
            )
            if not should_finish:
                return

            if self._phrase_frames:
                audio_to_transcribe = np.concatenate(self._phrase_frames)
            generation = self._phrase_generation
            phrase_started_at = self._phrase_started_at
            self._phrase_transcribing = True
            self._reset_phrase_locked()

        if audio_to_transcribe is not None and audio_to_transcribe.size:
            threading.Thread(
                target=self._transcribe_wake_phrase,
                args=(audio_to_transcribe, generation, phrase_started_at),
                daemon=True,
                name="hi-jk-phrase-spotter",
            ).start()

    def _reset_phrase_locked(self):
        self._pre_roll.clear()
        self._phrase_frames = []
        self._phrase_active = False
        self._phrase_started_at = 0.0
        self._phrase_last_voice_at = 0.0
        self._phrase_voice_seconds = 0.0

    def _wake_speech_gate(self) -> float:
        """Return an adaptive dormant VAD threshold for this microphone."""

        configured_floor = max(
            0.0005,
            float(
                getattr(
                    self.cfg.voice,
                    "wake_speech_floor",
                    0.0015,
                )
            ),
        )
        maximum = max(
            configured_floor,
            float(getattr(self.wake_stt, "speech_threshold", 0.005)),
        )
        adaptive = (
            float(getattr(self, "_ambient_noise_floor", 0.00005)) * 8.0
            + configured_floor
        )
        return max(configured_floor, min(maximum, adaptive))

    def _transcribe_wake_phrase(
        self,
        pcm: np.ndarray,
        generation: int,
        phrase_started_at: float = 0.0,
    ):
        detection_started = time.perf_counter()
        try:
            audio = pcm.astype(np.float32) / 32768.0
            wake_lock = getattr(
                self,
                "_wake_stt_lock",
                getattr(self, "_stt_lock", threading.Lock()),
            )
            with wake_lock:
                transcript = self.wake_stt.transcribe_array(
                    audio,
                    # Bias acoustic decoding toward the exact assistant name.
                    hotwords=WAKE_PHRASE,
                ).strip()
                confidence = float(
                    getattr(self.wake_stt, "last_confidence", 0.0)
                )
        except Exception as exc:
            log.error(f"Wake phrase STT error: {exc}")
            transcript = ""
            confidence = 0.0

        with self._phrase_lock:
            is_current_generation = generation == self._phrase_generation
            valid = (
                self._running
                and self.state
                in {
                    VoiceState.LISTENING_WAKE,
                    VoiceState.THINKING,
                    VoiceState.SPEAKING,
                }
                and is_current_generation
            )
            if is_current_generation:
                self._phrase_transcribing = False
                self._ignore_phrase_until = time.monotonic() + 0.10
        if not valid:
            return

        remainder = self.extract_wake_command(transcript)
        minimum_confidence = float(
            getattr(
                self.cfg.voice,
                "wake_min_confidence",
                0.55,
            )
        )
        if remainder is not None and confidence < minimum_confidence:
            log.debug(
                "Exact wake text ignored below confidence threshold "
                f"({confidence:.2f} < {minimum_confidence:.2f})"
            )
            remainder = None
        # Preserve a Nepali/mixed inline command without making every dormant
        # utterance pay for a second transcription. The English exact-phrase
        # result remains the authoritative activation gate.
        if remainder:
            try:
                with wake_lock:
                    multilingual_transcript = (
                        self.wake_stt.transcribe_array(
                            audio,
                            language_hint="auto",
                        ).strip()
                    )
                multilingual_remainder = self.extract_wake_command(
                    multilingual_transcript
                )
                if multilingual_remainder:
                    remainder = multilingual_remainder
            except Exception as exc:
                log.debug(
                    "Multilingual inline wake decode failed: %s",
                    exc,
                )

        if self.state in {VoiceState.THINKING, VoiceState.SPEAKING}:
            if remainder is not None and self.is_stop_command(remainder):
                log_voice(f"Voice interruption recognized: '{transcript}'")
                self.cancel_current("voice")
            elif (
                self.state == VoiceState.SPEAKING
                and self._conversation_active
                and bool(
                    getattr(
                        self.cfg.voice,
                        "barge_in_enabled",
                        True,
                    )
                )
            ):
                barge_minimum = float(
                    getattr(
                        self.cfg.voice,
                        "barge_in_min_confidence",
                        0.70,
                    )
                )
                if confidence < barge_minimum:
                    log.debug(
                        "Possible barge-in ignored below confidence threshold "
                        f"({confidence:.2f} < {barge_minimum:.2f})"
                    )
                    return
                barge_transcript = transcript
                try:
                    with wake_lock:
                        multilingual_barge = (
                            self.wake_stt.transcribe_array(
                                audio,
                                language_hint="auto",
                            ).strip()
                        )
                    if multilingual_barge:
                        barge_transcript = multilingual_barge
                except Exception as exc:
                    log.debug(
                        "Multilingual barge-in decode failed: %s",
                        exc,
                    )
                barge_remainder = self.extract_wake_command(
                    barge_transcript
                )
                candidate = (
                    barge_remainder
                    if barge_remainder is not None
                    else barge_transcript
                ).strip()
                if self.is_stop_command(candidate):
                    self._interrupt_speech_and_listen()
                    return
                echo_threshold = float(
                    getattr(
                        self.cfg.voice,
                        "barge_in_echo_similarity",
                        0.72,
                    )
                )
                if self.is_likely_tts_echo(
                    candidate,
                    self._last_spoken_text,
                    echo_threshold,
                ):
                    log.debug("Alpha TTS echo ignored during barge-in")
                    return
                if candidate:
                    self._interrupt_speech_with_command(candidate)
            elif transcript:
                log.debug(f"Busy speech ignored: '{transcript}'")
            return

        if remainder is None:
            if transcript:
                log.debug(f"Ambient speech ignored: '{transcript}'")
            return

        performance = getattr(self, "performance", None)
        if performance is not None:
            performance.record(
                "wake_detection",
                (time.perf_counter() - detection_started) * 1000,
                True,
                f"confidence={confidence:.2f}",
            )
            if phrase_started_at:
                performance.record(
                    "wake_utterance_total",
                    (time.monotonic() - phrase_started_at) * 1000,
                    True,
                    f"confidence={confidence:.2f}",
                )

        self._conversation_active = bool(
            getattr(
                self.cfg.voice,
                "continuous_conversation",
                True,
            )
        )
        log_voice(
            f'Exact "{WAKE_PHRASE}" wake word recognized '
            f"(confidence={confidence:.2f}): '{transcript}'"
        )
        self._notify_activation("alpha")
        if remainder:
            self._dispatch_command(remainder)
        else:
            # Give immediate audible confirmation. TTS completion naturally
            # opens continuous follow-up capture, so the user can speak the
            # command as soon as "Yes?" finishes.
            self.respond("Yes?")

    # ---- Exclusive command capture ----

    def _on_custom_wake(self, match: WakeWordMatch):
        # A model score alone may be produced by similar sounds. Every wake
        # must pass the exact transcript verifier above, so custom detections
        # are intentionally non-authoritative.
        log.debug(
            "Custom wake score ignored pending exact transcript verification "
            f"({match.confidence:.2f})"
        )

    def _begin_command_capture(self):
        with self._phrase_lock:
            if not self._running or self.state != VoiceState.LISTENING_WAKE:
                return
            self._phrase_generation += 1
            self._phrase_transcribing = False
            self._reset_phrase_locked()
        self._set_state(VoiceState.PREPARING_CMD)
        self._capture_command()

    def _capture_command(self, followup: bool = False):
        """Pause the ambient stream, capture one command, then resume it."""

        def _listen():
            if not self._cmd_lock.acquire(blocking=False):
                log.warning("Command capture already active")
                self._return_to_wake_listening()
                return

            text = ""
            try:
                paused = self.wakeword.pause(timeout=2.0)
                if not paused and self.wakeword.audio_available:
                    log.error(
                        "Ambient microphone did not pause; refusing a competing STT stream"
                    )
                else:
                    # The heavier multilingual model remains unloaded while
                    # dormant. Do not announce "Listening" until it is ready,
                    # otherwise the first words can be lost during model load.
                    self.stt.ensure_loaded()
                    if not self._running:
                        return
                    self._set_state(VoiceState.LISTENING_CMD)

                    def on_level(level: float):
                        self._emit_audio_level(level)

                    if followup:
                        duration = min(
                            30.0,
                            max(
                                3.0,
                                float(
                                    getattr(
                                        self.cfg.voice,
                                        "continuous_followup_timeout",
                                        10.0,
                                    )
                                ),
                            ),
                        )
                    else:
                        duration = min(
                            15.0,
                            max(
                                3.0,
                                float(
                                    getattr(
                                        self.cfg.voice,
                                        "max_speech_duration",
                                        10.0,
                                    )
                                ),
                            ),
                        )
                    command_lock = getattr(
                        self,
                        "_command_stt_lock",
                        getattr(self, "_stt_lock", threading.Lock()),
                    )
                    with command_lock:
                        text = self.stt.transcribe_once_from_mic(
                            duration=duration,
                            on_audio_level=on_level,
                            silence_after_speech=float(
                                getattr(
                                    self.cfg.voice,
                                    "command_silence_seconds",
                                    0.85,
                                )
                            ),
                            ignore_initial_audio=float(
                                getattr(
                                    self.cfg.voice,
                                    "command_audio_guard_seconds",
                                    0.28,
                                )
                            ),
                            initial_prompt=(
                                "Transcribe this English, नेपाली, or mixed "
                                "Nepali-English Windows command exactly in "
                                "the language spoken."
                            ),
                            hotwords=(
                                "open close launch Brave Camera Calculator "
                                "Chrome Edge Notepad Settings Downloads "
                                "volume brightness screenshot search play "
                                "exit quit program application type write "
                                "press enter escape tab scroll up down click "
                                "switch focus copy paste cut undo redo save "
                                "select all new tab close tab refresh minimize "
                                "maximize restore window reminder remind timer "
                                "task priority note remember forget briefing"
                                " खोल खोल्नुहोस् बन्द गर टाइप गर आजको काम "
                                "आवाज स्क्रिनसट रिमाइन्डर नोट"
                            ),
                        )
            except Exception as exc:
                log.error(f"Command STT error: {exc}")
            finally:
                self.wakeword.resume()
                self._cmd_lock.release()
                self._emit_audio_level(0.0)

            if not self._running:
                return
            if text and text.strip():
                command_confidence = float(
                    getattr(self.stt, "last_confidence", 0.0)
                )
                minimum_command_confidence = float(
                    getattr(
                        self.cfg.voice,
                        "command_min_confidence",
                        0.18,
                    )
                )
                if (
                    getattr(self.stt, "engine", "") in {
                        "faster_whisper",
                        "whisper",
                    }
                    and command_confidence < minimum_command_confidence
                ):
                    log_voice(
                        "Low-confidence command ignored "
                        f"({command_confidence:.2f} < "
                        f"{minimum_command_confidence:.2f})"
                    )
                    text = ""
            if text and text.strip():
                decision = validate_spoken_language(
                    text,
                    getattr(self.stt, "last_detected_language", ""),
                    getattr(self.stt, "last_language_probability", 0.0),
                )
                if decision.supported:
                    self._dispatch_command(text.strip())
                else:
                    log_voice(
                        "Unsupported speech language rejected "
                        f"code={decision.code} reason={decision.reason}"
                    )
                    self._conversation_active = True
                    self.respond(UNSUPPORTED_LANGUAGE_MESSAGE)
            else:
                self._conversation_active = False
                log_voice(
                    f'No command speech detected; waiting for "{self.wake_phrase}"'
                )
                self._return_to_wake_listening()

        threading.Thread(
            target=_listen,
            daemon=True,
            name="cmd-listen",
        ).start()

    def _dispatch_command(self, text: str):
        log_voice(f"Command captured: '{text}'")
        if self.is_end_conversation_command(text):
            self._conversation_active = False
        with self._phrase_lock:
            self._phrase_generation += 1
            self._phrase_transcribing = False
            self._reset_phrase_locked()
        for callback in tuple(self._transcript_listeners):
            try:
                callback(text, True)
            except Exception:
                pass
        self._command_queue.put(text)
        self._set_state(VoiceState.THINKING)
        if self.events is not None:
            self.events.publish(
                "speech.command",
                {"language": getattr(self.stt, "last_detected_language", "")},
                source="voice",
            )

    # ---- Command dispatch / microphone readiness ----

    def _loop(self):
        while self._running:
            self._update_microphone_state(time.monotonic())
            try:
                command = self._command_queue.get(timeout=0.10)
            except queue.Empty:
                continue
            try:
                handler = getattr(self, "_cmd_handler", None)
                if handler:
                    handler(command)
                else:
                    log.warning("No command handler registered")
            except Exception as exc:
                log.error(f"Command handler error: {exc}")
                self.respond("Sorry, something went wrong.")

    def _update_microphone_state(self, now: float) -> None:
        ambient_states = {
            VoiceState.STARTING,
            VoiceState.MIC_ERROR,
            VoiceState.LISTENING_WAKE,
        }
        if self.state not in ambient_states:
            self._mic_unavailable_since = 0.0
            return

        if self.wakeword.audio_available:
            self._mic_unavailable_since = 0.0
            if self.state in {VoiceState.STARTING, VoiceState.MIC_ERROR}:
                self._set_state(VoiceState.LISTENING_WAKE)
                log.info(f'Microphone ready; say "{self.wake_phrase}"')
                if getattr(self, "_pending_hotkey_activation", False):
                    self.activate_from_hotkey()
            return

        if not self._mic_unavailable_since:
            self._mic_unavailable_since = now
            return
        if (
            now - self._mic_unavailable_since >= 3.0
            and self.state != VoiceState.MIC_ERROR
        ):
            error = self.wakeword.last_audio_error or "microphone did not open"
            log.error(f"Alpha cannot listen: {error}")
            self._set_state(VoiceState.MIC_ERROR)
