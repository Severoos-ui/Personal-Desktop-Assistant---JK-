"""Example Alpha plugin — respond to a custom phrase."""

from alpha.plugins.manager import PluginBase


class Plugin(PluginBase):
    name = "example_greeter"
    version = "0.1.0"
    author = "Alpha Team"
    description = "Adds a custom 'good morning' response and a 'who made you' easter egg."
    permissions = ["voice_command_hook"]

    def initialize(self) -> bool:
        # Register a custom command with the app's command engine, if available
        if self.app is not None and hasattr(self.app, "cmd_engine"):
            from alpha.commands.registry import CommandDef
            self.app.cmd_engine.register_custom_command(
                "tell me a secret",
                lambda: "I'm afraid I can't do that. Just kidding — you built me!"
            )
        return True

    def shutdown(self):
        pass

    def on_voice_command(self, text: str):
        tl = text.lower()
        if "who made you" in tl or "who built you" in tl or "who created you" in tl:
            return "I was built by you — my creator. I'm Alpha, and I'm here to help."
        if "i love you" in tl:
            return "That means a lot. I'm here whenever you need me."
        return None
