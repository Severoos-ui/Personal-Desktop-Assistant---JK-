"""Plugin system for extensibility. Plugins live in <data_dir>/plugins/ as Python modules."""

import importlib.util
import sys
import threading
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
from abc import ABC, abstractmethod

from alpha.utils.logger import get_logger

log = get_logger("plugins")


class PluginBase(ABC):
    """All plugins should inherit from this."""

    name: str = "unnamed_plugin"
    version: str = "0.1.0"
    author: str = ""
    description: str = ""
    permissions: List[str] = field(default_factory=list)

    def __init__(self, app=None):
        self.app = app
        self.enabled = True

    @abstractmethod
    def initialize(self) -> bool:
        """Called once when plugin is loaded. Return True for success."""
        ...

    def shutdown(self):
        """Called on app exit."""
        pass

    def on_voice_command(self, text: str) -> Optional[str]:
        """Called before command engine; return response to override."""
        return None

    def on_llm_response(self, response: str) -> Optional[str]:
        return None


@dataclass
class LoadedPlugin:
    instance: PluginBase
    path: Path
    metadata: Dict[str, Any] = field(default_factory=dict)
    load_error: Optional[str] = None


class PluginManager:
    """Discovers, loads, and manages plugins from the plugins directory."""

    def __init__(self, plugins_dir: Path, app=None):
        self.plugins_dir = Path(plugins_dir)
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        self.app = app
        self._plugins: Dict[str, LoadedPlugin] = {}
        self._lock = threading.RLock()

    def discover(self) -> List[str]:
        found = []
        for p in self.plugins_dir.iterdir():
            if p.is_dir() and (p / "plugin.py").exists():
                found.append(p.name)
            elif p.suffix == ".py" and p.name.startswith("plugin_"):
                found.append(p.stem)
        return found

    def load_all(self):
        for name in self.discover():
            self.load_plugin(name)

    def load_plugin(self, name: str) -> bool:
        with self._lock:
            if name in self._plugins:
                return self._plugins[name].load_error is None
            try:
                # Locate module
                plugin_dir = self.plugins_dir / name
                plugin_file = plugin_dir / "plugin.py" if plugin_dir.is_dir() else self.plugins_dir / f"{name}.py"
                if not plugin_file.exists():
                    # try direct py name
                    plugin_file = self.plugins_dir / f"{name}.py"
                if not plugin_file.exists():
                    log.warning(f"Plugin {name} not found at {plugin_file}")
                    return False

                spec = importlib.util.spec_from_file_location(f"alpha_plugin_{name}", plugin_file)
                if spec is None or spec.loader is None:
                    raise ImportError(f"Cannot load spec for {name}")
                module = importlib.util.module_from_spec(spec)
                sys.modules[f"alpha_plugin_{name}"] = module
                spec.loader.exec_module(module)

                # Find the PluginBase subclass
                instance = None
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if (isinstance(attr, type) and issubclass(attr, PluginBase)
                            and attr is not PluginBase):
                        instance = attr(app=self.app)
                        break
                if instance is None:
                    # Try plugin class named same as module
                    cls = getattr(module, "Plugin", None)
                    if cls and issubclass(cls, PluginBase):
                        instance = cls(app=self.app)
                if instance is None:
                    raise ImportError(f"No PluginBase subclass found in {name}")

                ok = instance.initialize()
                if ok:
                    self._plugins[name] = LoadedPlugin(
                        instance=instance, path=plugin_file,
                        metadata={"name": instance.name, "version": instance.version}
                    )
                    log.info(f"Plugin loaded: {instance.name} v{instance.version}")
                    return True
                else:
                    self._plugins[name] = LoadedPlugin(
                        instance=instance, path=plugin_file, load_error="init returned False"
                    )
                    log.warning(f"Plugin {name} initialize() returned False")
                    return False
            except Exception as e:
                log.error(f"Failed to load plugin {name}: {e}")
                self._plugins[name] = LoadedPlugin(
                    instance=None, path=self.plugins_dir / name, load_error=str(e)
                )
                return False

    def unload_plugin(self, name: str):
        with self._lock:
            if name in self._plugins:
                p = self._plugins.pop(name)
                if p.instance:
                    try:
                        p.instance.shutdown()
                    except Exception as e:
                        log.error(f"Plugin {name} shutdown error: {e}")

    def get_plugin(self, name: str) -> Optional[PluginBase]:
        p = self._plugins.get(name)
        return p.instance if p else None

    def list_plugins(self) -> List[Dict[str, Any]]:
        out = []
        for name, lp in self._plugins.items():
            out.append({
                "name": name,
                "loaded": lp.instance is not None and lp.load_error is None,
                "error": lp.load_error,
                "version": lp.instance.version if lp.instance else "",
                "description": lp.instance.description if lp.instance else "",
            })
        return out

    # ---- Hook dispatch ----

    def dispatch_voice_command(self, text: str) -> Optional[str]:
        for lp in self._plugins.values():
            if lp.instance and lp.instance.enabled:
                try:
                    r = lp.instance.on_voice_command(text)
                    if r:
                        return r
                except Exception as e:
                    log.error(f"Plugin {lp.instance.name} voice command error: {e}")
        return None

    def dispatch_llm_response(self, text: str) -> str:
        current = text
        for lp in self._plugins.values():
            if lp.instance and lp.instance.enabled:
                try:
                    r = lp.instance.on_llm_response(current)
                    if r:
                        current = r
                except Exception as e:
                    log.error(f"Plugin {lp.instance.name} llm response error: {e}")
        return current

    def shutdown(self):
        for name in list(self._plugins.keys()):
            self.unload_plugin(name)
