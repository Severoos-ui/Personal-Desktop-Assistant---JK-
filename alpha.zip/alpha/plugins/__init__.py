from alpha.plugins.manager import PluginManager, PluginBase
