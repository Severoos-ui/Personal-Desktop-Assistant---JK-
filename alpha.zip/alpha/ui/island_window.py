"""Compact, voice-only Alpha Dynamic Island window.

The window is intentionally small at the native-window level.  Unlike the
legacy overlays, transparent pixels outside the island therefore do not block
mouse input to the desktop.
"""

from __future__ import annotations

import time
from typing import Any

from PySide6.QtCore import (
    QEasingCurve,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    QSize,
    Qt,
    QTimer,
    Signal,
    Slot,
)
from PySide6.QtGui import (
    QColor,
    QFont,
    QGuiApplication,
    QLinearGradient,
    QPainter,
    QPen,
    QRadialGradient,
)
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLayout,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from alpha.ui.waveform import MiniWaveform
from alpha.utils.local_time import nepal_now


class _StatusOrb(QWidget):
    """Small, inexpensive Alpha status orb used by the island."""

    COLORS = {
        "dormant": QColor("#69B7FF"),
        "starting": QColor("#7EA9D8"),
        "armed": QColor("#A98BFF"),
        "listening": QColor("#FF6B9D"),
        "thinking": QColor("#F9D423"),
        "speaking": QColor("#43E97B"),
        "confirming": QColor("#FF9D57"),
        "error": QColor("#FF5F6D"),
    }

    def __init__(self, size: int, parent: QWidget | None = None):
        super().__init__(parent)
        self._phase = "dormant"
        self._audio_level = 0.0
        self.setFixedSize(size, size)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)

    def set_phase(self, phase: str) -> None:
        self._phase = phase if phase in self.COLORS else "dormant"
        self.update()

    def set_audio_level(self, level: float) -> None:
        self._audio_level = max(0.0, min(1.0, float(level)))
        self.update()

    def paintEvent(self, event) -> None:
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        side = min(self.width(), self.height())
        center = self.rect().center()
        color = self.COLORS[self._phase]
        pulse = self._audio_level if self._phase in ("listening", "speaking") else 0.0

        glow_radius = side * (0.48 + pulse * 0.08)
        glow = QRadialGradient(center, glow_radius)
        glow.setColorAt(0.0, QColor(color.red(), color.green(), color.blue(), 90))
        glow.setColorAt(0.62, QColor(color.red(), color.green(), color.blue(), 35))
        glow.setColorAt(1.0, QColor(color.red(), color.green(), color.blue(), 0))
        painter.setPen(Qt.NoPen)
        painter.setBrush(glow)
        painter.drawEllipse(center, glow_radius, glow_radius)

        disc_radius = side * 0.34
        disc = QRadialGradient(
            center.x() - disc_radius * 0.25,
            center.y() - disc_radius * 0.3,
            disc_radius * 1.6,
        )
        disc.setColorAt(0.0, QColor(35, 43, 65, 255))
        disc.setColorAt(1.0, QColor(7, 10, 20, 255))
        painter.setBrush(disc)
        painter.setPen(QPen(color, 1.8 + pulse * 1.4))
        painter.drawEllipse(center, disc_radius, disc_radius)

        font = QFont("Segoe UI", max(7, int(side * 0.19)))
        font.setBold(True)
        painter.setFont(font)
        painter.setPen(QColor(244, 249, 255))
        painter.drawText(self.rect(), Qt.AlignCenter, "A")
        painter.end()


class AlphaIslandWindow(QWidget):
    """Top-center, always-on-top Dynamic Island for the Alpha assistant.

    Public update methods are backed by Qt signals, so they can safely be used
    as callbacks from Alpha's worker threads.
    """

    closed = Signal()
    details_toggled = Signal(bool)
    cancel_requested = Signal()

    _state_received = Signal(object)
    _audio_received = Signal(float)
    _transcript_received = Signal(str, str)
    _dashboard_received = Signal(object)
    _confirmation_received = Signal(str)
    _activation_received = Signal(str)
    _clear_confirmation_received = Signal()

    COMPACT_SIZE = QSize(132, 46)
    ACTIVE_SIZE = QSize(440, 92)
    DETAILS_SIZE = QSize(440, 134)
    TOP_MARGIN = 8

    PHASE_COLORS = {
        "dormant": "#69B7FF",
        "starting": "#7EA9D8",
        "armed": "#A98BFF",
        "listening": "#FF6B9D",
        "thinking": "#F9D423",
        "speaking": "#43E97B",
        "confirming": "#FF9D57",
        "error": "#FF5F6D",
    }

    PHASE_COPY = {
        "dormant": ("Standing by", 'Say "Alpha"'),
        "starting": ("Starting Alpha", "Opening microphone"),
        "armed": ("Wake phrase heard", "Listening for your command"),
        "listening": ("Listening", "Speak your command"),
        "thinking": ("Thinking", 'Tap here or say "stop"'),
        "speaking": ("Alpha is speaking", "Speak anytime to interrupt"),
        "confirming": ("Confirmation needed", "Say yes/no or हो/होइन"),
        "error": ("Microphone unavailable", "Check Windows microphone access"),
    }

    def __init__(self, config: Any = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.config = config
        theme = getattr(config, "theme", None)
        compact_width = max(96, int(getattr(theme, "compact_width", 132)))
        compact_height = max(40, int(getattr(theme, "compact_height", 46)))
        active_width = max(320, int(getattr(theme, "active_width", 440)))
        active_height = max(72, int(getattr(theme, "active_height", 92)))
        details_height = max(
            active_height,
            int(getattr(theme, "details_height", 134)),
        )
        self.COMPACT_SIZE = QSize(compact_width, compact_height)
        self.ACTIVE_SIZE = QSize(active_width, active_height)
        self.DETAILS_SIZE = QSize(active_width, details_height)
        self.TOP_MARGIN = max(0, int(getattr(theme, "top_margin", 8)))
        self._hide_when_idle = bool(getattr(theme, "idle_hidden", True))
        self._active_opacity = max(
            0.55,
            min(1.0, float(getattr(theme, "active_opacity", 0.94))),
        )
        self._phase = "dormant"
        self._details_visible = False
        self._confirmation_active = False
        self._last_speaker = ""
        self._last_transcript = ""
        self._activation_source = ""
        self._activation_notice_ms = 4000
        self._screen = None
        self._screen_signal_connected = False
        self._press_position: QPoint | None = None

        self._build_window()
        self._build_ui()
        self._wire_thread_safe_api()

        self._geometry_animation = QPropertyAnimation(self, b"geometry", self)
        self._geometry_animation.setDuration(210)
        self._geometry_animation.setEasingCurve(QEasingCurve.OutCubic)

        self._clock_timer = QTimer(self)
        self._clock_timer.setInterval(1000)
        self._clock_timer.timeout.connect(self._update_clock)
        self._clock_timer.start()

        self._auto_collapse_timer = QTimer(self)
        self._auto_collapse_timer.setSingleShot(True)
        self._auto_collapse_timer.timeout.connect(self._auto_collapse)

        self._bind_screen(QGuiApplication.primaryScreen())
        self._update_clock()
        self._refresh_content()
        self._apply_presentation(animate=False)

    # ------------------------------------------------------------------
    # Window and layout
    # ------------------------------------------------------------------

    def _build_window(self) -> None:
        self.setWindowTitle("Alpha")
        self.setWindowFlags(
            Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
            | Qt.Tool
            | Qt.NoDropShadowWindowHint
            | Qt.WindowDoesNotAcceptFocus
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFocusPolicy(Qt.NoFocus)
        self.setWindowOpacity(self._active_opacity)
        self.resize(self.COMPACT_SIZE)

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(6, 6, 6, 6)
        root.setSpacing(0)
        # QStackedWidget reports the largest page as its minimum size. The
        # island intentionally becomes much smaller than its active page when
        # dormant, so let the animated top-level geometry be authoritative.
        root.setSizeConstraint(QLayout.SetNoConstraint)

        self._stack = QStackedWidget(self)
        self._stack.setMinimumSize(0, 0)
        self._stack.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self._stack.setStyleSheet("background: transparent; border: none;")
        root.addWidget(self._stack)

        # Dormant presentation: compact Alpha ball plus the Alpha name.
        self._compact_page = QWidget(self._stack)
        compact_layout = QHBoxLayout(self._compact_page)
        compact_layout.setContentsMargins(5, 1, 10, 1)
        compact_layout.setSpacing(5)
        self._compact_orb = _StatusOrb(34, self._compact_page)
        self._compact_name = QLabel("Alpha", self._compact_page)
        self._compact_name.setStyleSheet(
            "color: rgba(247,250,255,235); background: transparent;"
            "font-family: 'Segoe UI'; font-size: 13px; font-weight: 600;"
        )
        compact_layout.addWidget(self._compact_orb)
        compact_layout.addWidget(self._compact_name)
        compact_layout.addStretch(1)
        self._stack.addWidget(self._compact_page)

        # Active presentation.
        self._active_page = QWidget(self._stack)
        active_layout = QVBoxLayout(self._active_page)
        active_layout.setContentsMargins(10, 3, 10, 3)
        active_layout.setSpacing(3)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(9)

        self._active_orb = _StatusOrb(42, self._active_page)
        header.addWidget(self._active_orb)

        title_column = QVBoxLayout()
        title_column.setContentsMargins(0, 1, 0, 1)
        title_column.setSpacing(0)
        self._name_label = QLabel("Alpha", self._active_page)
        self._name_label.setStyleSheet(
            "color: white; background: transparent; font-family: 'Segoe UI';"
            "font-size: 13px; font-weight: 650;"
        )
        self._state_label = QLabel("Standing by", self._active_page)
        self._state_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self._state_label.setStyleSheet(
            "color: rgba(225,233,246,190); background: transparent;"
            "font-family: 'Segoe UI'; font-size: 10px;"
        )
        title_column.addWidget(self._name_label)
        title_column.addWidget(self._state_label)
        header.addLayout(title_column, 1)
        self.waveform = MiniWaveform(self._active_page, bars=24)
        self.waveform.setFixedSize(145, 34)
        header.addWidget(self.waveform)
        active_layout.addLayout(header)

        self._transcript_label = QLabel('Say "Alpha" to talk', self._active_page)
        self._transcript_label.setFixedHeight(24)
        self._transcript_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        self._transcript_label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._transcript_label.setStyleSheet(
            "color: rgba(239,244,252,220);"
            "background: rgba(255,255,255,10);"
            "border: 1px solid rgba(255,255,255,16);"
            "border-radius: 9px; padding: 0 9px;"
            "font-family: 'Segoe UI'; font-size: 10px;"
        )
        active_layout.addWidget(self._transcript_label)

        self._info_row = QWidget(self._active_page)
        info_layout = QHBoxLayout(self._info_row)
        info_layout.setContentsMargins(4, 2, 4, 0)
        info_layout.setSpacing(12)
        self._time_label = self._make_info_label("--:--")
        self._cpu_label = self._make_info_label("CPU --%")
        self._ram_label = self._make_info_label("RAM --%")
        self._battery_label = self._make_info_label("BAT --%")
        info_layout.addWidget(self._time_label)
        info_layout.addStretch(1)
        info_layout.addWidget(self._cpu_label)
        info_layout.addWidget(self._ram_label)
        info_layout.addWidget(self._battery_label)
        active_layout.addWidget(self._info_row)
        self._stack.addWidget(self._active_page)

        # There are no child controls, so the entire island remains one clean
        # click target for showing or hiding the detail row.
        for child in self.findChildren(QWidget):
            if child is not self:
                child.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def _make_info_label(self, text: str) -> QLabel:
        label = QLabel(text, self)
        label.setStyleSheet(
            "color: rgba(215,225,240,190); background: transparent;"
            "font-family: 'Segoe UI'; font-size: 9px; font-weight: 600;"
        )
        return label

    def _wire_thread_safe_api(self) -> None:
        self._state_received.connect(self._apply_state)
        self._audio_received.connect(self._apply_audio_level)
        self._transcript_received.connect(self._apply_transcript)
        self._dashboard_received.connect(self._apply_dashboard_data)
        self._confirmation_received.connect(self._apply_confirmation)
        self._activation_received.connect(self._apply_activation_notice)
        self._clear_confirmation_received.connect(self._apply_clear_confirmation)

    # ------------------------------------------------------------------
    # Thread-safe public API
    # ------------------------------------------------------------------

    def set_state(self, state: Any) -> None:
        """Update from a VoiceState enum or a compatible string/value."""
        self._state_received.emit(state)

    def set_audio_level(self, level: float) -> None:
        """Update the live microphone/speech level in the range 0..1."""
        try:
            value = float(level)
        except (TypeError, ValueError):
            value = 0.0
        self._audio_received.emit(value)

    def add_transcript(self, speaker: str, text: str) -> None:
        """Show the latest user or Alpha transcript preview."""
        self._transcript_received.emit(str(speaker or ""), str(text or ""))

    def set_transcript(self, speaker: str, text: str) -> None:
        """Alias for add_transcript for controller-style integrations."""
        self.add_transcript(speaker, text)

    def set_dashboard_data(self, data: dict | None) -> None:
        """Update CPU, RAM, battery and related compact information."""
        self._dashboard_received.emit(dict(data or {}))

    def show_confirmation(self, message: str) -> None:
        """Keep an expanded, voice-only yes/no confirmation visible."""
        self._confirmation_received.emit(str(message or "Confirmation required."))

    def clear_confirmation(self) -> None:
        """Clear a pending confirmation presentation."""
        self._clear_confirmation_received.emit()

    def activation_notice(self, source: str = "voice") -> None:
        """Show that Alpha recognized its wake word."""
        self._activation_received.emit(str(source or "voice"))

    @Slot()
    def show_window(self) -> None:
        """Show without entering full-screen, taking focus, or activating voice."""
        self._apply_presentation(animate=False)
        if not self.isVisible():
            self.show()
        self.raise_()

    @Slot()
    def show_dormant(self) -> None:
        """Keep dormant mode invisible; it has no manual show path."""
        self._phase = "dormant"
        self._details_visible = False
        self._confirmation_active = False
        self._auto_collapse_timer.stop()
        self._refresh_content()
        self._apply_presentation()
        self.hide_window()

    @Slot()
    def hide_window(self) -> None:
        self.hide()

    @Slot()
    def toggle_show(self) -> None:
        if self.isVisible():
            self.hide_window()

    @Slot(bool)
    def set_details_visible(self, visible: bool) -> None:
        visible = bool(visible)
        if self._details_visible == visible:
            return
        self._details_visible = visible
        self._apply_presentation()
        self.details_toggled.emit(visible)
        if visible and not self._confirmation_active:
            self._auto_collapse_timer.start(8000)

    @Slot()
    def toggle_details(self) -> None:
        self.set_details_visible(not self._details_visible)

    @property
    def phase(self) -> str:
        return self._phase

    @property
    def details_visible(self) -> bool:
        return self._details_visible

    # ------------------------------------------------------------------
    # State application
    # ------------------------------------------------------------------

    @Slot(object)
    def _apply_state(self, state: Any) -> None:
        phase = self._normalise_state(state)

        # Confirmation is a modal voice state from the user's perspective:
        # speaking the prompt or returning to wake listening must not hide it.
        if self._confirmation_active:
            self._apply_audio_phase(phase)
            self.show_window()
            return

        self._phase = phase
        self._details_visible = False

        if phase == "armed":
            self._auto_collapse_timer.start(self._activation_notice_ms)
        elif phase == "dormant":
            self._auto_collapse_timer.stop()
        else:
            self._auto_collapse_timer.stop()

        self._refresh_content()
        self._apply_presentation()
        if self._hide_when_idle and phase in {
            "dormant",
            "starting",
            "error",
        }:
            self.hide_window()
        else:
            self.show_window()

    @Slot(float)
    def _apply_audio_level(self, level: float) -> None:
        value = max(0.0, min(1.0, level))
        self.waveform.set_audio_level(value)
        self._compact_orb.set_audio_level(value)
        self._active_orb.set_audio_level(value)

    @Slot(str, str)
    def _apply_transcript(self, speaker: str, text: str) -> None:
        clean_text = " ".join(text.split())
        if not clean_text:
            return

        self._last_speaker = speaker.strip().lower()
        self._last_transcript = clean_text

        if self._confirmation_active and self._last_speaker == "user":
            first_word = clean_text.lower().strip(" .!?").split(maxsplit=1)[0]
            if first_word in {
                "yes",
                "no",
                "cancel",
                "confirm",
                "हो",
                "होइन",
                "हुन्छ",
                "रद्द",
            }:
                self._confirmation_active = False
                self._phase = "thinking"
                self._details_visible = False

        self._refresh_content()
        self._apply_presentation()
        self.show_window()

    @Slot(object)
    def _apply_dashboard_data(self, data: object) -> None:
        snapshot = data if isinstance(data, dict) else {}
        system = snapshot.get("system") or {}
        battery = snapshot.get("battery") or {}
        performance = snapshot.get("performance") or {}

        self._cpu_label.setText(f"CPU {self._format_percent(system.get('cpu_percent'))}")
        self._ram_label.setText(f"RAM {self._format_percent(system.get('ram_percent'))}")

        battery_text = self._format_percent(battery.get("percent"))
        if battery.get("plugged"):
            battery_text += "+"
        self._battery_label.setText(f"BAT {battery_text}")

        performance_config = getattr(self.config, "performance", None)
        if bool(getattr(performance_config, "debug_dashboard", False)):
            resources = performance.get("resources") or {}
            metrics = performance.get("metrics") or {}
            total = metrics.get("total_response") or {}
            wake = metrics.get("wake_detection") or {}
            self.setToolTip(
                "Alpha diagnostics\n"
                f"Wake: {wake.get('last_ms', 0)} ms\n"
                f"Response: {total.get('last_ms', 0)} ms\n"
                f"Process RAM: {resources.get('ram_mb', 0)} MB\n"
                f"Threads: {resources.get('threads', 0)}"
            )

    @Slot(str)
    def _apply_confirmation(self, message: str) -> None:
        self._confirmation_active = True
        self._phase = "confirming"
        self._details_visible = True
        self._last_speaker = "alpha"
        self._last_transcript = " ".join(message.split())
        self._auto_collapse_timer.stop()
        self._refresh_content()
        self._apply_presentation()
        self.show_window()

    @Slot()
    def _apply_clear_confirmation(self) -> None:
        if not self._confirmation_active:
            return
        self._confirmation_active = False
        self._phase = "dormant"
        self._details_visible = False
        self._refresh_content()
        self._apply_presentation()

    @Slot(str)
    def _apply_activation_notice(self, source: str) -> None:
        source_key = source.strip().lower().replace("-", "_").replace(" ", "_")
        source_copy = {
            "alpha": "Alpha heard",
            "hotkey": "Alt+F11 activated",
        }
        if source_key not in source_copy:
            return
        self._activation_source = source_copy[source_key]
        self._confirmation_active = False
        self._phase = "armed"
        self._details_visible = False
        self._auto_collapse_timer.start(self._activation_notice_ms)
        self._refresh_content()
        self._apply_presentation()
        self.show_window()

    def _normalise_state(self, state: Any) -> str:
        """Convert VoiceState values into compact presentation phases."""
        name = getattr(state, "name", "")
        value = getattr(state, "value", "")
        raw = " ".join((str(name), str(value), str(state))).lower()
        token = raw.replace("-", "_").replace(" ", "_")

        if "armed" in token:
            return "armed"
        if "starting" in token:
            return "starting"
        if "preparing_cmd" in token or "preparing_command" in token:
            return "armed"
        if "listening_cmd" in token or "listening_command" in token:
            return "listening"
        if "thinking" in token or "processing" in token:
            return "thinking"
        if "speaking" in token or "responding" in token:
            return "speaking"
        if "confirm" in token:
            return "confirming"
        if "error" in token or "offline" in token:
            return "error"
        # LISTENING_WAKE means the always-on wake detector is running. It is
        # intentionally compact until the wake phrase or a command arrives.
        if "listening_wake" in token or "idle" in token or "dormant" in token:
            return "dormant"
        if "listening" in token:
            return "listening"
        return "dormant"

    def _apply_audio_phase(self, voice_phase: str) -> None:
        waveform_phase = {
            "listening": "listening",
            "thinking": "thinking",
            "speaking": "speaking",
        }.get(voice_phase, "listening")
        self.waveform.set_state(waveform_phase)

    def _refresh_content(self) -> None:
        title, hint = self.PHASE_COPY[self._phase]
        if self._phase == "armed" and self._activation_source:
            hint = self._activation_source

        color = self.PHASE_COLORS[self._phase]
        self._state_label.setText(title)
        self._state_label.setStyleSheet(
            f"color: {color}; background: transparent;"
            "font-family: 'Segoe UI'; font-size: 10px; font-weight: 600;"
        )

        if self._last_transcript:
            speaker = "You" if self._last_speaker == "user" else "Alpha"
            preview = f"{speaker} - {self._last_transcript}"
        else:
            preview = hint
        self._transcript_label.setText(preview)
        self._transcript_label.setToolTip(preview)

        self._compact_orb.set_phase(self._phase)
        self._active_orb.set_phase(self._phase)
        waveform_phase = {
            "starting": "idle",
            "armed": "armed",
            "listening": "listening",
            "thinking": "thinking",
            "speaking": "speaking",
            "confirming": "listening",
            "error": "idle",
            "dormant": "idle",
        }[self._phase]
        self.waveform.set_state(waveform_phase)
        self.update()

    # ------------------------------------------------------------------
    # Presentation and positioning
    # ------------------------------------------------------------------

    def _target_size(self) -> QSize:
        if self._details_visible or self._confirmation_active:
            return self.DETAILS_SIZE
        if self._phase == "dormant":
            return self.COMPACT_SIZE
        return self.ACTIVE_SIZE

    def _apply_presentation(self, animate: bool = True) -> None:
        compact = self._phase == "dormant" and not self._details_visible
        self._stack.setCurrentWidget(self._compact_page if compact else self._active_page)
        self._info_row.setVisible(self._details_visible or self._confirmation_active)
        self._set_waveform_running(not compact and self.isVisible())

        target_rect = self._target_geometry(self._target_size())
        if not animate or not self.isVisible() or self.geometry().isNull():
            self._geometry_animation.stop()
            self.setGeometry(target_rect)
            return

        self._geometry_animation.stop()
        self._geometry_animation.setStartValue(self.geometry())
        self._geometry_animation.setEndValue(target_rect)
        self._geometry_animation.start()

    def _target_geometry(self, size: QSize) -> QRect:
        screen = self._screen or QGuiApplication.primaryScreen()
        if screen is None:
            return QRect(self.x(), self.y(), size.width(), size.height())
        available = screen.availableGeometry()
        x = available.x() + (available.width() - size.width()) // 2
        y = available.y() + self.TOP_MARGIN
        return QRect(x, y, size.width(), size.height())

    def _bind_screen(self, screen) -> None:
        if screen is None or screen is self._screen:
            return
        if self._screen is not None:
            try:
                self._screen.availableGeometryChanged.disconnect(self._screen_geometry_changed)
                self._screen.geometryChanged.disconnect(self._screen_geometry_changed)
            except (RuntimeError, TypeError):
                pass
        self._screen = screen
        self._screen.availableGeometryChanged.connect(self._screen_geometry_changed)
        self._screen.geometryChanged.connect(self._screen_geometry_changed)

    @Slot()
    def _screen_geometry_changed(self, *_args) -> None:
        self._apply_presentation(animate=False)

    @Slot(object)
    def _screen_changed(self, screen) -> None:
        self._bind_screen(screen)
        self._apply_presentation(animate=False)

    def _set_waveform_running(self, running: bool) -> None:
        # MiniWaveform predates the compact window and owns its timer. Pausing
        # it while collapsed prevents a hidden 25 FPS animation from consuming
        # laptop battery.
        timer = getattr(self.waveform, "_timer", None)
        if timer is None:
            return
        if running:
            if not timer.isActive():
                timer.start(40)
        else:
            timer.stop()
            self.waveform.set_audio_level(0.0)

    @Slot()
    def _auto_collapse(self) -> None:
        self._details_visible = False
        if self._phase == "armed":
            self._phase = "dormant"
            self._activation_source = ""
        self._refresh_content()
        self._apply_presentation()

    @Slot()
    def _update_clock(self) -> None:
        self._time_label.setText(
            nepal_now().strftime("%I:%M %p").lstrip("0")
        )

    @staticmethod
    def _format_percent(value: Any) -> str:
        try:
            return f"{max(0, min(100, int(round(float(value)))))}%"
        except (TypeError, ValueError):
            return "--%"

    # ------------------------------------------------------------------
    # QWidget events
    # ------------------------------------------------------------------

    def showEvent(self, event) -> None:
        super().showEvent(event)
        handle = self.windowHandle()
        if handle is not None:
            self._bind_screen(handle.screen())
            if not self._screen_signal_connected:
                handle.screenChanged.connect(self._screen_changed)
                self._screen_signal_connected = True
        self._set_waveform_running(self._stack.currentWidget() is self._active_page)
        QTimer.singleShot(0, lambda: self._apply_presentation(animate=False))

    def hideEvent(self, event) -> None:
        self._set_waveform_running(False)
        super().hideEvent(event)

    def closeEvent(self, event) -> None:
        self.closed.emit()
        super().closeEvent(event)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self._press_position = event.position().toPoint()
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton and self._press_position is not None:
            distance = (event.position().toPoint() - self._press_position).manhattanLength()
            self._press_position = None
            if distance <= 6:
                if self._phase in {"thinking", "speaking"}:
                    self.cancel_requested.emit()
                else:
                    self.toggle_details()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def paintEvent(self, event) -> None:
        del event
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = QRectF(self.rect()).adjusted(6, 6, -6, -6)
        radius = rect.height() / 2 if self._target_size() == self.COMPACT_SIZE else 23
        color = QColor(self.PHASE_COLORS[self._phase])

        painter.setBrush(Qt.NoBrush)
        painter.setPen(QPen(QColor(color.red(), color.green(), color.blue(), 48), 6))
        painter.drawRoundedRect(rect.adjusted(2, 2, -2, -2), radius, radius)

        background = QLinearGradient(rect.topLeft(), rect.bottomLeft())
        background.setColorAt(0.0, QColor(25, 31, 48, 218))
        background.setColorAt(0.55, QColor(13, 17, 29, 224))
        background.setColorAt(1.0, QColor(7, 10, 19, 228))
        painter.setBrush(background)
        painter.setPen(QPen(QColor(color.red(), color.green(), color.blue(), 115), 1))
        painter.drawRoundedRect(rect, radius, radius)

        highlight = QLinearGradient(rect.topLeft(), rect.topRight())
        highlight.setColorAt(0.0, QColor(255, 255, 255, 8))
        highlight.setColorAt(0.5, QColor(255, 255, 255, 32))
        highlight.setColorAt(1.0, QColor(255, 255, 255, 8))
        painter.setBrush(Qt.NoBrush)
        painter.setPen(QPen(highlight, 1))
        painter.drawRoundedRect(rect.adjusted(1, 1, -1, -1), radius - 1, radius - 1)
        painter.end()
