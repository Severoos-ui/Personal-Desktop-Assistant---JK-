"""Compact animated waveform for Alpha's Dynamic Island."""

import math
from collections import deque

from PySide6.QtCore import Qt, QTimer, QRectF
from PySide6.QtGui import QColor, QLinearGradient, QPainter
from PySide6.QtWidgets import QWidget


STATE_COLORS = {
    "idle": QColor("#5AA8F0"),
    "armed": QColor("#A98BFF"),
    "listening": QColor("#FF6B9D"),
    "thinking": QColor("#F9D423"),
    "speaking": QColor("#43E97B"),
}


class MiniWaveform(QWidget):
    """Slim Dynamic Island bars that react to microphone audio."""

    def __init__(self, parent=None, bars: int = 28):
        super().__init__(parent)
        self._bars = bars
        self._levels = deque([0.0] * bars, maxlen=bars)
        self._state = "idle"
        self._target = 0.0
        self._phase = 0.0
        self.setMinimumHeight(28)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setStyleSheet("background: transparent;")
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(40)

    def set_state(self, state: str):
        state = state.lower()
        self._state = state if state in STATE_COLORS else "idle"

    def set_audio_level(self, level: float):
        self._target = max(0.0, min(1.0, float(level)))

    def _tick(self):
        self._phase += 0.2
        level = self._target
        self._target *= 0.82
        if self._state in ("idle", "armed"):
            level = math.sin(self._phase * 0.4) * 0.06 + 0.08
        elif self._state == "thinking":
            level = max(
                level,
                (math.sin(self._phase * 3) * 0.5 + 0.5) * 0.7,
            )
        elif self._state == "speaking" and level < 0.1:
            level = (math.sin(self._phase * 2 + 1) * 0.5 + 0.5) * 0.5
        smoothed = self._levels[-1] * 0.55 + level * 0.45
        self._levels.append(smoothed)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        width, height = self.width(), self.height()
        color = STATE_COLORS[self._state]
        bar_width = max(2.0, width / self._bars - 2)
        gap = (width - bar_width * self._bars) / max(1, self._bars - 1)
        midpoint = height / 2
        for index, level in enumerate(self._levels):
            bar_height = max(2.0, level * height * 0.95)
            x = index * (bar_width + gap)
            gradient = QLinearGradient(
                x,
                midpoint - bar_height / 2,
                x,
                midpoint + bar_height / 2,
            )
            gradient.setColorAt(0, color.lighter(140))
            gradient.setColorAt(0.5, color)
            gradient.setColorAt(1, color.darker(130))
            painter.setBrush(gradient)
            painter.setPen(Qt.NoPen)
            rect = QRectF(
                x,
                midpoint - bar_height / 2,
                bar_width,
                bar_height,
            )
            painter.drawRoundedRect(rect, bar_width / 2, bar_width / 2)
        painter.end()
