"""Alpha's compact desktop interface."""

from alpha.ui.island_window import AlphaIslandWindow

__all__ = ["AlphaIslandWindow"]
