"""Extensible command registry for ALPHA."""

import re
import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum


class ParamType(Enum):
    STRING = "string"
    INT = "int"
    FLOAT = "float"
    BOOL = "bool"
    PATH = "path"
    APP = "app"
    WEBSITE = "website"
    QUERY = "query"


@dataclass
class ParamDef:
    name: str
    type: ParamType = ParamType.STRING
    required: bool = False
    default: Any = None
    description: str = ""
    synonyms: List[str] = field(default_factory=list)


@dataclass
class CommandDef:
    name: str
    handler: Callable
    description: str = ""
    category: str = "general"
    params: List[ParamDef] = field(default_factory=list)
    triggers: List[str] = field(default_factory=list)  # phrases that trigger this
    patterns: List[str] = field(default_factory=list)   # regex patterns
    dangerous: bool = False
    requires_confirmation: bool = False
    examples: List[str] = field(default_factory=list)
    platform: str = "all"  # all, windows, linux, darwin, android

    def __post_init__(self):
        # Auto-generate WORD-BOUNDARY ANCHORED regex patterns from triggers if none provided.
        # Patterns are anchored at the START of the cleaned input to prevent spurious
        # substring matches (e.g. "yo" matching inside "you").
        if not self.patterns and self.triggers:
            for trigger in self.triggers:
                words = trigger.split()
                if len(words) == 1:
                    # Single word: whole word at start
                    pattern = r"\b" + re.escape(trigger) + r"\b"
                else:
                    pattern = r"\s+".join(re.escape(w) for w in words)
                self.patterns.append(pattern)


class CommandRegistry:
    """Thread-safe registry of all available commands."""

    def __init__(self):
        self._commands: Dict[str, CommandDef] = {}
        self._category_index: Dict[str, List[str]] = {}
        self._alias_map: Dict[str, str] = {}

    def register(self, cmd: CommandDef):
        self._commands[cmd.name] = cmd
        self._category_index.setdefault(cmd.category, []).append(cmd.name)
        for trigger in cmd.triggers:
            self._alias_map[trigger.lower()] = cmd.name
            # also store normalized forms
            norm = trigger.lower().replace(" ", "")
            if norm != trigger.lower():
                self._alias_map[norm] = cmd.name

    def unregister(self, name: str):
        if name in self._commands:
            cmd = self._commands.pop(name)
            if cmd.category in self._category_index:
                self._category_index[cmd.category] = [
                    n for n in self._category_index[cmd.category] if n != name
                ]

    def get(self, name: str) -> Optional[CommandDef]:
        return self._commands.get(name)

    def all(self) -> List[CommandDef]:
        return list(self._commands.values())

    def by_category(self, category: str) -> List[CommandDef]:
        names = self._category_index.get(category, [])
        return [self._commands[n] for n in names if n in self._commands]

    def find_matches(self, text: str) -> List[Tuple[CommandDef, float, Dict[str, Any]]]:
        """
        Find commands matching the input text.
        Returns list of (CommandDef, confidence, extracted_params).
        Matching priority:
          1. Anchored regex patterns (start of text after wake word)
          2. Triggers at the start of text
          3. Multi-word keyword overlap (must include ALL trigger words)
          4. Exact single-word (chat) matches only when input is just that word
        """
        text_stripped = text.strip()
        text_lower = text_stripped.lower()
        matches = []

        # Strip only Alpha's exact wake word or a polite request prefix. The
        # voice gate is authoritative; this keeps direct command parsing
        # consistent with it without turning greetings into commands.
        prefix_pattern = re.compile(
            r"^(?:(?:alpha)"
            r"(?=$|[\s,.:;!?\-])[\s,.:;!?\-]*|"
            r"(?:(?:can|could|would|will)\s+you\s+)?please\s+|"
            r"(?:can|could|would|will)\s+you\s+)",
            re.IGNORECASE,
        )
        prefix_match = prefix_pattern.match(text_stripped)
        text_clean_preserved = (
            text_stripped[prefix_match.end():].strip()
            if prefix_match
            else text_stripped
        )
        text_clean_lower = text_clean_preserved.lower()

        for cmd in self._commands.values():
            best_conf = 0.0
            best_params: Dict[str, Any] = {}
            best_match_start = None  # earlier matches are better

            # 1) Regex patterns - anchored at start of cleaned text
            for pattern in cmd.patterns:
                try:
                    # Automation patterns must begin the cleaned utterance.
                    # Substring matching could turn background speech such as
                    # "I do not want to open it" into an unintended action.
                    pat = f"^{pattern}"
                    flags = re.IGNORECASE
                    m = re.search(pat, text_clean_lower, flags)
                    if m:
                        conf = 0.9
                        groups = m.groupdict()
                        params_out = {}
                        if groups:
                            # Preserve case for dictated text and app names.
                            m_pres = re.search(
                                pat,
                                text_clean_preserved,
                                flags,
                            )
                            preserved_groups = (
                                m_pres.groupdict() if m_pres else groups
                            )
                            for k, v in preserved_groups.items():
                                if v is not None:
                                    params_out[k] = v.strip(" ,.;!?")
                            conf += 0.08
                        end_in_preserved = m.end()
                        trailing = text_clean_preserved[
                            end_in_preserved:
                        ].strip(" ,.;!?")
                        if trailing and not params_out:
                            for p in cmd.params:
                                if p.type in (
                                    ParamType.QUERY,
                                    ParamType.STRING,
                                    ParamType.PATH,
                                    ParamType.APP,
                                    ParamType.WEBSITE,
                                ):
                                    params_out[p.name] = trailing
                                    conf += 0.02
                                    break
                        residual = len(text_clean_lower) - m.end()
                        if residual < 3:
                            conf += 0.05
                        if conf > best_conf:
                            best_conf = conf
                            best_params = params_out
                            best_match_start = m.start()
                except re.error:
                    continue

            # 2) Multi-word trigger prefix match (trigger words appear at start)
            if best_conf < 0.85:
                for trigger in cmd.triggers:
                    trigger_l = trigger.lower().strip()
                    t_words = trigger_l.split()
                    is_chat = cmd.category == "chat"

                    # Only match trigger if it actually appears at START of cleaned text
                    # as a whole-phrase prefix (not partial word match)
                    # Build a pattern that matches the trigger as a whole phrase
                    trig_pat = r"^\s*" + r"\s+".join(re.escape(w) for w in t_words) + r"\b"
                    if not re.search(trig_pat, text_clean_lower):
                        continue

                    # For chat category, only accept if this match would be the primary
                    # intent (i.e. the match essentially covers the whole input or leaves
                    # only trailing filler words like "please" or punctuation)
                    after_match = re.sub(trig_pat, "", text_clean_lower, count=1).strip(" ,.;!?")
                    if is_chat:
                        # Only accept single-word chat greetings when the whole input is just that word
                        if len(t_words) == 1 and after_match and not re.match(r"^(please|pls|now)\s*$", after_match):
                            continue
                        # Multi-word chat phrases (like "good morning"): allow no trailing words
                        # or just a name
                        if after_match and len(after_match.split()) > 2:
                            continue

                    conf = 0.85 if not after_match else 0.78
                    # Extract arguments
                    m_trig = re.search(trig_pat, text_clean_lower)
                    idx = m_trig.start() if m_trig else 0
                    match_end = m_trig.end() if m_trig else len(trigger_l)
                    args_str_orig = text_clean_preserved[match_end:].strip(" ,.;!?")
                    if args_str_orig:
                        for p in cmd.params:
                            if p.type in (ParamType.QUERY, ParamType.STRING, ParamType.PATH, ParamType.APP):
                                best_params[p.name] = args_str_orig
                                break
                    if best_conf < conf:
                        best_conf = conf
                        best_match_start = idx

            # 3) Fallback: all trigger keywords appear as WHOLE WORDS at start (multi-word only)
            if best_conf == 0 and len(cmd.triggers) > 0:
                # Pick the longest trigger to maximize specificity
                trigger = max(cmd.triggers, key=len)
                t_words = trigger.lower().split()
                if len(t_words) >= 2:
                    # Use word boundary regex to ensure whole-word matching
                    first_word_pat = re.compile(rf"^\s*{re.escape(t_words[0])}\b", re.IGNORECASE)
                    if first_word_pat.search(text_clean_lower):
                        all_present = all(
                            re.search(rf"\b{re.escape(w)}\b", text_clean_lower) for w in t_words
                        )
                        if all_present:
                            best_conf = 0.5
                            for p in cmd.params:
                                if p.type in (ParamType.QUERY, ParamType.STRING):
                                    idx = text_clean_lower.rfind(t_words[-1])
                                    if idx >= 0:
                                        best_params[p.name] = text_clean_preserved[idx + len(t_words[-1]):].strip(" ,.;!?")
                                    break

            if best_conf > 0:
                # Score also rewards: longer trigger match, earlier match, fewer residuals
                specificity = max((len(t.split()) for t in cmd.triggers), default=1)
                matches.append((cmd, best_conf, best_params, specificity, best_match_start or 0))

        # Sort by: confidence desc, specificity desc (longest triggers first), match position asc
        matches.sort(key=lambda x: (-x[1], -x[3], x[4]))
        return [(c, cf, p) for c, cf, p, _, _ in matches]

    def decorator(self, name: str, **kwargs):
        """Decorator for registering commands from functions."""
        def deco(func: Callable) -> Callable:
            # Auto-extract params from function signature
            params = []
            sig = inspect.signature(func)
            for pname, param in sig.parameters.items():
                if pname in ("self", "ctx"):
                    continue
                ptype = ParamType.STRING
                ann = param.annotation
                if ann is int:
                    ptype = ParamType.INT
                elif ann is float:
                    ptype = ParamType.FLOAT
                elif ann is bool:
                    ptype = ParamType.BOOL
                default = param.default if param.default is not inspect.Parameter.empty else None
                params.append(ParamDef(
                    name=pname, type=ptype,
                    required=(param.default is inspect.Parameter.empty),
                    default=default,
                ))
            cmd = CommandDef(
                name=name, handler=func,
                params=params, **kwargs
            )
            self.register(cmd)
            return func
        return deco
