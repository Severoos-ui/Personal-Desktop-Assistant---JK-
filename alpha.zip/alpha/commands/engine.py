"""Command engine: NLU parsing, execution, multi-command, confirmation."""

import re
import time
import threading
import shlex
from typing import Any, Dict, List, Optional, Callable, Tuple
from dataclasses import dataclass, field
from enum import Enum
from concurrent.futures import ThreadPoolExecutor

from alpha.utils.logger import get_logger, log_cmd
from alpha.commands.registry import CommandRegistry, CommandDef

log = get_logger("cmd.engine")


class CommandStatus(Enum):
    PENDING = "pending"
    CONFIRMATION_REQUIRED = "confirmation_required"
    EXECUTING = "executing"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    UNKNOWN = "unknown"


@dataclass
class CommandResult:
    status: CommandStatus
    command_name: str = ""
    spoken_response: str = ""
    data: Any = None
    error: Optional[str] = None
    requires_confirmation: bool = False
    confirmation_message: str = ""
    execution_time_ms: float = 0.0
    timestamp: float = field(default_factory=time.time)


# Multi-command splitters
SPLIT_WORDS = [
    r"\band\s+then\b", r"\bthen\b", r"\bafter that\b", r"\bnext\b",
    r"\band\b", r"\balso\b", r";", r",",
]
SPLIT_RE = re.compile("|".join(SPLIT_WORDS), re.IGNORECASE)


class CommandEngine:
    """
    Parses natural language into commands, handles confirmations,
    executes commands, supports multi-command and history.
    """

    _PLANNED_ACTION_ALIASES = {
        "open_app": "open_smart",
        "launch_app": "open_smart",
        "close_program": "close_app",
        "open_website": "open_site",
        "search": "search_google",
        "play_youtube": "play_youtube_music",
    }
    _PLANNED_PARAM_ALIASES = {
        "open_smart": {"app": "target", "name": "target"},
        "open_site": {"url": "site", "website": "site"},
        "close_app": {"program": "app", "name": "app"},
        "search_google": {"text": "query", "term": "query"},
        "search_youtube": {"text": "query", "term": "query"},
    }

    def __init__(self, registry: CommandRegistry, confirmation_callback: Optional[Callable] = None):
        self.registry = registry
        self.history: List[Tuple[str, CommandResult]] = []
        self._history_limit = 500
        self._aliases: Dict[str, str] = {}
        self._custom_commands: Dict[str, Callable] = {}
        self._confirmation_cb = confirmation_callback
        self._pending_confirmation: Optional[Tuple[CommandDef, Dict[str, Any]]] = None
        self._executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="cmd-exec")
        self._lock = threading.Lock()
        self._pre_hooks: List[Callable[[CommandDef, Dict[str, Any]], Optional[CommandResult]]] = []
        self._post_hooks: List[Callable[[CommandDef, Dict[str, Any], CommandResult], None]] = []

    # ---- Public API ----

    def add_pre_hook(self, cb: Callable):
        self._pre_hooks.append(cb)

    def add_post_hook(self, cb: Callable):
        self._post_hooks.append(cb)

    def add_alias(self, alias: str, expansion: str):
        self._aliases[alias.lower().strip()] = expansion

    def register_custom_command(self, phrase: str, action_fn: Callable):
        self._custom_commands[phrase.lower().strip()] = action_fn

    def parse(self, text: str) -> List[Tuple[CommandDef, Dict[str, Any], float]]:
        """Parse input text into a list of (CommandDef, params, confidence)."""
        text = self._expand_aliases(text)
        parts = self._split_multi(text)
        results = []
        for part in parts:
            part = part.strip()
            if not part:
                continue
            # Check custom commands
            matched_custom = False
            for phrase, fn in self._custom_commands.items():
                if phrase in part.lower():
                    # Wrap in a synthetic command
                    from alpha.commands.registry import ParamDef
                    cmd = CommandDef(
                        name=f"custom_{phrase[:20]}", handler=fn,
                        description=f"Custom command: {phrase}",
                        category="custom",
                        triggers=[phrase],
                    )
                    results.append((cmd, {}, 0.9))
                    matched_custom = True
                    break
            if matched_custom:
                continue
            matches = self.registry.find_matches(part)
            if matches:
                cmd, conf, params = matches[0]
                if conf >= 0.3:
                    # Coerce params
                    params = self._coerce_params(cmd, params, part)
                    results.append((cmd, params, conf))
                else:
                    results.append((None, {"_text": part}, 0.0))
            else:
                results.append((None, {"_text": part}, 0.0))
        return results

    def execute(self, text: str, context: Optional[Dict] = None) -> List[CommandResult]:
        """Parse and execute a command string, returning results."""
        results = []
        parsed = self.parse(text)
        for cmd, params, conf in parsed:
            if cmd is None:
                # Pass through to LLM
                r = CommandResult(
                    status=CommandStatus.UNKNOWN,
                    spoken_response=params.get("_text", ""),
                )
                results.append(r)
                continue
            r = self._execute_single(cmd, params, context or {})
            results.append(r)
            # Stop chain if dangerous and waiting for confirmation
            if r.status == CommandStatus.CONFIRMATION_REQUIRED:
                break
            # Short delay between chained commands
            time.sleep(0.45)
        self._add_history(text, results)
        return results

    def execute_planned(
        self,
        action: str,
        params: Optional[Dict[str, Any]] = None,
        context: Optional[Dict] = None,
    ) -> CommandResult:
        """Execute one LLM-planned action through the registered allowlist.

        The model never receives a callable and cannot bypass command
        confirmation. Unknown actions/parameters are rejected before reaching
        a handler.
        """

        requested_action = str(action or "").strip()
        normalized_action = re.sub(
            r"[^a-z0-9_]+",
            "_",
            requested_action.casefold(),
        ).strip("_")
        normalized_action = self._PLANNED_ACTION_ALIASES.get(
            normalized_action,
            normalized_action,
        )
        cmd = self.registry.get(normalized_action)
        if cmd is None:
            result = CommandResult(
                status=CommandStatus.FAILED,
                command_name=normalized_action,
                error="Action is not in Alpha's command allowlist.",
                spoken_response=(
                    "I cannot safely execute that action because it is not "
                    "in my local command allowlist."
                ),
            )
            self._add_history(f"planned:{requested_action}", [result])
            return result

        incoming = {
            str(key).strip(): value
            for key, value in dict(params or {}).items()
        }
        aliases = self._PLANNED_PARAM_ALIASES.get(cmd.name, {})
        for old_name, new_name in aliases.items():
            if old_name in incoming and new_name not in incoming:
                incoming[new_name] = incoming[old_name]

        safe_params: Dict[str, Any] = {}
        for definition in cmd.params:
            if definition.name in incoming:
                raw_value = incoming[definition.name]
            elif definition.default is not None:
                raw_value = definition.default
            elif definition.required:
                result = CommandResult(
                    status=CommandStatus.FAILED,
                    command_name=cmd.name,
                    error=f"Missing required parameter: {definition.name}",
                    spoken_response=(
                        f"I need {definition.name.replace('_', ' ')} before "
                        "I can do that."
                    ),
                )
                self._add_history(f"planned:{cmd.name}", [result])
                return result
            else:
                continue

            try:
                type_name = getattr(
                    definition.type,
                    "value",
                    str(definition.type),
                )
                if type_name == "int":
                    value = int(float(raw_value))
                elif type_name == "float":
                    value = float(raw_value)
                elif type_name == "bool":
                    value = (
                        raw_value
                        if isinstance(raw_value, bool)
                        else str(raw_value).strip().casefold()
                        in {"1", "true", "yes", "on"}
                    )
                else:
                    value = str(raw_value).strip()
                safe_params[definition.name] = value
            except (TypeError, ValueError):
                result = CommandResult(
                    status=CommandStatus.FAILED,
                    command_name=cmd.name,
                    error=f"Invalid parameter: {definition.name}",
                    spoken_response=(
                        f"I could not understand the "
                        f"{definition.name.replace('_', ' ')} value."
                    ),
                )
                self._add_history(f"planned:{cmd.name}", [result])
                return result

        log_cmd(f"Executing allowlisted plan: {cmd.name} params={safe_params}")
        result = self._execute_single(
            cmd,
            safe_params,
            context or {},
        )
        self._add_history(f"planned:{cmd.name}", [result])
        return result

    def confirm(self, approved: bool):
        """Respond to a pending confirmation."""
        if not self._pending_confirmation:
            return CommandResult(status=CommandStatus.CANCELLED, error="No pending confirmation")
        cmd, params = self._pending_confirmation
        self._pending_confirmation = None
        if not approved:
            return CommandResult(status=CommandStatus.CANCELLED, command_name=cmd.name,
                                 spoken_response="Cancelled.")
        return self._execute_single(cmd, params, {}, skip_confirm=True)

    # ---- Internals ----

    def _expand_aliases(self, text: str) -> str:
        for alias, expansion in self._aliases.items():
            text = re.sub(rf"\b{re.escape(alias)}\b", expansion, text, flags=re.IGNORECASE)
        return text

    def _split_multi(self, text: str) -> List[str]:
        # Split on coordinating words but be careful with contexts like "open and close"
        # Preserve registered compound intents which need the whole sentence.
        if re.fullmatch(
            r"\s*(?:open|launch|start)\s+(?:the\s+)?"
            r"(?:brave(?:\s+browser)?|(?:google\s+)?chrome|"
            r"(?:microsoft\s+)?edge|firefox)"
            r"(?:\s+browser)?\s+(?:and\s+then|and|then)\s+"
            r"(?:play|start)\s+.+?\s+"
            r"(?:on|in|within|with\s+in)\s+(?:youtube|you\s+tube)\s*",
            text,
            flags=re.IGNORECASE,
        ):
            return [text]

        # Simple heuristic: split on strong separators first
        parts = [text]
        for pat in [r"\s+and\s+then\s+", r"\s+then\s+", r"\s+after that\s+", r";\s*", r",\s+and\s+"]:
            new_parts = []
            for p in parts:
                new_parts.extend(re.split(pat, p, flags=re.IGNORECASE))
            parts = new_parts

        # Split a plain "and" only when the next clause starts with a clear
        # action verb. This keeps phrases such as "rock and roll" intact.
        action_clause = re.compile(
            r"\s+and\s+(?="
            r"(?:open|launch|start|run|close|exit|quit|type|write|"
            r"press|hit|scroll|click|switch|focus|bring|minimize|"
            r"maximize|restore|search|play|take|set|turn|mute|"
            r"unmute|read|describe|summarize|analyze)\b"
            r")",
            re.IGNORECASE,
        )
        expanded = []
        for part in parts:
            expanded.extend(action_clause.split(part))
        parts = expanded
        return [p for p in parts if p.strip()]

    def _coerce_params(self, cmd: CommandDef, params: Dict[str, Any], raw_text: str) -> Dict[str, Any]:
        out = dict(params)
        # Fill in defaults
        for p in cmd.params:
            if p.name not in out and p.default is not None:
                out[p.name] = p.default
        return out

    def _execute_single(self, cmd: CommandDef, params: Dict[str, Any],
                        context: Dict, skip_confirm: bool = False) -> CommandResult:
        start = time.time()
        # Confirmation gate
        if cmd.requires_confirmation or cmd.dangerous:
            if not skip_confirm:
                self._pending_confirmation = (cmd, params)
                msg = (f"Are you sure you want to {cmd.description or cmd.name}? "
                       f"Say yes or no.")
                log_cmd(f"Confirmation required for: {cmd.name}")
                return CommandResult(
                    status=CommandStatus.CONFIRMATION_REQUIRED,
                    command_name=cmd.name,
                    requires_confirmation=True,
                    confirmation_message=msg,
                    spoken_response=msg,
                )
        # Pre-hooks
        for hook in self._pre_hooks:
            try:
                r = hook(cmd, params)
                if r is not None:
                    return r
            except Exception as e:
                log.error(f"Pre-hook error: {e}")

        try:
            log_cmd(f"Executing: {cmd.name} params={params}")
            result = cmd.handler(**params)
            if isinstance(result, CommandResult):
                resp = result
            elif isinstance(result, str):
                resp = CommandResult(status=CommandStatus.SUCCESS, command_name=cmd.name,
                                     spoken_response=result, data=result)
            else:
                resp = CommandResult(status=CommandStatus.SUCCESS, command_name=cmd.name,
                                     spoken_response="Done.", data=result)
        except TypeError as e:
            # Try calling with context too
            try:
                result = cmd.handler(**params, ctx=context)
                if isinstance(result, str):
                    resp = CommandResult(status=CommandStatus.SUCCESS, command_name=cmd.name,
                                         spoken_response=result, data=result)
                elif isinstance(result, CommandResult):
                    resp = result
                else:
                    resp = CommandResult(status=CommandStatus.SUCCESS, command_name=cmd.name,
                                         spoken_response="Done.")
            except Exception as e2:
                log.error(f"Command '{cmd.name}' execution error: {e2}")
                resp = CommandResult(status=CommandStatus.FAILED, command_name=cmd.name,
                                     error=str(e2), spoken_response=f"Sorry, that didn't work: {e2}")
        except Exception as e:
            log.error(f"Command '{cmd.name}' execution error: {e}")
            resp = CommandResult(status=CommandStatus.FAILED, command_name=cmd.name,
                                 error=str(e), spoken_response=f"Sorry, I ran into a problem: {e}")

        resp.execution_time_ms = (time.time() - start) * 1000
        # Post-hooks
        for hook in self._post_hooks:
            try:
                hook(cmd, params, resp)
            except Exception as e:
                log.error(f"Post-hook error: {e}")
        return resp

    def _add_history(self, text: str, results: List[CommandResult]):
        with self._lock:
            self.history.append((text, results))
            if len(self.history) > self._history_limit:
                self.history = self.history[-self._history_limit:]
