"""Deterministic tests for Alpha's provider-neutral AI manager."""

import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.ai.intent_classifier import IntentClassifier
from alpha.ai.manager import AIManager
from alpha.ai.openai_provider import OpenAIProvider
from alpha.ai.claude_provider import ClaudeProvider
from alpha.ai.provider_base import (
    AIMessage,
    AIProvider,
    AIResponse,
    parse_command_directives,
)


class RecordingProvider(AIProvider):
    def __init__(self, name: str, text: str = "Natural answer."):
        self.name = name
        self.text = text
        self.calls = []

    def ask(self, messages, system_prompt):
        self.calls.append((list(messages), system_prompt))
        return AIResponse(
            text=self.text,
            model=f"{self.name}-test-model",
            provider=self.name,
        )


class FailingProvider(RecordingProvider):
    def ask(self, messages, system_prompt):
        self.calls.append((list(messages), system_prompt))
        raise RuntimeError("simulated provider outage")


class StreamingProvider(RecordingProvider):
    def stream(self, messages, system_prompt):
        self.calls.append((list(messages), system_prompt))
        yield "Hello "
        yield "from Alpha."


def _config():
    return SimpleNamespace(
        ai=SimpleNamespace(
            default_provider="openai",
            base_url="https://openrouter.ai/api/v1",
            openai_model="openai-test",
            claude_model="claude-test",
            max_tokens=100,
            timeout_seconds=2,
            temperature=0.2,
        )
    )


class TestIntentClassifier(unittest.TestCase):
    def setUp(self):
        self.classifier = IntentClassifier()

    def test_routes_programming_and_creative_writing_to_claude(self):
        for prompt in (
            "Debug this Python function",
            "Explain this Java stack trace",
            "Write a short story about Kathmandu",
            "Create a poem about rain",
        ):
            with self.subTest(prompt=prompt):
                self.assertEqual(
                    self.classifier.classify(prompt).provider,
                    "claude",
                )

    def test_routes_math_research_and_analysis_to_reasoning_model(self):
        for prompt in (
            "Solve this mathematics equation step by step",
            "Research and analyze the trade-offs",
            "Diagnose the root cause of this architecture problem",
        ):
            with self.subTest(prompt=prompt):
                self.assertEqual(
                    self.classifier.classify(prompt).provider,
                    "claude",
                )

    def test_routes_everyday_and_uncertain_requests_to_openai(self):
        for prompt in (
            "Hello, how are you?",
            "Tell me a joke",
            "What is the weather?",
            "Translate this into Nepali",
            "A completely unfamiliar request",
        ):
            with self.subTest(prompt=prompt):
                self.assertEqual(
                    self.classifier.classify(prompt).provider,
                    "openai",
                )


class TestAIManager(unittest.TestCase):
    def _manager(self, providers):
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        env_path = Path(temp_dir.name) / ".env"
        return AIManager(
            config=_config(),
            env_path=env_path,
            providers=providers,
        )

    def test_ask_routes_without_exposing_provider_in_answer(self):
        openai = RecordingProvider("openai", "Hello! Nice to see you.")
        claude = RecordingProvider("claude", "Here is the fixed code.")
        manager = self._manager({"openai": openai, "claude": claude})

        answer = manager.ask("Hello, how are you?")
        code_answer = manager.ask("Debug this Python function")

        self.assertEqual(answer.text, "Hello! Nice to see you.")
        self.assertEqual(code_answer.text, "Here is the fixed code.")
        self.assertEqual(len(openai.calls), 1)
        self.assertEqual(len(claude.calls), 1)
        self.assertNotIn("openai", answer.text.casefold())
        self.assertNotIn("claude", code_answer.text.casefold())

    def test_provider_failure_falls_back_automatically(self):
        openai = FailingProvider("openai")
        claude = RecordingProvider("claude", "I can still help.")
        manager = self._manager({"openai": openai, "claude": claude})

        response = manager.ask("Tell me a joke")

        self.assertEqual(response.text, "I can still help.")
        self.assertEqual(len(openai.calls), 1)
        self.assertEqual(len(claude.calls), 1)

    def test_circuit_breaker_skips_recently_failed_provider(self):
        openai = FailingProvider("openai")
        claude = RecordingProvider("claude", "Fallback answer.")
        manager = self._manager({"openai": openai, "claude": claude})

        manager.ask("Tell me something useful")
        manager.ask("Tell me something different")

        self.assertEqual(len(openai.calls), 1)
        self.assertEqual(len(claude.calls), 2)
        self.assertTrue(manager.provider_health()["openai"]["circuit_open"])

    def test_safe_repeated_response_is_cached_in_memory(self):
        openai = RecordingProvider("openai", "A reusable answer.")
        claude = RecordingProvider("claude")
        manager = self._manager({"openai": openai, "claude": claude})

        first = manager.ask("Tell me a joke")
        second = manager.ask("Tell me a joke")

        self.assertEqual(first.text, second.text)
        self.assertEqual(len(openai.calls), 1)

    def test_streaming_stays_provider_neutral(self):
        openai = StreamingProvider("openai")
        manager = self._manager(
            {
                "openai": openai,
                "claude": RecordingProvider("claude"),
            }
        )

        chunks = list(manager.ask_stream("Hello there"))

        self.assertEqual("".join(chunks), "Hello from Alpha.")
        self.assertEqual(len(openai.calls), 1)

    def test_alpha_history_is_forwarded_across_provider_switches(self):
        openai = RecordingProvider("openai")
        claude = RecordingProvider("claude")
        manager = self._manager({"openai": openai, "claude": claude})
        history = [
            AIMessage(role="user", content="My project is called Aurora."),
            AIMessage(role="assistant", content="I will remember that."),
        ]

        manager.ask(
            "Write Python code for my project",
            history=history,
            system_prompt="You are Alpha.",
        )

        sent_messages, sent_prompt = claude.calls[0]
        self.assertEqual(sent_messages[:2], history)
        self.assertEqual(
            sent_messages[-1].content,
            "Write Python code for my project",
        )
        self.assertEqual(sent_prompt, "You are Alpha.")

    def test_missing_env_file_is_created_with_placeholders(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            env_path = Path(temp_dir) / ".env"
            with patch.dict(
                os.environ,
                {
                    "OPENROUTER_API_KEY": "",
                    "OPENROUTER_BASE_URL": "https://openrouter.ai/api/v1",
                },
                clear=False,
            ):
                manager = AIManager(config=_config(), env_path=env_path)

            self.assertTrue(env_path.exists())
            self.assertIn(
                "OPENROUTER_API_KEY=",
                env_path.read_text("utf-8"),
            )
            self.assertEqual(
                manager.missing_keys(),
                ["OPENROUTER_API_KEY"],
            )

    def test_both_routes_share_one_openrouter_key_and_url(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            env_path = Path(temp_dir) / ".env"
            env_path.write_text("", encoding="utf-8")
            with patch.dict(
                os.environ,
                {
                    "OPENROUTER_API_KEY": "test-shared-key",
                    "OPENROUTER_BASE_URL": "https://openrouter.example/v1",
                    "OPENROUTER_OPENAI_MODEL": "openai-test-model",
                    "OPENROUTER_CLAUDE_MODEL": "claude-test-model",
                },
                clear=False,
            ):
                manager = AIManager(config=_config(), env_path=env_path)

            openai = manager.providers["openai"]
            claude = manager.providers["claude"]
            self.assertEqual(openai.api_key, claude.api_key)
            self.assertEqual(openai.base_url, claude.base_url)
            self.assertEqual(
                openai.base_url,
                "https://openrouter.example/v1",
            )
            self.assertNotEqual(openai.model, claude.model)
            self.assertEqual(manager.missing_keys(), [])


class TestCommandDirectiveParser(unittest.TestCase):
    def test_preserves_existing_allowlisted_plan_contract(self):
        text, commands = parse_command_directives(
            "On it. [[CMD:open_app|app=Brave]]"
        )

        self.assertEqual(text, "On it.")
        self.assertEqual(commands[0]["action"], "open_app")
        self.assertEqual(commands[0]["params"], {"app": "Brave"})


class TestProviderAdapters(unittest.TestCase):
    def test_openai_adapter_uses_shared_compatible_api(self):
        provider = OpenAIProvider(
            "test-key",
            "test-model",
            "https://openrouter.example/v1",
        )
        create = MagicMock(
            return_value=SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(
                            content="Done. [[CMD:open_app|app=Brave]]"
                        )
                    )
                ],
                usage=SimpleNamespace(total_tokens=12),
            )
        )
        provider._client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=create)
            )
        )

        response = provider.ask(
            [AIMessage(role="user", content="Open Brave")],
            "You are Alpha.",
        )

        self.assertEqual(response.text, "Done.")
        self.assertEqual(response.commands[0]["action"], "open_app")
        self.assertEqual(response.tokens_used, 12)
        self.assertEqual(
            create.call_args.kwargs["messages"][0]["content"],
            "You are Alpha.",
        )

    def test_claude_adapter_uses_same_compatible_api(self):
        provider = ClaudeProvider(
            "test-key",
            "test-model",
            "https://openrouter.example/v1",
        )
        create = MagicMock(
            return_value=SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(
                            content="Here is the answer."
                        )
                    )
                ],
                usage=SimpleNamespace(total_tokens=13),
            )
        )
        provider._client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=create)
            )
        )

        response = provider.ask(
            [AIMessage(role="user", content="Debug this code")],
            "You are Alpha.",
        )

        self.assertEqual(response.text, "Here is the answer.")
        self.assertEqual(response.tokens_used, 13)
        self.assertEqual(
            create.call_args.kwargs["messages"][0]["content"],
            "You are Alpha.",
        )


if __name__ == "__main__":
    unittest.main()
