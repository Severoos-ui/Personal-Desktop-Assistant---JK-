"""Bilingual command normalization and confirmation checks."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.language import (
    contains_unsupported_script,
    detect_language,
    is_affirmative,
    is_negative,
    localize_response,
    normalize_command,
    validate_spoken_language,
)


class TestLanguageDetection(unittest.TestCase):
    def test_detects_english_nepali_and_mixed_nepali(self):
        self.assertEqual(detect_language("open Chrome"), "en")

    def test_accepts_only_english_nepali_and_mixed_speech(self):
        self.assertTrue(
            validate_spoken_language("Open Chrome", "en", 0.95).supported
        )
        self.assertTrue(
            validate_spoken_language(
                "Chrome खोल",
                "ne",
                0.95,
            ).supported
        )
        decision = validate_spoken_language("Hola amigo", "es", 0.95)
        self.assertFalse(decision.supported)
        self.assertEqual(decision.code, "es")

    def test_blocks_non_latin_non_devanagari_tts_scripts(self):
        self.assertFalse(contains_unsupported_script("Hello नमस्ते"))
        self.assertTrue(contains_unsupported_script("Привет"))
        self.assertEqual(detect_language("क्रोम खोल"), "ne")
        self.assertEqual(detect_language("VS Code open गर"), "ne")


class TestMixedCommandNormalization(unittest.TestCase):
    def test_required_mixed_examples_route_to_local_commands(self):
        examples = {
            "Chrome खोल।": "open Chrome",
            "VS Code open गर।": "open VS Code",
            "YouTube मा lo-fi music play गर।": (
                "play lo-fi music on youtube"
            ),
            "Downloads folder खोल।": "open Downloads",
            "आजको काम के छ?": "daily briefing",
            "कम्प्युटर बन्द गर।": "shutdown",
        }
        for spoken, expected in examples.items():
            with self.subTest(spoken=spoken):
                self.assertEqual(normalize_command(spoken), expected)


class TestNepaliResponses(unittest.TestCase):
    def test_common_action_response_is_nepali_unicode(self):
        self.assertEqual(
            localize_response("Opening Chrome.", "ne"),
            "Chrome खोल्दैछु।",
        )
        self.assertEqual(
            localize_response("Cancelled.", "ne"),
            "रद्द गरियो।",
        )

    def test_daily_briefing_is_localized(self):
        response = localize_response(
            "Good morning. You have 2 pending tasks, 1 active "
            "reminder, and 1 reminder due today.",
            "ne",
        )
        self.assertIn("तपाईंका 2 बाँकी काम", response)
        self.assertIn("आजका लागि 1 रिमाइन्डर", response)

    def test_dangerous_confirmation_answers_are_bilingual(self):
        prompt = localize_response(
            "Are you sure you want to shutdown the computer? Say yes or no.",
            "ne",
        )
        self.assertIn("हो वा होइन", prompt)
        for answer in ("yes", "हो", "हुन्छ", "ठीक छ"):
            with self.subTest(answer=answer):
                self.assertTrue(is_affirmative(answer))
        for answer in ("no", "होइन", "रद्द गर", "नगर"):
            with self.subTest(answer=answer):
                self.assertTrue(is_negative(answer))


if __name__ == "__main__":
    unittest.main()
