"""Tests for the memory store."""

import os
import sqlite3
import sys
import tempfile
import unittest
from contextlib import closing
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.memory.store import MemoryStore


class TestMemoryStore(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db = MemoryStore(
            db_path=str(Path(self.tmp.name) / "test.db"),
            encrypted=False,
        )

    def tearDown(self):
        self.tmp.cleanup()

    def test_conversation_roundtrip(self):
        self.db.add_message("sess1", "user", "Hello Alpha")
        self.db.add_message("sess1", "assistant", "Hey there!")
        conv = self.db.get_conversation("sess1")
        self.assertEqual(len(conv), 2)
        self.assertEqual(conv[0]["content"], "Hello Alpha")
        self.assertEqual(conv[1]["role"], "assistant")

    def test_preferences(self):
        self.db.set_pref("browser", "brave")
        self.db.set_pref("volume", 65)
        self.assertEqual(self.db.get_pref("browser"), "brave")
        self.assertEqual(self.db.get_pref("volume"), 65)
        self.assertIsNone(self.db.get_pref("nonexistent"))
        self.assertEqual(self.db.get_pref("nonexistent", "default"), "default")
        self.assertTrue(self.db.delete_pref("browser"))
        self.assertIsNone(self.db.get_pref("browser"))

    def test_command_history(self):
        self.db.log_command("open brave", "open_app", True, "Opening brave.")
        cmds = self.db.recent_commands()
        self.assertEqual(len(cmds), 1)
        self.assertEqual(cmds[0]["command_name"], "open_app")

    def test_reminders(self):
        rid = self.db.add_reminder("Buy milk")
        self.db.add_reminder("Test future", due_at=9999999999)
        due = self.db.get_due_reminders()
        # Buy milk has no due_at (treated as not due?)
        # Actually our due query is `due_at <= now` and `due_at IS NOT NULL`, so no-due reminders
        # are not considered "due" here.
        self.assertTrue(all(r["title"] != "Buy milk" or r["due_at"] is None for r in due))
        self.db.complete_reminder(rid)
        all_active = self.db.list_reminders(include_completed=False)
        self.assertFalse(any(r["id"] == rid for r in all_active))

    def test_tasks(self):
        tid = self.db.add_task("Write code", priority=3)
        pending = self.db.list_tasks("pending")
        self.assertTrue(any(t["id"] == tid for t in pending))
        self.db.complete_task(tid)
        done = self.db.list_tasks("done")
        self.assertTrue(any(t["id"] == tid for t in done))

    def test_notes_can_be_listed_and_searched(self):
        self.db.add_note("Project", "The demo is Friday")
        self.assertEqual(
            self.db.list_notes()[0]["content"],
            "The demo is Friday",
        )
        self.assertEqual(
            self.db.search_notes("demo")[0]["title"],
            "Project",
        )

    def test_sensitive_command_history_is_redacted(self):
        self.db.log_command(
            "type my password is example",
            "type_text",
            False,
            "password refused",
        )
        command = self.db.recent_commands()[0]
        self.assertEqual(
            command["command_text"],
            "[REDACTED SENSITIVE COMMAND]",
        )

    def test_personal_productivity_data_is_encrypted_at_rest(self):
        encrypted_path = Path(self.tmp.name) / "encrypted.db"
        encrypted = MemoryStore(
            db_path=str(encrypted_path),
            encrypted=True,
            key_path=str(Path(self.tmp.name) / ".memory-key"),
        )
        self.assertTrue(encrypted.encryption_enabled)
        encrypted.set_pref("favorite browser", "Brave")
        encrypted.add_message(
            "session",
            "user",
            "My project demo is Friday",
        )
        encrypted.add_note("Project", "The demo is Friday")
        encrypted.add_task("Finish the report")
        encrypted.add_reminder("Call home", due_at=9999999999)

        with closing(sqlite3.connect(str(encrypted_path))) as connection:
            stored_pref = connection.execute(
                "SELECT value FROM preferences WHERE key='favorite browser'"
            ).fetchone()[0]
            stored_note = connection.execute(
                "SELECT content FROM notes"
            ).fetchone()[0]
            stored_task = connection.execute(
                "SELECT title FROM tasks"
            ).fetchone()[0]
            stored_reminder = connection.execute(
                "SELECT title FROM reminders"
            ).fetchone()[0]

        self.assertNotIn("Brave", stored_pref)
        self.assertNotIn("demo", stored_note)
        self.assertNotIn("Finish", stored_task)
        self.assertNotIn("Call", stored_reminder)
        self.assertEqual(
            encrypted.get_pref("favorite browser"),
            "Brave",
        )
        self.assertEqual(
            encrypted.search_notes("demo")[0]["title"],
            "Project",
        )
        self.assertEqual(
            encrypted.search_conversations("project demo")[0]["role"],
            "user",
        )


if __name__ == "__main__":
    unittest.main()
