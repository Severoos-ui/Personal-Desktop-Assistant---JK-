"""Deterministic checks for Alpha's global shortcut request channel."""

import os
import sys
import tempfile
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication

from alpha.system.hotkey_requests import HotkeyRequestService


class TestHotkeyRequestService(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication(sys.argv)

    def test_activation_request_is_consumed_once(self):
        with tempfile.TemporaryDirectory() as temporary:
            service = HotkeyRequestService(Path(temporary))
            activations = []
            service.activate_requested.connect(lambda: activations.append(True))
            service.activate_path.write_text("request", encoding="utf-8")

            service._poll()
            service._poll()

            self.assertEqual(activations, [True])
            self.assertFalse(service.activate_path.exists())

    def test_quit_wins_when_both_requests_exist(self):
        with tempfile.TemporaryDirectory() as temporary:
            service = HotkeyRequestService(Path(temporary))
            events = []
            service.activate_requested.connect(lambda: events.append("activate"))
            service.quit_requested.connect(lambda: events.append("quit"))
            service.activate_path.write_text("request", encoding="utf-8")
            service.quit_path.write_text("request", encoding="utf-8")

            service._poll()

            self.assertEqual(events, ["quit"])
            self.assertTrue(service.activate_path.exists())
            self.assertFalse(service.quit_path.exists())
