"""Basic unit tests for the command registry and parser."""

import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.commands.registry import CommandRegistry, CommandDef, ParamDef, ParamType
from alpha.commands.engine import CommandEngine, CommandStatus
from alpha.automation.desktop import DesktopController
from alpha.automation.register_commands import register_desktop_commands


class TestCommandRegistry(unittest.TestCase):

    def setUp(self):
        self.reg = CommandRegistry()
        self.reg.register(CommandDef(
            name="greet",
            handler=lambda name="world": f"Hello, {name}!",
            description="greet someone",
            triggers=["greet", "say hello to"],
            params=[ParamDef(name="name", type=ParamType.STRING)],
            patterns=[r"(?:greet|say\s+hello\s+to)\s+(?P<name>.+)$"],
        ))
        self.reg.register(CommandDef(
            name="shutdown",
            handler=lambda: "Shutting down",
            description="shutdown pc",
            triggers=["shutdown", "shut down"],
            dangerous=True, requires_confirmation=True,
        ))
        self.engine = CommandEngine(self.reg)

    def test_match_simple(self):
        matches = self.reg.find_matches("greet Alice")
        self.assertTrue(len(matches) >= 1)
        cmd, conf, params = matches[0]
        self.assertEqual(cmd.name, "greet")
        self.assertGreaterEqual(conf, 0.5)

    def test_match_with_hi_jk_prefix(self):
        matches = self.reg.find_matches("Alpha, greet Alice")
        self.assertTrue(matches)
        self.assertEqual(matches[0][0].name, "greet")

    def test_no_match(self):
        matches = self.reg.find_matches("xyzzy random nonsense")
        self.assertEqual(len(matches), 0)

    def test_execute_greet(self):
        results = self.engine.execute("greet Alice")
        self.assertEqual(len(results), 1)
        self.assertIn("Hello", results[0].spoken_response)

    def test_confirmation_required(self):
        results = self.engine.execute("shutdown now")
        self.assertTrue(any(r.status.value == "confirmation_required" for r in results))
        # Confirm
        r = self.engine.confirm(True)
        self.assertEqual(r.status.value, "success")

    def test_deny_confirmation(self):
        self.engine.execute("shutdown")
        r = self.engine.confirm(False)
        self.assertEqual(r.status.value, "cancelled")

    def test_allowlisted_llm_plan_executes_exact_registered_command(self):
        result = self.engine.execute_planned(
            "greet",
            {"name": "Sujan", "ignored": "not passed to handler"},
        )

        self.assertEqual(result.status, CommandStatus.SUCCESS)
        self.assertEqual(result.spoken_response, "Hello, Sujan!")

    def test_unlisted_llm_plan_is_rejected(self):
        result = self.engine.execute_planned(
            "run_arbitrary_powershell",
            {"script": "anything"},
        )

        self.assertEqual(result.status, CommandStatus.FAILED)
        self.assertIn("allowlist", result.spoken_response)

    def test_dangerous_llm_plan_keeps_confirmation_gate(self):
        result = self.engine.execute_planned("shutdown")

        self.assertEqual(
            result.status,
            CommandStatus.CONFIRMATION_REQUIRED,
        )
        self.assertIsNotNone(self.engine._pending_confirmation)

    def test_history(self):
        self.engine.execute("greet Bob")
        self.engine.execute("greet Carol")
        self.assertEqual(len(self.engine.history), 2)

    def test_alias_expansion(self):
        self.engine.add_alias("hi there", "greet everyone")
        results = self.engine.execute("hi there")
        # Should route to greet with "everyone" as name
        self.assertTrue(any("Hello" in r.spoken_response for r in results))

    def test_spoken_app_name_corrections(self):
        self.assertEqual(
            DesktopController._normalise_app_name("Braves."),
            "brave",
        )
        self.assertEqual(
            DesktopController._normalise_app_name("Visual Studio Code"),
            "vscode",
        )

    @patch("alpha.commands.engine.time.sleep")
    def test_chains_open_app_and_type_in_focused_window(self, sleep):
        registry = CommandRegistry()
        desktop = MagicMock()
        browser = MagicMock()
        system = MagicMock()
        desktop.open_app.return_value = "Opening notepad."
        desktop.type_text.return_value = "Typed it."
        register_desktop_commands(registry, desktop, browser, system)
        engine = CommandEngine(registry)

        results = engine.execute("open Notepad and type meeting notes")

        self.assertEqual(len(results), 2)
        self.assertTrue(all(r.status.value == "success" for r in results))
        desktop.open_app.assert_called_once_with("Notepad")
        desktop.type_text.assert_called_once_with("meeting notes")

    @patch("alpha.commands.engine.time.sleep")
    def test_foreground_control_voice_patterns(self, sleep):
        registry = CommandRegistry()
        desktop = MagicMock()
        register_desktop_commands(
            registry,
            desktop,
            MagicMock(),
            MagicMock(),
        )
        engine = CommandEngine(registry)

        engine.execute("scroll down five")
        engine.execute("switch to Brave")
        engine.execute("maximize this window")
        engine.execute("press enter")
        engine.execute("save")

        desktop.scroll_screen.assert_called_once_with("down", 5)
        desktop.focus_app.assert_called_once_with("Brave")
        desktop.window_action.assert_called_once_with("maximize")
        desktop.press_key.assert_called_once_with("enter")
        desktop.keyboard_shortcut.assert_called_once_with("save")

    def test_automation_requires_an_anchored_request(self):
        registry = CommandRegistry()
        register_desktop_commands(
            registry,
            MagicMock(),
            MagicMock(),
            MagicMock(),
        )

        self.assertFalse(
            registry.find_matches(
                "I do not want to open Calculator"
            )
        )
        polite = registry.find_matches(
            "Could you please open Calculator"
        )
        self.assertTrue(polite)
        self.assertEqual(polite[0][0].name, "open_smart")
        self.assertEqual(polite[0][2]["target"], "Calculator")

    def test_standalone_greeting_is_not_stripped_as_a_prefix(self):
        registry = CommandRegistry()
        register_desktop_commands(
            registry,
            MagicMock(),
            MagicMock(),
            MagicMock(),
        )

        matches = registry.find_matches("hello")

        self.assertTrue(matches)
        self.assertEqual(matches[0][0].name, "hello")


if __name__ == "__main__":
    unittest.main()
