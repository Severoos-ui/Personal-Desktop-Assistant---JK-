"""Regression checks for interruptible, persistent text-to-speech playback."""

import queue
import sys
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.voice.tts import TextToSpeech


class TestTextToSpeechLifecycle(unittest.TestCase):
    @staticmethod
    def _bare_tts(engine_type="mock"):
        tts = TextToSpeech.__new__(TextToSpeech)
        tts.engine_type = engine_type
        tts._play_queue = queue.Queue()
        tts._play_thread = None
        tts._interrupt_event = threading.Event()
        tts._shutdown_event = threading.Event()
        tts._stream_open = threading.Event()
        tts._is_speaking = threading.Event()
        tts._speech_idle = threading.Event()
        tts._speech_idle.set()
        tts._on_start = []
        tts._on_end = []
        tts._on_audio_chunk = []
        tts._default_voice_id = "english"
        tts._nepali_voice_id = None
        tts._warned_missing_nepali_voice = False
        tts._online_nepali = False
        tts._edge_tts_available = False
        tts._active_mci_alias = ""
        tts._pyttsx = None
        tts._pyttsx_owner_thread_id = None
        tts.rate = 1.0
        tts.volume = 1.0
        tts.performance = None
        return tts

    def test_interrupt_does_not_kill_playback_worker(self):
        tts = self._bare_tts()
        tts._start_playback()

        try:
            tts.say("first response")
            time.sleep(0.08)
            tts.say("second response")
            time.sleep(0.12)
            self.assertTrue(tts._play_thread.is_alive())
        finally:
            tts.shutdown()

    def test_nepali_routes_to_neural_voice_when_local_voice_is_missing(self):
        tts = self._bare_tts()
        tts._online_nepali = True
        tts._edge_tts_available = True
        tts._speak_nepali_neural = MagicMock(return_value=True)
        tts._speak_mock = MagicMock()
        tts._start_playback()

        try:
            tts.say("नमस्ते, म ज्याकी हुँ।")
            time.sleep(0.15)
            tts._speak_nepali_neural.assert_called_once()
            tts._speak_mock.assert_not_called()
        finally:
            tts.shutdown()

    def test_system_voice_speaks_three_consecutive_streamed_turns(self):
        class FakeSystemVoice:
            def __init__(self):
                self.spoken = []
                self.thread_ids = []
                self.busy_steps = 0

            def setProperty(self, _name, _value):
                self.thread_ids.append(threading.get_ident())

            def say(self, text):
                self.thread_ids.append(threading.get_ident())
                self.spoken.append(text)
                self.busy_steps = 2

            def startLoop(self, _use_driver_loop):
                self.thread_ids.append(threading.get_ident())

            def isBusy(self):
                return self.busy_steps > 0

            def iterate(self):
                self.thread_ids.append(threading.get_ident())
                self.busy_steps -= 1

            def stop(self):
                self.busy_steps = 0

            def endLoop(self):
                self.thread_ids.append(threading.get_ident())

        tts = self._bare_tts("pyttsx3")
        fake_voice = FakeSystemVoice()
        initialized_on = []

        def initialize_on_worker():
            initialized_on.append(threading.get_ident())
            tts._pyttsx_owner_thread_id = threading.get_ident()
            tts._pyttsx = fake_voice

        tts._initialize_pyttsx_engine = initialize_on_worker
        turn_ended = threading.Event()
        tts.on_end(turn_ended.set)
        tts._start_playback()

        try:
            for turn in range(3):
                turn_ended.clear()
                tts.begin_stream()
                tts.say(f"spoken response {turn + 1}", interrupt=False)
                tts.end_stream()
                self.assertTrue(
                    turn_ended.wait(timeout=1.0),
                    f"turn {turn + 1} did not finish speaking",
                )

            self.assertEqual(
                fake_voice.spoken,
                [
                    "spoken response 1",
                    "spoken response 2",
                    "spoken response 3",
                ],
            )
            self.assertEqual(len(initialized_on), 1)
            self.assertTrue(fake_voice.thread_ids)
            self.assertEqual(
                set(fake_voice.thread_ids),
                {initialized_on[0]},
            )
        finally:
            tts.shutdown()


if __name__ == "__main__":
    unittest.main()
