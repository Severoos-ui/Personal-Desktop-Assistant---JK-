"""Tests for persistent local productivity and preference commands."""

import sys
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch

sys.path.insert(
    0,
    str(Path(__file__).resolve().parent.parent.parent.parent),
)

from alpha.commands.engine import CommandEngine
from alpha.commands.registry import CommandRegistry
from alpha.memory.store import MemoryStore
from alpha.productivity.register_commands import (
    register_productivity_commands,
)
from alpha.productivity.service import ProductivityService


class TestProductivityService(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.memory = MemoryStore(
            str(Path(self.temp_dir.name) / "memory.db"),
            encrypted=False,
        )
        self.service = ProductivityService(
            self.memory,
            poll_interval=1,
        )

    def tearDown(self):
        self.service.stop()
        self.temp_dir.cleanup()

    def test_relative_and_clock_time_parsing(self):
        base = datetime(2026, 7, 24, 8, 0, 0).timestamp()

        relative = self.service.parse_when("in ten minutes", now=base)
        tomorrow = self.service.parse_when(
            "tomorrow at 9 AM",
            now=base,
        )

        self.assertEqual(relative, base + 600)
        self.assertEqual(
            datetime.fromtimestamp(tomorrow),
            datetime(2026, 7, 25, 9, 0, 0),
        )

    def test_due_reminder_is_delivered_once_and_completed(self):
        delivered = []
        self.service.set_due_callback(
            lambda reminder: delivered.append(reminder) or True
        )
        reminder_id = self.memory.add_reminder(
            "Stretch",
            due_at=time.time() - 1,
        )

        count = self.service._check_due_reminders()

        self.assertEqual(count, 1)
        self.assertEqual(delivered[0]["title"], "Stretch")
        self.assertFalse(
            any(
                item["id"] == reminder_id
                for item in self.memory.list_reminders()
            )
        )

    def test_tasks_notes_and_preferences_persist(self):
        self.assertIn(
            "Added finish report",
            self.service.add_task("finish report", "high"),
        )
        self.assertIn("finish report", self.service.list_tasks())
        self.assertIn(
            "Completed task",
            self.service.complete_task("finish report"),
        )

        self.service.add_note("The project demo is Friday")
        self.assertIn(
            "project demo is Friday",
            self.service.search_notes("demo"),
        )

        self.service.remember_preference(
            "favorite browser",
            "Brave",
        )
        self.assertEqual(
            self.service.recall_preference("favorite browser"),
            "Your favorite browser is Brave.",
        )

    def test_spoken_secrets_are_not_saved(self):
        response = self.service.remember_preference(
            "API key",
            "not-a-real-key",
        )

        self.assertIn("won't store", response)
        self.assertIsNone(self.memory.get_pref("api key"))


class TestProductivityCommands(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.memory = MemoryStore(
            str(Path(self.temp_dir.name) / "memory.db"),
            encrypted=False,
        )
        self.service = ProductivityService(self.memory)
        registry = CommandRegistry()
        register_productivity_commands(registry, self.service)
        self.engine = CommandEngine(registry)

    def tearDown(self):
        self.service.stop()
        self.temp_dir.cleanup()

    @patch("alpha.commands.engine.time.sleep")
    def test_natural_voice_commands_reach_local_memory(self, sleep):
        reminder = self.engine.execute(
            "remind me to stretch in ten minutes"
        )
        task = self.engine.execute(
            "add task finish the report with high priority"
        )
        note = self.engine.execute(
            "take a note that the demo is Friday"
        )
        preference = self.engine.execute(
            "remember that my favorite browser is Brave"
        )

        self.assertEqual(reminder[0].status.value, "success")
        self.assertEqual(task[0].status.value, "success")
        self.assertEqual(note[0].status.value, "success")
        self.assertEqual(preference[0].status.value, "success")
        self.assertEqual(
            self.memory.list_tasks()[0]["priority"],
            3,
        )
        self.assertEqual(
            self.memory.get_pref("favorite browser"),
            "Brave",
        )

    @patch("alpha.commands.engine.time.sleep")
    def test_timer_and_daily_briefing(self, sleep):
        timer = self.engine.execute("set a timer for five minutes")
        briefing = self.engine.execute("daily briefing")

        self.assertIn("Timer set", timer[0].spoken_response)
        self.assertIn("active reminder", briefing[0].spoken_response)


if __name__ == "__main__":
    unittest.main()
