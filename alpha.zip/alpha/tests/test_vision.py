"""Iris-style screen-awareness regression checks."""

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.automation.register_commands import register_screen_commands
from alpha.commands.engine import CommandEngine, CommandStatus
from alpha.commands.registry import CommandRegistry
from alpha.vision.screen import ScreenVision


class TestScreenVision(unittest.TestCase):
    def test_temporary_screenshot_is_deleted_after_analysis(self):
        desktop = MagicMock()
        llm = MagicMock()
        llm.analyze_image.return_value = SimpleNamespace(
            text="A code editor is open.",
        )

        def capture(path):
            Path(path).write_bytes(b"temporary-screen")
            return Path(path)

        desktop.capture_screen_image.side_effect = capture
        with tempfile.TemporaryDirectory() as temp_dir:
            vision = ScreenVision(desktop, llm, temp_dir)
            response = vision.analyze()
            cached_images = list(
                (Path(temp_dir) / "cache").glob("screen_vision_*.png")
            )

        self.assertEqual(response, "A code editor is open.")
        self.assertEqual(cached_images, [])
        llm.analyze_image.assert_called_once()

    def test_voice_phrase_runs_screen_analysis_command(self):
        registry = CommandRegistry()
        screen_vision = MagicMock()
        screen_vision.analyze.return_value = "A browser is open."
        register_screen_commands(registry, screen_vision)
        engine = CommandEngine(registry)

        results = engine.execute("what is on my screen")

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].status, CommandStatus.SUCCESS)
        self.assertEqual(results[0].command_name, "analyze_screen")
        screen_vision.analyze.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
