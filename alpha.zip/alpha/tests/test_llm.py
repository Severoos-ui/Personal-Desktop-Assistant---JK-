"""LLM provider integration checks that never use real credentials."""

import base64
import json
import os
import sys
import tempfile
import unittest
import urllib.error
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.commands.engine import CommandEngine
from alpha.commands.registry import (
    CommandDef,
    CommandRegistry,
    ParamDef,
    ParamType,
)
from alpha.core.brain import Brain
from alpha.core.llm import LLMClient, LLMResponse, Message
from alpha.ai.provider_base import AIResponse


class TestGeminiProvider(unittest.TestCase):
    def test_environment_key_overrides_stale_ollama_config(self):
        config = SimpleNamespace(
            provider="ollama",
            model="llama3.2:1b",
            base_url="http://localhost:11434",
            api_key="",
            temperature=0.2,
            max_tokens=64,
            system_prompt="Be concise.",
        )

        with patch.dict(os.environ, {"GEMINI_API_KEY": "test-secret"}):
            client = LLMClient(config)

        self.assertEqual(client.provider, "gemini")
        self.assertEqual(client.model, "gemini-flash-latest")
        self.assertEqual(
            client.base_url,
            "https://generativelanguage.googleapis.com/v1beta",
        )

    def test_native_gemini_request_uses_environment_key(self):
        config = SimpleNamespace(
            provider="gemini",
            model="gemini-test-model",
            base_url="https://generativelanguage.googleapis.com/v1beta",
            api_key="",
            temperature=0.2,
            max_tokens=64,
            system_prompt="Be concise.",
        )
        response = MagicMock()
        response.read.return_value = json.dumps({
            "candidates": [{
                "content": {"parts": [{"text": "Ready."}]},
            }],
            "usageMetadata": {"totalTokenCount": 7},
        }).encode("utf-8")
        context = MagicMock()
        context.__enter__.return_value = response
        context.__exit__.return_value = False

        with (
            patch.dict(os.environ, {"GEMINI_API_KEY": "test-secret"}),
            patch("urllib.request.urlopen", return_value=context) as urlopen,
        ):
            client = LLMClient(config)
            result = client.chat([
                Message(role="system", content="Be concise."),
                Message(role="user", content="Status?"),
            ])

        self.assertEqual(result.text, "Ready.")
        self.assertEqual(result.tokens_used, 7)
        request = urlopen.call_args.args[0]
        headers = dict(request.header_items())
        self.assertEqual(headers.get("X-goog-api-key"), "test-secret")

    def test_native_gemini_preserves_multiple_command_plans(self):
        config = SimpleNamespace(
            provider="gemini",
            model="gemini-test-model",
            base_url="https://generativelanguage.googleapis.com/v1beta",
            api_key="",
            temperature=0.2,
            max_tokens=64,
            system_prompt="Be concise.",
        )
        response = MagicMock()
        response.read.return_value = json.dumps({
            "candidates": [{
                "content": {"parts": [{"text": (
                    "[[CMD:open_smart|target=Brave]] "
                    "[[CMD:search_youtube|query=lo-fi music]] "
                    "I will handle that."
                )}]},
            }],
        }).encode("utf-8")
        context = MagicMock()
        context.__enter__.return_value = response
        context.__exit__.return_value = False

        with (
            patch.dict(os.environ, {"GEMINI_API_KEY": "test-secret"}),
            patch("urllib.request.urlopen", return_value=context),
        ):
            client = LLMClient(config)
            result = client.chat([
                Message(role="user", content="Open Brave and find music."),
            ])

        self.assertEqual(result.text, "I will handle that.")
        self.assertEqual(
            [command["action"] for command in result.commands],
            ["open_smart", "search_youtube"],
        )
        self.assertEqual(result.command, result.commands[0])

    def test_screen_image_uses_inline_gemini_data(self):
        config = SimpleNamespace(
            provider="gemini",
            model="gemini-test-model",
            base_url="https://generativelanguage.googleapis.com/v1beta",
            api_key="",
            temperature=0.2,
            max_tokens=64,
            system_prompt="Be concise.",
        )
        response = MagicMock()
        response.read.return_value = json.dumps({
            "candidates": [{
                "content": {
                    "parts": [{"text": "A browser is open."}],
                },
            }],
            "usageMetadata": {"totalTokenCount": 9},
        }).encode("utf-8")
        context = MagicMock()
        context.__enter__.return_value = response
        context.__exit__.return_value = False
        image_bytes = b"\x89PNG\r\n\x1a\nfake-image"

        with tempfile.TemporaryDirectory() as temp_dir:
            image_path = Path(temp_dir) / "screen.png"
            image_path.write_bytes(image_bytes)
            with (
                patch.dict(os.environ, {"GEMINI_API_KEY": "test-secret"}),
                patch(
                    "urllib.request.urlopen",
                    return_value=context,
                ) as urlopen,
            ):
                client = LLMClient(config)
                result = client.analyze_image(
                    image_path,
                    "Describe this screen.",
                )

        self.assertEqual(result.text, "A browser is open.")
        request = urlopen.call_args.args[0]
        payload = json.loads(request.data)
        inline_data = payload["contents"][0]["parts"][0]["inline_data"]
        self.assertEqual(inline_data["mime_type"], "image/png")
        self.assertEqual(
            inline_data["data"],
            base64.b64encode(image_bytes).decode("ascii"),
        )

    def test_gemini_quota_message_preserves_local_controls(self):
        config = SimpleNamespace(
            provider="gemini",
            model="gemini-test-model",
            base_url="https://generativelanguage.googleapis.com/v1beta",
            api_key="",
            temperature=0.2,
            max_tokens=64,
            system_prompt="Be concise.",
        )
        quota_error = urllib.error.HTTPError(
            "https://example.invalid",
            429,
            "Too Many Requests",
            {},
            None,
        )

        with (
            patch.dict(os.environ, {"GEMINI_API_KEY": "test-secret"}),
            patch("urllib.request.urlopen", side_effect=quota_error),
        ):
            client = LLMClient(config)
            result = client.chat([
                Message(role="user", content="Tell me something."),
            ])

        self.assertEqual(result.error, "HTTP 429")
        self.assertIn("control apps", result.text)


class TestConversationalCommandBridge(unittest.TestCase):
    def test_clock_questions_use_nepal_time_without_an_ai_request(self):
        with patch("alpha.core.brain.nepal_now") as now:
            now.return_value = __import__("datetime").datetime(
                2026,
                7,
                28,
                16,
                25,
            )
            self.assertEqual(
                Brain._local_clock_response("What time is it now?"),
                "It is 4:25 PM in Nepal.",
            )
            self.assertEqual(
                Brain._local_clock_response("आज कति गते हो?"),
                "आज नेपालको मिति 2026-07-28 हो।",
            )

    def test_brain_executes_gemini_plan_through_local_allowlist(self):
        registry = CommandRegistry()
        registry.register(CommandDef(
            name="greet",
            handler=lambda name="world": f"Hello, {name}!",
            description="greet someone",
            triggers=["greet"],
            params=[
                ParamDef(
                    name="name",
                    type=ParamType.STRING,
                    required=True,
                )
            ],
        ))
        engine = CommandEngine(registry)
        fake_manager = MagicMock()
        fake_manager.ask.return_value = AIResponse(
            text="I will do that.",
            command={
                "action": "greet",
                "params": {"name": "Sujan"},
            },
            commands=[{
                "action": "greet",
                "params": {"name": "Sujan"},
            }],
        )
        config = SimpleNamespace(
            llm=SimpleNamespace(system_prompt="Be concise."),
        )

        with patch(
            "alpha.core.brain.AIManager",
            return_value=fake_manager,
        ):
            brain = Brain(engine, memory=None, config=config)
        response = brain.process("Please welcome Sujan warmly")

        self.assertEqual(response, "Hello, Sujan!")
        self.assertTrue(
            any(
                item[1][0].command_name == "greet"
                for item in engine.history
                if item[1]
            )
        )


if __name__ == "__main__":
    unittest.main()
