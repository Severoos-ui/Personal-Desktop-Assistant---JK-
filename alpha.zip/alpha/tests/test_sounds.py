"""Deterministic checks for Alpha's original synthesized lifecycle cues."""

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(
    0,
    str(Path(__file__).resolve().parent.parent.parent.parent),
)

from alpha.utils import sounds


class TestLifecycleSounds(unittest.TestCase):
    def test_tone_and_sweep_render_finite_bounded_audio(self):
        tone = sounds._tone_wave((440.0, 660.0), 0.1, 0.2)
        sweep = sounds._sweep_wave(120.0, 900.0, 0.1, 0.2)

        self.assertEqual(len(tone), 4410)
        self.assertEqual(len(sweep), 4410)
        self.assertTrue(np.isfinite(tone).all())
        self.assertTrue(np.isfinite(sweep).all())
        self.assertLessEqual(float(np.max(np.abs(tone))), 0.21)
        self.assertLessEqual(float(np.max(np.abs(sweep))), 0.21)

    def test_power_on_and_off_have_distinct_complete_cues(self):
        with patch("alpha.utils.sounds._play_wave") as play:
            sounds.play_power_on()
            startup = play.call_args.args[0]
            sounds.play_power_off()
            shutdown = play.call_args.args[0]

        self.assertGreater(len(startup), 25000)
        self.assertGreater(len(shutdown), 25000)
        self.assertNotEqual(len(startup), len(shutdown))
        self.assertFalse(np.array_equal(startup, shutdown))


if __name__ == "__main__":
    unittest.main()
