"""Deterministic checks for Alpha's event-driven runtime."""

import asyncio
import sys
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.runtime import EventBus, PerformanceMonitor, ServiceRuntime


class TestEventBus(unittest.TestCase):
    def test_publish_is_thread_safe_and_unsubscribable(self):
        bus = EventBus()
        received = []
        unsubscribe = bus.subscribe(
            "voice.state",
            lambda event: received.append(event.payload["state"]),
        )

        bus.publish("voice.state", {"state": "listening"})
        unsubscribe()
        bus.publish("voice.state", {"state": "sleeping"})

        self.assertEqual(received, ["listening"])


class TestPerformanceMonitor(unittest.TestCase):
    def test_bounded_metrics_include_resource_and_thread_health(self):
        monitor = PerformanceMonitor(history_size=20)
        with monitor.span("wake_detection"):
            time.sleep(0.001)

        snapshot = monitor.snapshot()

        self.assertIn("wake_detection", snapshot["metrics"])
        self.assertGreaterEqual(
            snapshot["metrics"]["wake_detection"]["last_ms"],
            0,
        )
        self.assertIn("threads", snapshot["resources"])
        self.assertIn("ram_mb", snapshot["resources"])


class TestServiceRuntime(unittest.TestCase):
    def test_runs_blocking_work_off_the_async_loop(self):
        runtime = ServiceRuntime(io_workers=2, compute_workers=1)
        runtime.start()
        try:
            async def work():
                return await runtime.run_blocking(
                    lambda value: value + 1,
                    41,
                )

            future = runtime.submit(work())
            self.assertEqual(future.result(timeout=2), 42)
            self.assertTrue(runtime.health()["loop_alive"])
        finally:
            runtime.stop()


if __name__ == "__main__":
    unittest.main()
