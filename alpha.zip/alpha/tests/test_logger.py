"""Logger checks for silent Windows pythonw startup."""

import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.utils.logger import AlphaLogger


class TestAlphaLogger(unittest.TestCase):
    def test_runs_without_console_streams(self):
        with tempfile.TemporaryDirectory() as tmp:
            log_path = Path(tmp) / "alpha.log"
            with patch.object(sys, "stdout", None), patch.object(sys, "stderr", None):
                logger = AlphaLogger(str(log_path))
                self.assertIsNone(logger.console_handler)
                logger.start()
                logger.get("pythonw-test").info("silent startup works")
                time.sleep(0.1)
                logger.stop()

            self.assertIn(
                "silent startup works",
                log_path.read_text(encoding="utf-8"),
            )


if __name__ == "__main__":
    unittest.main()
