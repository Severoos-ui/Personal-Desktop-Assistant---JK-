"""Deterministic tests for the strict Alpha activation gate."""

import sys
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.voice.engine import VoiceEngine, VoiceState
from alpha.voice.stt import SpeechToText
from alpha.core.assistant import AlphaAssistant


class TestWakePhraseParsing(unittest.TestCase):
    def test_accepts_only_exact_alpha_with_transcription_punctuation(self):
        examples = {
            "Alpha": "",
            "alpha.": "",
            "ALPHA!": "",
            "Alpha open Calculator": "open Calculator",
            "Alpha, आज मौसम कस्तो छ?": "आज मौसम कस्तो छ?",
        }
        for transcript, expected in examples.items():
            with self.subTest(transcript=transcript):
                self.assertEqual(
                    VoiceEngine.extract_wake_command(transcript),
                    expected,
                )

    def test_rejects_every_alias_partial_and_embedded_match(self):
        rejected = (
            "Beta",
            "Gamma",
            "Hey Beta",
            "Hello Beta",
            "Jay Kay",
            "Hi Jay Kay",
            "Hi Alpha",
            "Hey Alpha",
            "Hello Alpha",
            "Wake Alpha",
            "WakeUp Alpha",
            "Wake Up Alpha",
            "Alfa",
            "alphabet",
            "my Alpha",
            "Hi. Hi.",
            "Here's the key.",
            "",
        )
        for transcript in rejected:
            with self.subTest(transcript=transcript):
                self.assertIsNone(
                    VoiceEngine.extract_wake_command(transcript)
                )
                # The legacy compatibility argument must never loosen the gate.
                self.assertIsNone(
                    VoiceEngine.extract_wake_command(
                        transcript,
                        allow_short=True,
                    )
                )

    def test_stop_command_requires_an_exact_cancel_intent(self):
        for transcript in ("stop", "Stop it.", "cancel that", "be quiet"):
            with self.subTest(transcript=transcript):
                self.assertTrue(VoiceEngine.is_stop_command(transcript))
        for transcript in ("stop music", "do not stop", "cancel culture", ""):
            with self.subTest(transcript=transcript):
                self.assertFalse(VoiceEngine.is_stop_command(transcript))

    def test_prompt_echo_is_a_command_not_a_second_wake_match(self):
        self.assertEqual(
            VoiceEngine.extract_wake_command(
                "Alpha and should be written exactly as well."
            ),
            "and should be written exactly as well.",
        )

    def test_end_conversation_phrases_are_explicit_and_bilingual(self):
        for transcript in (
            "bye",
            "Goodbye Alpha.",
            "end the conversation",
            "that's all",
            "बिदा",
            "अब पुग्यो",
        ):
            with self.subTest(transcript=transcript):
                self.assertTrue(
                    VoiceEngine.is_end_conversation_command(transcript)
                )
        self.assertFalse(
            VoiceEngine.is_end_conversation_command("play goodbye music")
        )


class TestWakeStateGate(unittest.TestCase):
    def _engine(self, state):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine._running = True
        engine.state = state
        engine._phrase_lock = threading.RLock()
        engine._phrase_generation = 0
        engine._phrase_transcribing = False
        engine._reset_phrase_locked = lambda: None
        engine._set_state = lambda new_state: setattr(engine, "state", new_state)
        engine._capture_command = lambda: setattr(engine, "capture_started", True)
        engine.capture_started = False
        return engine

    def test_command_capture_starts_only_after_wake_phrase(self):
        engine = self._engine(VoiceState.LISTENING_WAKE)
        engine._begin_command_capture()
        self.assertEqual(engine.state, VoiceState.PREPARING_CMD)
        self.assertTrue(engine.capture_started)

        engine = self._engine(VoiceState.THINKING)
        engine._begin_command_capture()
        self.assertEqual(engine.state, VoiceState.THINKING)
        self.assertFalse(engine.capture_started)

    def test_followup_capture_prepares_multilingual_model(self):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine._running = True
        engine.state = VoiceState.SPEAKING
        engine.cfg = SimpleNamespace(
            voice=SimpleNamespace(continuous_followup_timeout=10.0)
        )
        engine._phrase_lock = threading.RLock()
        engine._phrase_generation = 0
        engine._phrase_transcribing = False
        engine._reset_phrase_locked = MagicMock()
        engine._set_state = lambda new_state: setattr(
            engine,
            "state",
            new_state,
        )
        engine._capture_command = MagicMock()

        engine._begin_followup_capture()

        self.assertEqual(engine.state, VoiceState.PREPARING_CMD)
        engine._capture_command.assert_called_once_with(followup=True)

    def test_tts_end_starts_continuous_followup(self):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine._running = True
        engine._conversation_active = True
        engine.cfg = SimpleNamespace(
            voice=SimpleNamespace(continuous_conversation=True)
        )
        engine._begin_followup_capture = MagicMock()
        engine._return_to_wake_listening = MagicMock()

        engine._on_tts_end()

        engine._begin_followup_capture.assert_called_once_with()
        engine._return_to_wake_listening.assert_not_called()

    def test_alt_f11_activates_dormant_listening(self):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine._running = True
        engine.state = VoiceState.LISTENING_WAKE
        engine.cfg = SimpleNamespace(
            voice=SimpleNamespace(continuous_conversation=True)
        )
        engine._pending_hotkey_activation = False
        engine._conversation_active = False
        engine._notify_activation = MagicMock()
        engine._begin_command_capture = MagicMock()

        activated = engine.activate_from_hotkey()

        self.assertTrue(activated)
        self.assertTrue(engine._conversation_active)
        engine._notify_activation.assert_called_once_with("hotkey")
        engine._begin_command_capture.assert_called_once_with()

    def test_alt_f11_queues_while_microphone_starts(self):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine._running = True
        engine.state = VoiceState.STARTING
        engine._pending_hotkey_activation = False

        activated = engine.activate_from_hotkey()

        self.assertTrue(activated)
        self.assertTrue(engine._pending_hotkey_activation)


class TestWakeConfidenceGate(unittest.TestCase):
    def _engine(self, transcript: str, confidence: float):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine._running = True
        engine.state = VoiceState.LISTENING_WAKE
        engine.cfg = SimpleNamespace(
            voice=SimpleNamespace(
                wake_min_confidence=0.55,
                continuous_conversation=True,
            )
        )
        engine._stt_lock = threading.Lock()
        engine._phrase_lock = threading.RLock()
        engine._phrase_generation = 7
        engine._phrase_transcribing = True
        engine._ignore_phrase_until = 0.0
        engine.wake_stt = SimpleNamespace(
            transcribe_array=MagicMock(return_value=transcript),
            last_confidence=confidence,
        )
        engine._notify_activation = MagicMock()
        engine._begin_command_capture = MagicMock()
        engine._dispatch_command = MagicMock()
        engine.respond = MagicMock()
        return engine

    def test_low_confidence_exact_text_remains_dormant(self):
        engine = self._engine("Alpha", 0.30)
        engine._transcribe_wake_phrase(np.zeros(3200, dtype=np.int16), 7)

        engine._notify_activation.assert_not_called()
        engine._begin_command_capture.assert_not_called()
        engine._dispatch_command.assert_not_called()
        engine.respond.assert_not_called()
        self.assertEqual(engine.state, VoiceState.LISTENING_WAKE)

    def test_clear_exact_text_is_the_only_activation_path(self):
        engine = self._engine("Alpha, Chrome खोल", 0.90)
        engine._transcribe_wake_phrase(np.zeros(3200, dtype=np.int16), 7)

        engine._notify_activation.assert_called_once_with("alpha")
        engine._dispatch_command.assert_called_once_with("Chrome खोल")
        engine.respond.assert_not_called()
        self.assertEqual(
            engine.wake_stt.transcribe_array.call_count,
            2,
        )
        first_call = engine.wake_stt.transcribe_array.call_args_list[0]
        self.assertEqual(first_call.kwargs["hotwords"], "Alpha")
        second_call = engine.wake_stt.transcribe_array.call_args_list[1]
        self.assertEqual(second_call.kwargs["language_hint"], "auto")

    def test_exact_alpha_gives_audible_acknowledgement(self):
        engine = self._engine("Alpha", 0.72)

        engine._transcribe_wake_phrase(np.zeros(3200, dtype=np.int16), 7)

        engine._notify_activation.assert_called_once_with("alpha")
        engine.respond.assert_called_once_with("Yes?")
        engine._begin_command_capture.assert_not_called()
        engine._dispatch_command.assert_not_called()

    def test_dormant_speech_gate_adapts_below_legacy_threshold(self):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine.cfg = SimpleNamespace(
            voice=SimpleNamespace(wake_speech_floor=0.0015)
        )
        engine.wake_stt = SimpleNamespace(speech_threshold=0.005)
        engine._ambient_noise_floor = 0.00002

        gate = engine._wake_speech_gate()

        self.assertGreaterEqual(gate, 0.0015)
        self.assertLess(gate, 0.003)

    def test_custom_model_score_cannot_activate_by_itself(self):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine._notify_activation = MagicMock()
        engine._begin_command_capture = MagicMock()

        engine._on_custom_wake(SimpleNamespace(confidence=0.99))

        engine._notify_activation.assert_not_called()
        engine._begin_command_capture.assert_not_called()

    def test_live_barge_in_dispatches_clear_new_turn(self):
        engine = self._engine("open Camera", 0.92)
        engine.state = VoiceState.SPEAKING
        engine._conversation_active = True
        engine._last_spoken_text = "Here is your system information."
        engine.cfg.voice.barge_in_enabled = True
        engine.cfg.voice.barge_in_min_confidence = 0.70
        engine.cfg.voice.barge_in_echo_similarity = 0.72
        engine._interrupt_speech_with_command = MagicMock()
        engine._interrupt_speech_and_listen = MagicMock()

        engine._transcribe_wake_phrase(
            np.zeros(3200, dtype=np.int16),
            7,
        )

        engine._interrupt_speech_with_command.assert_called_once_with(
            "open Camera"
        )
        engine._interrupt_speech_and_listen.assert_not_called()

    def test_live_barge_in_rejects_alphas_own_tts_echo(self):
        spoken = "Opening Calculator now."
        engine = self._engine(spoken, 0.94)
        engine.state = VoiceState.SPEAKING
        engine._conversation_active = True
        engine._last_spoken_text = spoken
        engine.cfg.voice.barge_in_enabled = True
        engine.cfg.voice.barge_in_min_confidence = 0.70
        engine.cfg.voice.barge_in_echo_similarity = 0.72
        engine._interrupt_speech_with_command = MagicMock()
        engine._interrupt_speech_and_listen = MagicMock()

        engine._transcribe_wake_phrase(
            np.zeros(3200, dtype=np.int16),
            7,
        )

        engine._interrupt_speech_with_command.assert_not_called()
        engine._interrupt_speech_and_listen.assert_not_called()

    def test_plain_stop_interrupts_speech_but_keeps_live_session(self):
        engine = self._engine("stop", 0.95)
        engine.state = VoiceState.SPEAKING
        engine._conversation_active = True
        engine._last_spoken_text = "A long response without that word."
        engine.cfg.voice.barge_in_enabled = True
        engine.cfg.voice.barge_in_min_confidence = 0.70
        engine.cfg.voice.barge_in_echo_similarity = 0.72
        engine._interrupt_speech_with_command = MagicMock()
        engine._interrupt_speech_and_listen = MagicMock()

        engine._transcribe_wake_phrase(
            np.zeros(3200, dtype=np.int16),
            7,
        )

        engine._interrupt_speech_and_listen.assert_called_once_with()
        engine._interrupt_speech_with_command.assert_not_called()

class TestDormantTranscriptPrivacy(unittest.TestCase):
    def test_wake_detector_does_not_write_ambient_text_to_log(self):
        stt = SpeechToText.__new__(SpeechToText)
        stt.model = SimpleNamespace(
            transcribe=MagicMock(
                return_value=(
                    [
                        SimpleNamespace(
                            text="background conversation",
                            avg_logprob=-0.1,
                            no_speech_prob=0.05,
                        )
                    ],
                    SimpleNamespace(
                        language="en",
                        language_probability=0.9,
                    ),
                )
            )
        )
        stt.language = "auto"
        stt.log_transcript = False
        stt.last_detected_language = ""
        stt.last_language_probability = 0.0
        stt.last_confidence = 0.0

        with patch("alpha.voice.stt.log_voice") as log_mock:
            result = stt._transcribe_fw(np.zeros(1600, dtype=np.float32))

        self.assertEqual(result, "background conversation")
        log_mock.assert_not_called()

    def test_ambiguous_foreign_id_retries_as_constrained_english(self):
        calls = []

        def transcribe(_audio, **kwargs):
            calls.append(kwargs.get("language"))
            if kwargs.get("language") == "en":
                return (
                    [
                        SimpleNamespace(
                            text="open calculator",
                            avg_logprob=-0.15,
                            no_speech_prob=0.03,
                        )
                    ],
                    SimpleNamespace(
                        language="en",
                        language_probability=1.0,
                    ),
                )
            return (
                [
                    SimpleNamespace(
                        text="garbled words",
                        avg_logprob=-0.25,
                        no_speech_prob=0.08,
                    )
                ],
                SimpleNamespace(
                    language="cs",
                    language_probability=0.42,
                ),
            )

        stt = SpeechToText.__new__(SpeechToText)
        stt.model = SimpleNamespace(transcribe=transcribe)
        stt.engine = "faster_whisper"
        stt.language = "auto"
        stt.model_size = "base"
        stt.metric_name = "command_stt"
        stt.log_transcript = False
        stt.performance = None
        stt.last_detected_language = ""
        stt.last_language_probability = 0.0
        stt.last_confidence = 0.0

        result = stt.transcribe_array(np.zeros(3200, dtype=np.float32))

        self.assertEqual(result, "open calculator")
        self.assertEqual(calls, [None, "en"])
        self.assertEqual(stt.last_detected_language, "en")


class TestSpeechModelConcurrency(unittest.TestCase):
    def test_command_preload_does_not_hold_wake_transcription_lock(self):
        command_started = threading.Event()
        allow_command_finish = threading.Event()

        class FakeSTT:
            model_size = "test"
            engine = "faster_whisper"

            def __init__(self, wait=False):
                self.wait = wait

            def ensure_loaded(self):
                if self.wait:
                    command_started.set()
                    allow_command_finish.wait(timeout=1.0)

        engine = VoiceEngine.__new__(VoiceEngine)
        engine._wake_stt_lock = threading.Lock()
        engine._command_stt_lock = threading.Lock()
        engine.wake_stt = FakeSTT()
        engine.stt = FakeSTT(wait=True)
        engine.performance = None
        engine.events = None
        worker = threading.Thread(target=engine._preload_active_models)
        worker.start()

        try:
            self.assertTrue(command_started.wait(timeout=1.0))
            self.assertTrue(engine._wake_stt_lock.acquire(blocking=False))
            engine._wake_stt_lock.release()
        finally:
            allow_command_finish.set()
            worker.join(timeout=1.0)


class TestMicrophoneReadiness(unittest.TestCase):
    def _engine(self, available: bool, state=VoiceState.STARTING):
        engine = VoiceEngine.__new__(VoiceEngine)
        engine.state = state
        engine._mic_unavailable_since = 1.0
        engine.wakeword = SimpleNamespace(
            audio_available=available,
            last_audio_error="device unavailable",
        )
        engine._set_state = lambda new_state: setattr(engine, "state", new_state)
        return engine

    def test_ready_state_is_not_reported_before_audio_opens(self):
        engine = self._engine(False)
        engine._update_microphone_state(2.0)
        self.assertEqual(engine.state, VoiceState.STARTING)

        engine._update_microphone_state(4.1)
        self.assertEqual(engine.state, VoiceState.MIC_ERROR)

    def test_microphone_recovery_returns_to_wake_listening(self):
        engine = self._engine(True, state=VoiceState.MIC_ERROR)
        engine._update_microphone_state(5.0)
        self.assertEqual(engine.state, VoiceState.LISTENING_WAKE)


class TestConfirmationTimeout(unittest.TestCase):
    def test_unanswered_dangerous_action_is_cancelled_and_hidden(self):
        assistant = AlphaAssistant.__new__(AlphaAssistant)
        assistant._last_state = VoiceState.LISTENING_CMD
        assistant.cmd_engine = SimpleNamespace(
            _pending_confirmation=object()
        )
        assistant.brain = SimpleNamespace(cancel_current=MagicMock())
        assistant._confirmation_clear_listener = MagicMock()
        assistant._state_callbacks = []

        assistant._fire_state(VoiceState.LISTENING_WAKE)

        assistant.brain.cancel_current.assert_called_once_with()
        assistant._confirmation_clear_listener.assert_called_once_with()


if __name__ == "__main__":
    unittest.main()
