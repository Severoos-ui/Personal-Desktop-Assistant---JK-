"""Offscreen checks for Alpha's compact, voice-only desktop island."""

import os
import sys
import unittest
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from PySide6.QtCore import Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QLineEdit

from alpha.ui.island_window import AlphaIslandWindow


class TestAlphaIslandWindow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.window = AlphaIslandWindow()
        self.app.processEvents()

    def tearDown(self):
        self.window.close()
        self.app.processEvents()

    def test_dormant_is_small_but_completely_hidden(self):
        self.window.show_dormant()
        QTest.qWait(100)
        self.assertEqual(self.window.phase, "dormant")
        self.assertFalse(self.window.isVisible())
        self.assertFalse(self.window.isFullScreen())
        self.assertLessEqual(self.window.width(), 150)
        self.assertEqual(self.window.findChildren(QLineEdit), [])

        screen = self.app.primaryScreen().availableGeometry()
        island_center = self.window.geometry().center().x()
        self.assertLessEqual(abs(island_center - screen.center().x()), 1)
        self.assertGreaterEqual(self.window.y(), screen.y())

    def test_voice_states_expand_and_show_details(self):
        self.window.set_state("starting_microphone")
        QTest.qWait(100)
        self.assertEqual(self.window.phase, "starting")

        self.window.activation_notice("alpha")
        QTest.qWait(250)
        self.assertEqual(self.window.phase, "armed")
        self.assertGreater(self.window.width(), 300)

        self.window.set_state("listening_wake")
        QTest.qWait(250)
        self.assertEqual(self.window.phase, "dormant")
        self.assertIn(
            'Say "Alpha"',
            self.window._transcript_label.text(),
        )
        self.assertFalse(self.window.isVisible())

        self.window.set_dashboard_data({
            "system": {"cpu_percent": 22, "ram_percent": 48},
            "battery": {"percent": 81, "plugged": True},
        })
        self.window.set_details_visible(True)
        QTest.qWait(250)
        self.assertTrue(self.window.details_visible)

        self.window.show_confirmation("Shut down the computer? Say yes or no.")
        QTest.qWait(250)
        self.assertEqual(self.window.phase, "confirming")
        self.assertTrue(self.window.details_visible)

    def test_click_cancels_thinking_instead_of_opening_details(self):
        cancelled = []
        self.window.cancel_requested.connect(lambda: cancelled.append(True))
        self.window.set_state("thinking")
        QTest.qWait(100)

        QTest.mouseClick(self.window, Qt.LeftButton)
        QTest.qWait(50)

        self.assertEqual(cancelled, [True])
        self.assertFalse(self.window.details_visible)

    def test_ghost_mode_hides_idle_and_shows_on_activation(self):
        self.window.set_state("listening_wake")
        QTest.qWait(100)
        self.assertFalse(self.window.isVisible())

        self.window.activation_notice("alpha")
        QTest.qWait(100)
        self.assertTrue(self.window.isVisible())

    def test_non_exact_activation_source_cannot_show_island(self):
        self.window.activation_notice("background_audio")
        QTest.qWait(100)
        self.assertFalse(self.window.isVisible())


if __name__ == "__main__":
    unittest.main()
