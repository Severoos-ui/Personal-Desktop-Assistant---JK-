"""Browser and compound YouTube music command regression checks."""

import sys
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.automation.browser import BrowserController
from alpha.automation.register_commands import register_desktop_commands
from alpha.commands.engine import CommandEngine, CommandStatus
from alpha.commands.registry import CommandRegistry


class TestYouTubeMusic(unittest.TestCase):
    def test_some_music_uses_a_real_default_query(self):
        self.assertEqual(
            BrowserController._normalise_music_query("some music"),
            "relaxing music mix",
        )

    def test_first_result_opens_in_requested_browser(self):
        browser = BrowserController(default_browser="system")
        with (
            patch.object(
                browser,
                "_first_youtube_video_id",
                return_value="abcdefghijk",
            ),
            patch.object(
                browser,
                "_open_in_named_browser",
                return_value=True,
            ) as open_named,
        ):
            response = browser.play_youtube_music(
                "some music",
                browser_name="Brave",
            )

        target_url, browser_name = open_named.call_args.args
        self.assertIn("watch?v=abcdefghijk", target_url)
        self.assertEqual(browser_name, "Brave")
        self.assertEqual(
            response,
            "Playing relaxing music mix on YouTube in Brave.",
        )


class TestCompoundBrowserCommand(unittest.TestCase):
    def test_open_brave_and_play_music_is_one_action(self):
        registry = CommandRegistry()
        desktop = MagicMock()
        browser = MagicMock()
        system = MagicMock()
        browser.play_youtube_music.return_value = (
            "Playing relaxing music mix on YouTube in Brave."
        )
        register_desktop_commands(registry, desktop, browser, system)
        engine = CommandEngine(registry)

        results = engine.execute(
            "open Brave and play some music with in YouTube"
        )

        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].status, CommandStatus.SUCCESS)
        self.assertEqual(
            results[0].command_name,
            "open_browser_play_youtube_music",
        )
        browser.play_youtube_music.assert_called_once_with(
            "some music",
            browser_name="Brave",
        )
        desktop.open_app.assert_not_called()


if __name__ == "__main__":
    unittest.main()
