"""Desktop application closing regression checks."""

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from alpha.automation.desktop import DesktopController


class TestWindowsApplicationClosing(unittest.TestCase):
    def setUp(self):
        self.desktop = DesktopController.__new__(DesktopController)

    @patch("alpha.automation.desktop.subprocess.run")
    def test_calculator_uses_real_windows_process_aliases(self, run):
        run.return_value = SimpleNamespace(
            returncode=0,
            stdout="1\n",
            stderr="",
        )

        response = self.desktop.close_app("Calculator app.")

        self.assertEqual(response, "Closed calculator.")
        environment = run.call_args.kwargs["env"]
        candidates = environment["ALPHA_PROCESS_CANDIDATES"].split(";")
        self.assertIn("calculatorapp", candidates)
        self.assertEqual(environment["ALPHA_APP_QUERY"], "calculator")

    @patch("alpha.automation.desktop.subprocess.run")
    def test_generic_program_can_match_process_or_window_title(self, run):
        run.return_value = SimpleNamespace(
            returncode=0,
            stdout="1\n",
            stderr="",
        )

        response = self.desktop.close_app("My Notes program")

        self.assertEqual(response, "Closed my notes.")
        environment = run.call_args.kwargs["env"]
        self.assertEqual(environment["ALPHA_APP_QUERY"], "my notes")
        self.assertIn(
            "mynotes",
            environment["ALPHA_PROCESS_CANDIDATES"].split(";"),
        )

    @patch("alpha.automation.desktop.subprocess.run")
    def test_unsaved_work_prompt_is_not_force_closed(self, run):
        run.return_value = SimpleNamespace(
            returncode=0,
            stdout="1|1\n",
            stderr="",
        )

        response = self.desktop.close_app("Word")

        self.assertIn("waiting for you to save", response)

    @patch("alpha.automation.desktop.subprocess.run")
    def test_windows_and_alpha_processes_are_protected(self, run):
        for app_name in ("Alpha", "Windows", "File Explorer"):
            with self.subTest(app_name=app_name):
                response = self.desktop.close_app(app_name)
                self.assertIn("won't close", response)
        run.assert_not_called()


class TestDesktopInputControl(unittest.TestCase):
    def setUp(self):
        self.desktop = DesktopController.__new__(DesktopController)
        self.desktop._pyautogui = MagicMock()
        self.desktop._pyautogui.KEYBOARD_KEYS = [
            "enter", "esc", "tab", "space", "backspace", "delete",
            "home", "end", "pgup", "pgdn", "up", "down", "left", "right",
        ]
        self.desktop._pyautogui.size.return_value = (1920, 1080)

    @patch("alpha.automation.desktop.time.sleep")
    def test_types_ordinary_text_in_focused_app(self, sleep):
        response = self.desktop.type_text("meeting notes")

        self.assertEqual(response, "Typed it.")
        self.desktop._pyautogui.write.assert_called_once_with(
            "meeting notes",
            interval=0.015,
        )

    def test_refuses_to_type_spoken_secrets(self):
        response = self.desktop.type_text("my password is example")

        self.assertIn("won't type secrets", response)
        self.desktop._pyautogui.write.assert_not_called()

    def test_scroll_and_click_are_bounded(self):
        self.assertEqual(
            self.desktop.scroll_screen("down", 7),
            "Scrolled down.",
        )
        self.desktop._pyautogui.scroll.assert_called_once_with(-7)

        self.assertEqual(
            self.desktop.click_at(500, 300),
            "Clicked at 500, 300.",
        )
        self.desktop._pyautogui.click.assert_called_once_with(
            x=500,
            y=300,
            clicks=1,
            interval=0.12,
        )

        self.assertIn(
            "outside the screen",
            self.desktop.click_at(2000, 300),
        )

    def test_common_shortcut_and_spoken_key_alias(self):
        self.assertEqual(
            self.desktop.keyboard_shortcut("save"),
            "Save.",
        )
        self.desktop._pyautogui.hotkey.assert_called_once_with("ctrl", "s")

        self.assertEqual(
            self.desktop.press_key("page down"),
            "Pressed page down.",
        )
        self.desktop._pyautogui.press.assert_called_once_with("pgdn")


if __name__ == "__main__":
    unittest.main()
