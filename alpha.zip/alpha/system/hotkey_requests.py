"""Low-overhead request channel used by Alpha's Windows hotkey shortcuts."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QObject, QTimer, Signal

from alpha.utils.logger import get_logger


log = get_logger("hotkeys")


class HotkeyRequestService(QObject):
    """Convert local request files into thread-safe Qt lifecycle signals."""

    activate_requested = Signal()
    quit_requested = Signal()

    def __init__(self, data_dir: Path, poll_interval_ms: int = 120):
        super().__init__()
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.activate_path = self.data_dir / "activate.request"
        self.quit_path = self.data_dir / "quit.request"
        self._timer = QTimer(self)
        self._timer.setInterval(max(50, int(poll_interval_ms)))
        self._timer.timeout.connect(self._poll)

    def start(self) -> None:
        self._timer.start()
        # Consume a request created immediately before Alpha finished loading.
        QTimer.singleShot(0, self._poll)

    def stop(self) -> None:
        self._timer.stop()

    @staticmethod
    def _consume(path: Path) -> bool:
        try:
            path.unlink()
            return True
        except FileNotFoundError:
            return False
        except OSError as exc:
            log.warning("Could not consume hotkey request %s: %s", path.name, exc)
            return False

    def _poll(self) -> None:
        # Full quit wins if both shortcuts were pressed almost simultaneously.
        if self._consume(self.quit_path):
            log.info("Alt+F12 full-quit request received")
            self.quit_requested.emit()
            return
        if self._consume(self.activate_path):
            log.info("Alt+F11 activation request received")
            self.activate_requested.emit()
