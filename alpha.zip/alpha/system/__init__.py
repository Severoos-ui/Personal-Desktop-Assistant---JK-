"""Operating-system integration services for Alpha."""

from alpha.system.hotkey_requests import HotkeyRequestService

__all__ = ["HotkeyRequestService"]
