"""Original offline sound effects for Alpha's lifecycle and voice feedback.

The cues are synthesized at runtime, so no copyrighted movie audio or bundled
sound files are required.
"""

import threading
from collections.abc import Sequence

import numpy as np

from alpha.utils.logger import get_logger

log = get_logger("sounds")

_sound_stream = None
_stream_lock = threading.RLock()
_SAMPLE_RATE = 44100

# Public durations let the Qt lifecycle wait until the shutdown cue finishes.
POWER_ON_DURATION_SECONDS = 0.72
POWER_OFF_DURATION_SECONDS = 0.66


def _get_stream(sample_rate: int = _SAMPLE_RATE):
    """Get or open a sounddevice output stream."""
    global _sound_stream
    with _stream_lock:
        if _sound_stream is not None:
            return _sound_stream, sample_rate
        try:
            import sounddevice as sd

            _sound_stream = sd.OutputStream(
                samplerate=sample_rate,
                channels=1,
                dtype="float32",
            )
            _sound_stream.start()
            return _sound_stream, sample_rate
        except Exception as e:
            log.debug("Audio output unavailable: %s", e)
            return None, sample_rate


def _envelope(
    size: int,
    sample_rate: int,
    attack: float,
    release: float,
) -> np.ndarray:
    """Return a click-free attack/release envelope."""

    env = np.ones(max(0, int(size)), dtype=np.float64)
    if not len(env):
        return env
    attack_samples = min(len(env), max(0, int(attack * sample_rate)))
    release_samples = min(len(env), max(0, int(release * sample_rate)))
    if attack_samples:
        env[:attack_samples] = np.linspace(
            0.0,
            1.0,
            attack_samples,
            endpoint=False,
        )
    if release_samples:
        env[-release_samples:] = np.linspace(
            1.0,
            0.0,
            release_samples,
            endpoint=True,
        )
    return env


def _tone_wave(
    frequencies: float | Sequence[float],
    duration: float,
    volume: float,
    sample_rate: int = _SAMPLE_RATE,
    attack: float = 0.012,
    release: float = 0.055,
) -> np.ndarray:
    """Render one clean tone or harmonic chord."""

    values = (
        [float(frequencies)]
        if isinstance(frequencies, (int, float))
        else [float(value) for value in frequencies]
    )
    size = max(1, int(sample_rate * max(0.0, duration)))
    timeline = np.arange(size, dtype=np.float64) / sample_rate
    wave = np.zeros(size, dtype=np.float64)
    for frequency in values:
        wave += np.sin(2.0 * np.pi * frequency * timeline)
    wave /= max(1, len(values))
    wave *= _envelope(size, sample_rate, attack, release)
    return (wave * float(volume)).astype(np.float32)


def _sweep_wave(
    start_frequency: float,
    end_frequency: float,
    duration: float,
    volume: float,
    sample_rate: int = _SAMPLE_RATE,
) -> np.ndarray:
    """Render a harmonic frequency sweep for a futuristic machine effect."""

    size = max(1, int(sample_rate * max(0.0, duration)))
    frequencies = np.geomspace(
        max(20.0, float(start_frequency)),
        max(20.0, float(end_frequency)),
        size,
    )
    phase = 2.0 * np.pi * np.cumsum(frequencies) / sample_rate
    # A quieter octave and metallic fifth make the sweep feel machine-like.
    wave = (
        np.sin(phase)
        + 0.32 * np.sin(phase * 2.0)
        + 0.18 * np.sin(phase * 1.5)
    ) / 1.5
    wave *= _envelope(size, sample_rate, 0.018, 0.09)
    return (wave * float(volume)).astype(np.float32)


def _silence(duration: float, sample_rate: int = _SAMPLE_RATE) -> np.ndarray:
    return np.zeros(max(1, int(sample_rate * duration)), dtype=np.float32)


def _play_wave(wave: np.ndarray) -> None:
    """Play a complete cue on one daemon worker."""

    def _run():
        global _sound_stream
        stream, _ = _get_stream()
        if stream is None:
            return
        try:
            with _stream_lock:
                stream.write(np.asarray(wave, dtype=np.float32))
        except Exception as exc:
            log.debug("Sound cue playback error: %s", exc)
            with _stream_lock:
                try:
                    stream.close()
                except Exception:
                    pass
                _sound_stream = None

    threading.Thread(
        target=_run,
        daemon=True,
        name="alpha-sound-cue",
    ).start()


def _play_tone(frequencies, duration=0.3, volume=0.2, attack=0.02, release=0.08):
    """Play a synthesized tone (single or multiple frequencies as chord)."""
    _play_wave(
        _tone_wave(
            frequencies,
            duration,
            volume,
            attack=attack,
            release=release,
        )
    )


def play_power_on() -> None:
    """Rising machine boot cue used when Alt+F11 makes Alpha ready."""

    cue = np.concatenate(
        (
            _sweep_wave(145.0, 720.0, 0.30, 0.18),
            _silence(0.025),
            _tone_wave((659.25, 987.77), 0.13, 0.17),
            _silence(0.018),
            _tone_wave((880.0, 1318.51), 0.22, 0.20),
        )
    )
    _play_wave(cue)


def play_power_off() -> None:
    """Descending machine shutdown cue used before Alt+F12 exits."""

    cue = np.concatenate(
        (
            _tone_wave((880.0, 1318.51), 0.11, 0.18),
            _silence(0.018),
            _sweep_wave(760.0, 105.0, 0.34, 0.19),
            _silence(0.018),
            _tone_wave((110.0, 164.81), 0.17, 0.18),
        )
    )
    _play_wave(cue)


def play_activation():
    """Two-note rising chime when the Alpha wake word is recognized."""
    _play_tone([880], duration=0.08, volume=0.15, release=0.05)
    timer = threading.Timer(
        0.09,
        lambda: _play_tone(
            [1320],
            duration=0.15,
            volume=0.18,
            release=0.1,
        ),
    )
    timer.daemon = True
    timer.start()


def play_listening():
    """Soft hum to indicate listening start."""
    _play_tone([523], duration=0.1, volume=0.1)
