"""Regional time helpers for Alpha.

Alpha is configured for Nepal, independent of an incorrect Windows timezone.
All timestamps remain stored as Unix UTC seconds; this module controls only
how local dates and clock times are interpreted and displayed.
"""

from __future__ import annotations

from datetime import datetime
from zoneinfo import ZoneInfo


NEPAL_TIMEZONE = ZoneInfo("Asia/Kathmandu")


def nepal_now() -> datetime:
    """Return the current wall-clock time in Nepal."""

    return datetime.now(NEPAL_TIMEZONE)


def nepal_from_timestamp(timestamp: float) -> datetime:
    """Render a stored Unix timestamp in Nepal time."""

    return datetime.fromtimestamp(float(timestamp), NEPAL_TIMEZONE)
