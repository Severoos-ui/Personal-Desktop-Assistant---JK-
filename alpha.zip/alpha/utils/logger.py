"""Centralized logging for ALPHA AI."""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler, QueueHandler, QueueListener
import queue
from typing import Optional


_JSON_FORMAT = False
_EMOJI_MAP = {
    "DEBUG": "🔍", "INFO": "ℹ️ ", "WARNING": "⚠️ ",
    "ERROR": "❌", "CRITICAL": "💥", "VOICE": "🎤",
    "CMD": "⚡", "UI": "🎨", "AI": "🧠", "MEM": "💾", "NET": "🌐"
}

VOICE_LEVEL = 25
CMD_LEVEL = 26
UI_LEVEL = 27
AI_LEVEL = 28
MEM_LEVEL = 29
NET_LEVEL = 30

for name, level in [("VOICE", VOICE_LEVEL), ("CMD", CMD_LEVEL), ("UI", UI_LEVEL),
                     ("AI", AI_LEVEL), ("MEM", MEM_LEVEL), ("NET", NET_LEVEL)]:
    logging.addLevelName(level, name)


class AlphaFormatter(logging.Formatter):
    """Custom formatter with colors, timestamps, and component tags."""

    COLORS = {
        "DEBUG": "\033[36m", "INFO": "\033[32m", "WARNING": "\033[33m",
        "ERROR": "\033[31m", "CRITICAL": "\033[41m\033[37m",
        "VOICE": "\033[95m", "CMD": "\033[93m", "UI": "\033[94m",
        "AI": "\033[96m", "MEM": "\033[37m", "NET": "\033[92m"
    }
    RESET = "\033[0m"

    def __init__(self, use_color: bool = True, use_symbols: bool = True):
        super().__init__()
        self.use_color = use_color
        self.use_symbols = use_symbols

    def format(self, record: logging.LogRecord) -> str:
        ts = self.formatTime(record, datefmt="%Y-%m-%d %H:%M:%S")
        lvl = record.levelname
        emoji = _EMOJI_MAP.get(lvl, "•") if self.use_symbols else "-"
        msg = record.getMessage()
        tag = f"[{record.name}]" if record.name != "root" else ""
        if self.use_color:
            c = self.COLORS.get(lvl, "")
            return f"{c}{ts} {emoji} {lvl:<8}{self.RESET} {tag} {msg}"
        return f"{ts} {emoji} {lvl:<8} {tag} {msg}"


class SafeUnicodeStreamHandler(logging.StreamHandler):
    """Write Unicode logs even when the Windows console uses cp1252."""

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = self.format(record)
            stream = self.stream
            try:
                stream.write(message + self.terminator)
            except UnicodeEncodeError:
                encoding = getattr(stream, "encoding", None) or "utf-8"
                safe_message = message.encode(
                    encoding,
                    errors="backslashreplace",
                ).decode(encoding)
                stream.write(safe_message + self.terminator)
            self.flush()
        except Exception:
            self.handleError(record)


_logger_instance: Optional["AlphaLogger"] = None


class AlphaLogger:
    """Production-ready async logger with file rotation and console output."""

    def __init__(self, log_file: str, level: str = "INFO", max_bytes: int = 5_000_000,
                 backup_count: int = 5):
        self.log_file = Path(log_file)
        self.log_file.parent.mkdir(parents=True, exist_ok=True)
        self.level = getattr(logging, level.upper(), logging.INFO)
        self.queue: queue.Queue = queue.Queue(-1)
        self.queue_handler = QueueHandler(self.queue)

        # File handler with rotation
        self.file_handler = RotatingFileHandler(
            log_file, maxBytes=max_bytes, backupCount=backup_count, encoding="utf-8"
        )
        self.file_handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-8s [%(name)s] %(message)s"
        ))

        # pythonw.exe intentionally provides no stdout/stderr. Keep file
        # logging active without constructing a broken console handler.
        self.console_handler = None
        listener_handlers = [self.file_handler]
        console_stream = sys.stdout or sys.stderr
        if console_stream is not None:
            self.console_handler = SafeUnicodeStreamHandler(console_stream)
            console_encoding = getattr(console_stream, "encoding", None) or "utf-8"
            try:
                "⚡".encode(console_encoding)
                supports_symbols = True
            except (LookupError, UnicodeEncodeError):
                supports_symbols = False
            self.console_handler.setFormatter(AlphaFormatter(
                use_color=bool(getattr(console_stream, "isatty", lambda: False)()),
                use_symbols=supports_symbols,
            ))
            listener_handlers.append(self.console_handler)

        self.listener = QueueListener(
            self.queue,
            *listener_handlers,
            respect_handler_level=True,
        )

        self.root = logging.getLogger("alpha")
        self.root.setLevel(self.level)
        self.root.handlers.clear()
        self.root.addHandler(self.queue_handler)
        self._module_loggers = {}
        self._started = False

    def start(self):
        if not self._started:
            self.listener.start()
            self._started = True

    def stop(self):
        if self._started:
            self.listener.stop()
            self._started = False
        self.root.removeHandler(self.queue_handler)
        for handler in (self.file_handler, self.console_handler):
            if handler is not None:
                handler.flush()
                handler.close()

    def get(self, name: str) -> logging.Logger:
        if name not in self._module_loggers:
            self._module_loggers[name] = self.root.getChild(name)
        return self._module_loggers[name]


def setup_logger(log_file: str = "", level: str = "INFO") -> AlphaLogger:
    global _logger_instance
    if _logger_instance is None:
        from alpha.config.settings import ConfigManager
        cfg = ConfigManager.instance().config
        lf = log_file or cfg.log_file
        _logger_instance = AlphaLogger(lf, level=cfg.log_level if not level else level)
        _logger_instance.start()
    return _logger_instance


def get_logger(name: str = "core") -> logging.Logger:
    if _logger_instance is None:
        setup_logger()
    return _logger_instance.get(name)


def log_voice(msg: str):
    get_logger("voice").log(VOICE_LEVEL, msg)


def log_cmd(msg: str):
    get_logger("cmd").log(CMD_LEVEL, msg)


def log_ui(msg: str):
    get_logger("ui").log(UI_LEVEL, msg)


def log_ai(msg: str):
    get_logger("ai").log(AI_LEVEL, msg)


def log_mem(msg: str):
    get_logger("mem").log(MEM_LEVEL, msg)


def log_net(msg: str):
    get_logger("net").log(NET_LEVEL, msg)
