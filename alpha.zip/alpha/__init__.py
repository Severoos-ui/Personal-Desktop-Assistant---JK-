"""Alpha voice assistant package using the stable alpha module."""

__version__ = "0.1.0"
DISPLAY_NAME = "Alpha"
WAKE_PHRASE = "Alpha"
