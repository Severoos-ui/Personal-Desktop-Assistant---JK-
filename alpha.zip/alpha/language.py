"""English/Nepali language detection, mixed-command routing, and local replies."""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass


DEVANAGARI_RE = re.compile(r"[\u0900-\u097F]")
SUPPORTED_LANGUAGE_CODES = frozenset({"en", "ne"})
UNSUPPORTED_LANGUAGE_MESSAGE = (
    "Sorry, I currently support only English and Nepali. "
    "म अहिले अंग्रेजी र नेपाली भाषा मात्र समर्थन गर्छु।"
)


@dataclass(frozen=True)
class LanguageDecision:
    code: str
    supported: bool
    reason: str


def validate_spoken_language(
    text: str,
    detected_code: str = "",
    probability: float = 0.0,
) -> LanguageDecision:
    """Allow only English, Nepali, or their natural mixed form.

    Whisper's single multilingual acoustic model is retained because an
    English-only model cannot recognize Nepali. Its broader language IDs are
    treated only as a rejection signal and never enable another language.
    """

    value = str(text or "").strip()
    code = str(detected_code or "").casefold().split("-", 1)[0]
    confidence = max(0.0, min(1.0, float(probability or 0.0)))
    has_nepali_script = bool(DEVANAGARI_RE.search(value))
    if has_nepali_script and code in {"", "ne"}:
        return LanguageDecision("ne", True, "Nepali Unicode detected")
    if not has_nepali_script and code in {"", "en"}:
        return LanguageDecision("en", True, "English speech detected")
    if confidence < 0.70:
        inferred = "ne" if has_nepali_script else "en"
        return LanguageDecision(
            inferred,
            True,
            "low-confidence acoustic language ID; constrained by script",
        )
    return LanguageDecision(
        code or "unsupported",
        False,
        f"unsupported acoustic language ID: {code or 'unknown'}",
    )


def contains_unsupported_script(text: str) -> bool:
    """Reject non-Latin/non-Devanagari scripts before text-to-speech."""

    for character in str(text or ""):
        if not character.isalpha():
            continue
        point = ord(character)
        if 0x0900 <= point <= 0x097F:
            continue
        name = unicodedata.name(character, "")
        if "LATIN" not in name:
            return True
    return False


def detect_language(text: str) -> str:
    """Return ``ne`` for Nepali Unicode/mixed speech, otherwise ``en``."""

    return "ne" if DEVANAGARI_RE.search(str(text or "")) else "en"


def normalize_command(text: str) -> str:
    """Translate common Nepali/mixed desktop intents to local command syntax.

    Unknown Nepali remains unchanged and is passed to the conversational model.
    """

    original = " ".join(str(text or "").strip().split())
    if detect_language(original) != "ne":
        return original

    clean = original.strip(" ।.!?,")
    lower = clean.casefold()

    exact = {
        "आजको काम के छ": "daily briefing",
        "आजको काम के छ?": "daily briefing",
        "मेरो काम के छ": "what are my tasks",
        "मेरो कामहरू के छन्": "what are my tasks",
        "रिमाइन्डर के छ": "what are my reminders",
        "मेरो रिमाइन्डर के छ": "what are my reminders",
        "आवाज बढाऊ": "volume up",
        "आवाज बढाइदेऊ": "volume up",
        "आवाज घटाऊ": "volume down",
        "आवाज घटाइदेऊ": "volume down",
        "आवाज बन्द गर": "mute",
        "आवाज खोल": "unmute",
        "स्क्रिनसट लेऊ": "take screenshot",
        "स्क्रिनसट खिच": "take screenshot",
        "सेभ गर": "save",
        "कपी गर": "copy",
        "पेस्ट गर": "paste",
        "अनडु गर": "undo",
        "अर्को एपमा जाऊ": "switch app",
        "अर्को विन्डोमा जाऊ": "switch app",
        "मेरो स्क्रिनमा के छ": "what is on my screen",
        "स्क्रिन पढ": "read my screen",
        "कम्प्युटर बन्द गर": "shutdown",
        "कम्प्युटर रिस्टार्ट गर": "restart",
        "कम्प्युटर पुनः सुरु गर": "restart",
        "कम्प्युटर स्लीप गर": "sleep pc",
    }
    if lower in exact:
        return exact[lower]

    # "YouTube मा lo-fi music play गर।"
    match = re.fullmatch(
        r"(?:youtube|युट्युब)\s+मा\s+(.+?)\s+"
        r"(?:play|प्ले)\s+(?:गर|गर्नुहोस्|गरिदेऊ)",
        clean,
        re.IGNORECASE,
    )
    if match:
        return f"play {match.group(1)} on youtube"

    # "lo-fi music YouTube मा play गर।"
    match = re.fullmatch(
        r"(.+?)\s+(?:youtube|युट्युब)\s+मा\s+"
        r"(?:play|प्ले)\s+(?:गर|गर्नुहोस्|गरिदेऊ)",
        clean,
        re.IGNORECASE,
    )
    if match:
        return f"play {match.group(1)} on youtube"

    # "VS Code open गर।"
    match = re.fullmatch(
        r"(.+?)\s+(?:open|ओपन)\s+"
        r"(?:गर|गर्नुहोस्|गरिदेऊ|गरिदिनुहोस्)",
        clean,
        re.IGNORECASE,
    )
    if match:
        return f"open {_clean_target(match.group(1))}"

    # "Chrome खोल।", "Downloads folder खोल।"
    match = re.fullmatch(
        r"(.+?)\s+(?:खोल|खोल्नुहोस्|खोलिदेऊ|खोलिदिनुहोस्)",
        clean,
        re.IGNORECASE,
    )
    if match:
        return f"open {_clean_target(match.group(1))}"

    match = re.fullmatch(
        r"(.+?)\s+(?:close|क्लोज|बन्द)\s+"
        r"(?:गर|गर्नुहोस्|गरिदेऊ|गरिदिनुहोस्)",
        clean,
        re.IGNORECASE,
    )
    if match:
        return f"close {_clean_target(match.group(1))}"

    # "meeting notes टाइप गर।"
    match = re.fullmatch(
        r"(.+?)\s+(?:type|टाइप)\s+"
        r"(?:गर|गर्नुहोस्|गरिदेऊ|गरिदिनुहोस्)",
        clean,
        re.IGNORECASE,
    )
    if match:
        return f"type {match.group(1)}"

    # Basic task/note phrasing.
    match = re.fullmatch(
        r"(.+?)\s+(?:काम|टास्क)\s+थप",
        clean,
        re.IGNORECASE,
    )
    if match:
        return f"add task {match.group(1)}"

    match = re.fullmatch(
        r"(?:नोट\s+गर|नोट\s+लेख)\s+(.+)",
        clean,
        re.IGNORECASE,
    )
    if match:
        return f"take a note {match.group(1)}"

    return original


def localize_response(text: str, language: str) -> str:
    """Render common local command responses in Nepali Unicode."""

    response = str(text or "").strip()
    if language != "ne" or not response:
        return response
    if DEVANAGARI_RE.search(response):
        return response

    exact = {
        "Done.": "भयो।",
        "Cancelled.": "रद्द गरियो।",
        "Typed it.": "टाइप गरें।",
        "Switched applications.": "अर्को एपमा गएँ।",
        "Save.": "सेभ गरें।",
        "Copy.": "कपी गरें।",
        "Paste.": "पेस्ट गरें।",
        "Undo.": "अघिल्लो परिवर्तन फिर्ता गरें।",
        "Muted.": "आवाज बन्द गरें।",
        "Unmuted.": "आवाज खोलें।",
        "Your task list is clear.": "तपाईंको कार्यसूची खाली छ।",
        "You have no active reminders.": "तपाईंका सक्रिय रिमाइन्डर छैनन्।",
        "You have no saved notes.": "तपाईंका सुरक्षित नोट छैनन्।",
        "Your timer is finished.": "तपाईंको टाइमर सकियो।",
    }
    if response in exact:
        return exact[response]

    patterns = [
        (
            r"^Opening (.+?)\.$",
            lambda m: f"{m.group(1)} खोल्दैछु।",
        ),
        (
            r"^Closed (.+?)\.$",
            lambda m: f"{m.group(1)} बन्द गरें।",
        ),
        (
            r"^Switched to (.+?)\.$",
            lambda m: f"{m.group(1)} मा गएँ।",
        ),
        (
            r"^Scrolled (up|down)\.$",
            lambda m: (
                "माथि स्क्रोल गरें।"
                if m.group(1) == "up"
                else "तल स्क्रोल गरें।"
            ),
        ),
        (
            r"^Pressed (.+?)\.$",
            lambda m: f"{m.group(1)} थिचें।",
        ),
        (
            r"^Timer set for (.+?)\.$",
            lambda m: f"{m.group(1)} का लागि टाइमर सेट गरें।",
        ),
        (
            r"^Reminder set for (.+?): (.+?)\.$",
            lambda m: f"{m.group(2)} का लागि रिमाइन्डर सेट गरें: {m.group(1)}।",
        ),
        (
            r"^Completed task: (.+?)\.$",
            lambda m: f"कार्य पूरा गरियो: {m.group(1)}।",
        ),
        (
            r"^Saved your note: (.+?)\.$",
            lambda m: f"नोट सुरक्षित गरें: {m.group(1)}।",
        ),
        (
            r"^I(?:'|’)ll remember that your (.+?) is (.+?)\.$",
            lambda m: f"तपाईंको {m.group(1)} {m.group(2)} हो भनेर सम्झन्छु।",
        ),
        (
            r"^Good (?:morning|afternoon|evening)\. You have "
            r"(\d+) pending tasks?, (\d+) active reminders?, and "
            r"(\d+) reminders? due today\.$",
            lambda m: (
                f"नमस्ते। तपाईंका {m.group(1)} बाँकी काम, "
                f"{m.group(2)} सक्रिय रिमाइन्डर, र आजका लागि "
                f"{m.group(3)} रिमाइन्डर छन्।"
            ),
        ),
        (
            r"^You have (\d+) pending tasks?\. (.+)$",
            lambda m: (
                f"तपाईंका {m.group(1)} बाँकी काम छन्। {m.group(2)}"
            ),
        ),
        (
            r"^You have (\d+) active reminders?\. (.+)$",
            lambda m: (
                f"तपाईंका {m.group(1)} सक्रिय रिमाइन्डर छन्। {m.group(2)}"
            ),
        ),
        (
            r"^Added (.+?) to your (.+?) priority tasks\.$",
            lambda m: (
                f"{m.group(1)} लाई {m.group(2)} प्राथमिकताको काममा थपें।"
            ),
        ),
    ]
    for pattern, render in patterns:
        match = re.match(pattern, response, re.IGNORECASE)
        if match:
            return render(match)

    if response.startswith("Are you sure"):
        return (
            "यो संवेदनशील कार्य गर्न निश्चित हुनुहुन्छ? "
            "कृपया हो वा होइन भन्नुहोस्।"
        )
    if "Gemini has reached its current API quota" in response:
        return (
            "Gemini को हालको API सीमा सकिएको छ। स्थानीय कम्प्युटर "
            "कमाण्डहरू अझै चल्छन्, तर खुला कुराकानीका लागि सीमा फेरि "
            "उपलब्ध हुनुपर्छ।"
        )
    if response.startswith("I heard you, but"):
        return (
            "मैले सुनेँ, तर यो अनुरोधलाई स्थानीय कमाण्डसँग मिलाउन सकिनँ। "
            "कृपया फेरि स्पष्ट रूपमा भन्नुहोस्।"
        )
    return response


def is_affirmative(text: str) -> bool:
    clean = " ".join(str(text or "").casefold().strip(" ।.!?,").split())
    return bool(
        re.match(
            r"^(?:yes|yeah|yep|sure|ok|okay|proceed|do it|go ahead|"
            r"confirm|हो|हुन्छ|ठीक छ|गर्नुहोस्|गर)$",
            clean,
        )
    )


def is_negative(text: str) -> bool:
    clean = " ".join(str(text or "").casefold().strip(" ।.!?,").split())
    return bool(
        re.match(
            r"^(?:no|nope|cancel|don't|do not|stop|nevermind|abort|"
            r"होइन|हुँदैन|रद्द गर|नगर|बन्द गर)$",
            clean,
        )
    )


def _clean_target(value: str) -> str:
    target = " ".join(str(value).strip().split())
    target = re.sub(r"^(?:मेरो|यो)\s+", "", target, flags=re.IGNORECASE)
    target = re.sub(
        r"\s+(?:app|application|folder|file|"
        r"एप|एप्लिकेसन|फोल्डर|फाइल)$",
        "",
        target,
        flags=re.IGNORECASE,
    )
    aliases = {
        "डाउनलोड्स": "Downloads",
        "डकुमेन्ट्स": "Documents",
        "क्याल्कुलेटर": "Calculator",
        "नोटप्याड": "Notepad",
        "सेटिङ्स": "Settings",
        "ब्रेव": "Brave",
        "क्रोम": "Chrome",
        "भीएस कोड": "VS Code",
    }
    return aliases.get(target.casefold(), target)
