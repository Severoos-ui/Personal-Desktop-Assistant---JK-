"""Low-overhead latency, resource, and thread-health monitoring."""

from __future__ import annotations

import contextlib
import statistics
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import DefaultDict, Iterator

from alpha.utils.logger import get_logger


log = get_logger("performance")


@dataclass(frozen=True)
class Metric:
    name: str
    latency_ms: float
    success: bool
    timestamp: float
    detail: str = ""


class PerformanceMonitor:
    """Collect bounded metrics without retaining prompts or personal data."""

    def __init__(self, history_size: int = 250):
        self._metrics: DefaultDict[str, deque[Metric]] = defaultdict(
            lambda: deque(maxlen=max(20, int(history_size)))
        )
        self._lock = threading.RLock()
        self._started = time.monotonic()

    def record(
        self,
        name: str,
        latency_ms: float,
        success: bool = True,
        detail: str = "",
    ) -> Metric:
        metric = Metric(
            name=name,
            latency_ms=max(0.0, float(latency_ms)),
            success=bool(success),
            timestamp=time.time(),
            detail=str(detail or "")[:120],
        )
        with self._lock:
            self._metrics[name].append(metric)
        log.info(
            "PERF metric=%s latency_ms=%.1f success=%s%s",
            name,
            metric.latency_ms,
            metric.success,
            f" detail={metric.detail}" if metric.detail else "",
        )
        return metric

    @contextlib.contextmanager
    def span(self, name: str, detail: str = "") -> Iterator[None]:
        started = time.perf_counter()
        success = False
        try:
            yield
            success = True
        finally:
            self.record(
                name,
                (time.perf_counter() - started) * 1000,
                success,
                detail,
            )

    def snapshot(self) -> dict:
        with self._lock:
            metrics = {
                name: list(values)
                for name, values in self._metrics.items()
            }
        summary = {}
        for name, values in metrics.items():
            latencies = [item.latency_ms for item in values]
            successes = sum(1 for item in values if item.success)
            summary[name] = {
                "count": len(values),
                "success_rate": (
                    round(successes / len(values), 3) if values else 1.0
                ),
                "last_ms": round(latencies[-1], 1) if latencies else 0.0,
                "avg_ms": round(statistics.fmean(latencies), 1)
                if latencies
                else 0.0,
                "max_ms": round(max(latencies), 1) if latencies else 0.0,
            }
        resources = {
            "cpu_percent": 0.0,
            "ram_mb": 0.0,
            "threads": threading.active_count(),
        }
        try:
            import os
            import psutil

            process = psutil.Process(os.getpid())
            resources.update(
                cpu_percent=process.cpu_percent(interval=None),
                ram_mb=round(process.memory_info().rss / 1024 / 1024, 1),
                threads=process.num_threads(),
            )
        except Exception:
            pass
        return {
            "uptime_seconds": round(time.monotonic() - self._started, 1),
            "resources": resources,
            "metrics": summary,
        }

