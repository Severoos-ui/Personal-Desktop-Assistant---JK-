"""One managed asyncio loop and bounded executors for all background work."""

from __future__ import annotations

import asyncio
import concurrent.futures
import functools
import threading
from typing import Any, Awaitable, Callable

from alpha.runtime.events import EventBus
from alpha.runtime.performance import PerformanceMonitor
from alpha.utils.logger import get_logger


log = get_logger("runtime")


class ServiceRuntime:
    """Own async scheduling so services do not create unmanaged threads."""

    def __init__(
        self,
        event_bus: EventBus | None = None,
        performance: PerformanceMonitor | None = None,
        io_workers: int = 6,
        compute_workers: int = 2,
    ):
        self.events = event_bus or EventBus()
        self.performance = performance or PerformanceMonitor()
        self._io_pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=max(2, int(io_workers)),
            thread_name_prefix="alpha-io",
        )
        self._compute_pool = concurrent.futures.ThreadPoolExecutor(
            max_workers=max(1, int(compute_workers)),
            thread_name_prefix="alpha-compute",
        )
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(
            target=self._run_loop,
            daemon=True,
            name="alpha-runtime",
        )
        self._started = threading.Event()
        self._stopping = threading.Event()

    def start(self) -> None:
        if self._thread.is_alive():
            return
        self._thread.start()
        self._started.wait(timeout=3.0)
        self.events.publish("runtime.started", source="runtime")

    def _run_loop(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._started.set()
        self._loop.run_forever()
        pending = asyncio.all_tasks(self._loop)
        for task in pending:
            task.cancel()
        if pending:
            self._loop.run_until_complete(
                asyncio.gather(*pending, return_exceptions=True)
            )
        self._loop.close()

    def submit(
        self,
        coroutine: Awaitable[Any],
    ) -> concurrent.futures.Future:
        if not self._thread.is_alive():
            self.start()
        return asyncio.run_coroutine_threadsafe(coroutine, self._loop)

    async def run_blocking(
        self,
        func: Callable[..., Any],
        *args,
        pool: str = "io",
        **kwargs,
    ) -> Any:
        loop = asyncio.get_running_loop()
        executor = self._compute_pool if pool == "compute" else self._io_pool
        call = functools.partial(func, *args, **kwargs)
        return await loop.run_in_executor(executor, call)

    def stop(self, timeout: float = 3.0) -> None:
        if self._stopping.is_set():
            return
        self._stopping.set()
        self.events.publish("runtime.stopping", source="runtime")
        if self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread.is_alive():
            self._thread.join(timeout=max(0.1, timeout))
        self._io_pool.shutdown(wait=False, cancel_futures=True)
        self._compute_pool.shutdown(wait=False, cancel_futures=True)
        log.info("Service runtime stopped")

    def health(self) -> dict:
        return {
            "loop_alive": self._thread.is_alive(),
            "stopping": self._stopping.is_set(),
            **self.performance.snapshot(),
        }
