"""Thread-safe event bus for loosely coupled Alpha services."""

from __future__ import annotations

import asyncio
import inspect
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable, DefaultDict

from alpha.utils.logger import get_logger


log = get_logger("runtime.events")
EventHandler = Callable[["Event"], Any]


@dataclass(frozen=True)
class Event:
    name: str
    payload: dict[str, Any] = field(default_factory=dict)
    source: str = ""
    timestamp: float = field(default_factory=time.time)


class EventBus:
    """Publish service events without coupling producers to consumers."""

    def __init__(self):
        self._handlers: DefaultDict[str, list[EventHandler]] = defaultdict(list)
        self._lock = threading.RLock()

    def subscribe(self, name: str, handler: EventHandler) -> Callable[[], None]:
        with self._lock:
            self._handlers[name].append(handler)

        def unsubscribe() -> None:
            with self._lock:
                handlers = self._handlers.get(name, [])
                if handler in handlers:
                    handlers.remove(handler)

        return unsubscribe

    def publish(
        self,
        name: str,
        payload: dict[str, Any] | None = None,
        source: str = "",
    ) -> None:
        event = Event(name=name, payload=payload or {}, source=source)
        with self._lock:
            handlers = [
                *self._handlers.get(name, ()),
                *self._handlers.get("*", ()),
            ]
        for handler in handlers:
            try:
                result = handler(event)
                if inspect.isawaitable(result):
                    try:
                        loop = asyncio.get_running_loop()
                    except RuntimeError:
                        asyncio.run(result)
                    else:
                        loop.create_task(result)
            except Exception as exc:
                log.error(
                    "Event handler failed event=%s error_type=%s",
                    name,
                    type(exc).__name__,
                )

    async def publish_async(
        self,
        name: str,
        payload: dict[str, Any] | None = None,
        source: str = "",
    ) -> None:
        event = Event(name=name, payload=payload or {}, source=source)
        with self._lock:
            handlers = [
                *self._handlers.get(name, ()),
                *self._handlers.get("*", ()),
            ]
        for handler in handlers:
            try:
                result = handler(event)
                if inspect.isawaitable(result):
                    await result
            except Exception as exc:
                log.error(
                    "Async event handler failed event=%s error_type=%s",
                    name,
                    type(exc).__name__,
                )

