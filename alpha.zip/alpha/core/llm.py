"""Legacy local/Gemini client retained for screen vision and offline fallback."""

import base64
import json
import os
import re
import time
import threading
from pathlib import Path
from typing import List, Dict, Optional, Iterator
from dataclasses import dataclass, field
from enum import Enum

import urllib.request
import urllib.error

from alpha.utils.logger import get_logger, log_ai
from alpha.utils.local_time import nepal_now

log = get_logger("llm")


@dataclass
class Message:
    role: str  # system, user, assistant
    content: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class LLMResponse:
    text: str
    model: str = ""
    tokens_used: int = 0
    latency_ms: float = 0.0
    is_offline: bool = True
    error: Optional[str] = None
    command: Optional[Dict] = None  # parsed [[CMD:action|...]] block
    commands: List[Dict] = field(default_factory=list)


class LLMClient:
    """
    Unified LLM interface.
    A securely stored GEMINI_API_KEY selects the native Gemini endpoint.
    Ollama remains available as a local, offline provider.
    Fallback: Smart rule-based engine (works fully offline without any model).
    """

    def __init__(self, config=None):
        from alpha.config.settings import ConfigManager
        cfg = config or ConfigManager.instance().config.llm
        gemini_key = os.environ.get("GEMINI_API_KEY", "").strip()
        # A securely stored Gemini credential is an explicit provider choice.
        # This also prevents a stale runtime config from silently reverting to
        # Ollama after a Windows background-process restart.
        if gemini_key:
            self.provider = "gemini"
            self.model = (
                cfg.model
                if cfg.provider == "gemini" and str(cfg.model).strip()
                else os.environ.get("GEMINI_MODEL", "gemini-flash-latest")
            )
            self.base_url = (
                cfg.base_url
                if cfg.provider == "gemini" and str(cfg.base_url).strip()
                else "https://generativelanguage.googleapis.com/v1beta"
            ).rstrip("/")
            self.api_key = gemini_key
        else:
            self.provider = cfg.provider
            self.model = cfg.model
            self.base_url = cfg.base_url.rstrip("/")
            self.api_key = cfg.api_key
        self.temperature = cfg.temperature
        self.max_tokens = cfg.max_tokens
        self.system_prompt = cfg.system_prompt
        self.timeout = 15
        self._available = False
        self._lock = threading.Lock()
        self._check_availability()

    def _check_availability(self):
        if self.provider == "ollama":
            self._available = self._ollama_check()
            if not self._available:
                log.warning("Ollama not reachable; falling back to rule-based engine")
                self.provider = "rule"
        elif self.provider == "gemini":
            self._available = bool(self.api_key)
            if not self._available:
                log.warning(
                    "GEMINI_API_KEY is not available; falling back to rule-based engine"
                )
                self.provider = "rule"
            else:
                log.info("Gemini configured with model '%s'.", self.model)
        else:
            self._available = True

    def _ollama_check(self) -> bool:
        try:
            req = urllib.request.Request(f"{self.base_url}/api/tags", method="GET")
            with urllib.request.urlopen(req, timeout=3) as r:
                data = json.loads(r.read())
                models = [m.get("name", "") for m in data.get("models", [])]
                if any(self.model.split(":")[0] in m for m in models):
                    log.info(f"Ollama connected; model '{self.model}' available")
                    return True
                # Model not pulled, but Ollama is up. Report available; will auto-pull or fail.
                log.info(f"Ollama up but model '{self.model}' not pulled; will try on first chat")
                return True
        except Exception as e:
            log.info(f"Ollama not reachable: {e}")
            return False

    def chat(self, messages: List[Message], context: Optional[Dict] = None) -> LLMResponse:
        start = time.time()
        try:
            if self.provider == "ollama":
                return self._ollama_chat(messages, start)
            if self.provider == "gemini":
                return self._gemini_chat(messages, start)
            return self._rule_based(messages, start, context or {})
        except urllib.error.HTTPError as exc:
            log.error(f"LLM HTTP error ({self.provider}): {exc.code}")
            if self.provider == "gemini" and exc.code == 429:
                return LLMResponse(
                    text=(
                        "Gemini has reached its current API quota. I can still "
                        "control apps and the laptop locally, but open-ended "
                        "AI conversation needs the quota to reset or a local "
                        "Ollama model."
                    ),
                    model=self.model,
                    latency_ms=(time.time() - start) * 1000,
                    is_offline=True,
                    error="HTTP 429",
                )
            return self._rule_based(messages, start, context or {})
        except Exception as e:
            log.error(f"LLM error ({self.provider}): {e}")
            return self._rule_based(messages, start, context or {})

    def chat_stream(self, messages: List[Message]) -> Iterator[str]:
        """Stream response tokens (best effort)."""
        if self.provider == "ollama":
            yield from self._ollama_stream(messages)
        else:
            resp = self.chat(messages)
            # yield in chunks
            words = resp.text.split(" ")
            out = ""
            for w in words:
                out += w + " "
                if len(out) > 40:
                    yield out
                    out = ""
                    time.sleep(0.04)
            if out:
                yield out

    # ---- Ollama ----

    def _ollama_chat(self, messages: List[Message], start: float) -> LLMResponse:
        payload = {
            "model": self.model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "stream": False,
            "options": {"temperature": self.temperature, "num_predict": self.max_tokens},
        }
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            f"{self.base_url}/api/chat",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=max(self.timeout, 30)) as r:
            body = json.loads(r.read())
        content = body.get("message", {}).get("content", "").strip()
        commands = self._extract_commands(content)
        cmd = commands[0] if commands else None
        return LLMResponse(
            text=self._strip_command(content),
            model=self.model,
            tokens_used=body.get("eval_count", 0),
            latency_ms=(time.time() - start) * 1000,
            is_offline=True,
            command=cmd,
            commands=commands,
        )

    def _ollama_stream(self, messages: List[Message]) -> Iterator[str]:
        payload = {
            "model": self.model,
            "messages": [{"role": m.role, "content": m.content} for m in messages],
            "stream": True,
            "options": {"temperature": self.temperature, "num_predict": self.max_tokens},
        }
        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            f"{self.base_url}/api/chat",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                for line in r:
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                        tok = obj.get("message", {}).get("content", "")
                        if tok:
                            yield tok
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            log.error(f"Ollama stream error: {e}")
            yield "Sorry, I had trouble thinking of a response."

    # ---- OpenAI-compatible ----

    def _gemini_chat(
        self,
        messages: List[Message],
        start: float,
    ) -> LLMResponse:
        """Call Gemini's native generateContent API with an auth key."""

        system_parts = [
            {"text": m.content}
            for m in messages
            if m.role == "system" and m.content.strip()
        ]
        contents = []
        for message in messages:
            if message.role == "system" or not message.content.strip():
                continue
            contents.append({
                "role": "model" if message.role == "assistant" else "user",
                "parts": [{"text": message.content}],
            })

        payload = {"contents": contents}
        if system_parts:
            payload["system_instruction"] = {"parts": system_parts}
        # Keep generation controls compatible with both stable model IDs and
        # Google's moving "flash-latest" alias.
        payload["generationConfig"] = {
            "maxOutputTokens": self.max_tokens,
        }

        base_url = self.base_url or (
            "https://generativelanguage.googleapis.com/v1beta"
        )
        url = f"{base_url}/models/{self.model}:generateContent"
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "x-goog-api-key": self.api_key,
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            body = json.loads(response.read())

        candidates = body.get("candidates") or []
        parts = (
            candidates[0].get("content", {}).get("parts", [])
            if candidates
            else []
        )
        content = " ".join(
            str(part.get("text", "")).strip()
            for part in parts
            if part.get("text")
        ).strip()
        if not content:
            feedback = body.get("promptFeedback", {})
            raise RuntimeError(
                f"Gemini returned no text ({feedback or 'empty response'})"
            )
        commands = self._extract_commands(content)
        command = commands[0] if commands else None
        usage = body.get("usageMetadata", {})
        return LLMResponse(
            text=self._strip_command(content),
            model=self.model,
            tokens_used=int(usage.get("totalTokenCount", 0) or 0),
            latency_ms=(time.time() - start) * 1000,
            is_offline=False,
            command=command,
            commands=commands,
        )

    def analyze_image(
        self,
        image_path: str | Path,
        prompt: str,
    ) -> LLMResponse:
        """Analyze one local image through Gemini's native multimodal API."""

        start = time.time()
        if self.provider != "gemini" or not self.api_key:
            return LLMResponse(
                text=(
                    "Screen vision needs a configured Gemini connection."
                ),
                model=self.model,
                latency_ms=(time.time() - start) * 1000,
                error="Gemini is unavailable",
            )

        try:
            path = Path(image_path)
            image_bytes = path.read_bytes()
            if len(image_bytes) > 15_000_000:
                raise ValueError("The screenshot is too large to analyze safely")

            payload = {
                "contents": [{
                    "role": "user",
                    "parts": [
                        {
                            "inline_data": {
                                "mime_type": "image/png",
                                "data": base64.b64encode(
                                    image_bytes
                                ).decode("ascii"),
                            }
                        },
                        {"text": prompt},
                    ],
                }],
                "generationConfig": {
                    "maxOutputTokens": self.max_tokens,
                },
            }
            url = f"{self.base_url}/models/{self.model}:generateContent"
            request = urllib.request.Request(
                url,
                data=json.dumps(payload).encode("utf-8"),
                headers={
                    "Content-Type": "application/json",
                    "x-goog-api-key": self.api_key,
                },
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=35) as response:
                body = json.loads(response.read())

            candidates = body.get("candidates") or []
            parts = (
                candidates[0].get("content", {}).get("parts", [])
                if candidates
                else []
            )
            content = " ".join(
                str(part.get("text", "")).strip()
                for part in parts
                if part.get("text")
            ).strip()
            if not content:
                raise RuntimeError("Gemini returned no screen description")
            usage = body.get("usageMetadata", {})
            return LLMResponse(
                text=content,
                model=self.model,
                tokens_used=int(
                    usage.get("totalTokenCount", 0) or 0
                ),
                latency_ms=(time.time() - start) * 1000,
                is_offline=False,
            )
        except urllib.error.HTTPError as exc:
            if exc.code == 429:
                message = (
                    "Screen vision is temporarily rate-limited. "
                    "Please try again in a minute."
                )
            else:
                message = "I couldn't analyze the screen right now."
            log.error(f"Gemini screen vision HTTP error: {exc.code}")
            return LLMResponse(
                text=message,
                model=self.model,
                latency_ms=(time.time() - start) * 1000,
                error=f"HTTP {exc.code}",
            )
        except Exception as exc:
            log.error(f"Screen vision error: {exc}")
            return LLMResponse(
                text="I couldn't analyze the screen right now.",
                model=self.model,
                latency_ms=(time.time() - start) * 1000,
                error=str(exc),
            )

    # ---- Rule-based fallback (always works offline) ----

    CMD_PATTERN = re.compile(r"\[\[CMD:([^\]]+)\]\]")

    def _extract_command(self, text: str) -> Optional[Dict]:
        commands = self._extract_commands(text)
        return commands[0] if commands else None

    def _extract_commands(self, text: str) -> List[Dict]:
        commands: List[Dict] = []
        for match in self.CMD_PATTERN.finditer(text or ""):
            raw = match.group(1).strip()
            parts = raw.split("|")
            action = parts[0].strip()
            if not action:
                continue
            params = {}
            for part in parts[1:]:
                if "=" in part:
                    key, value = part.split("=", 1)
                    params[key.strip()] = value.strip()
            commands.append({
                "action": action,
                "params": params,
                "raw": raw,
            })
        return commands

    def _strip_command(self, text: str) -> str:
        return self.CMD_PATTERN.sub("", text).strip()

    def _rule_based(self, messages: List[Message], start: float, context: Dict) -> LLMResponse:
        """
        Lightweight rule-based response engine used when no LLM is available.
        It produces conversational replies and recognizes explicit intents.
        """
        if not messages:
            return LLMResponse(text="Yes?", latency_ms=1)
        last = messages[-1].content.lower().strip()
        is_nepali = bool(re.search(r"[\u0900-\u097F]", last))

        if is_nepali:
            if "जोक" in last or "हँस" in last:
                return LLMResponse(
                    text=(
                        "कम्प्युटर किन चिसो भयो? किनकि उसले धेरै "
                        "विन्डोज खुला राखेको थियो!"
                    ),
                    latency_ms=5,
                    is_offline=True,
                )
            if "मौसम" in last:
                return LLMResponse(
                    text=(
                        "हालको मौसम जानकारीका लागि इन्टरनेट सेवा चाहिन्छ। "
                        "स्थानसहित फेरि सोध्नुहोस्।"
                    ),
                    latency_ms=5,
                    is_offline=True,
                )
            if any(word in last for word in ("धन्यवाद", "थ्याङ्क")):
                return LLMResponse(
                    text="स्वागत छ। म सहयोगका लागि तयार छु।",
                    latency_ms=5,
                    is_offline=True,
                )
            if any(word in last for word in ("बिदा", "फेरि भेटौँ")):
                return LLMResponse(
                    text="हुन्छ, फेरि भेटौँला।",
                    latency_ms=5,
                    is_offline=True,
                )

        # Greetings
        greetings = ["hi", "hello", "hey", "yo", "sup"]
        if any(last == g or last.startswith(g + " ") for g in greetings):
            return LLMResponse(
                text="Hey! How can I help you today?", latency_ms=5, is_offline=True
            )

        # Identity
        if any(k in last for k in ["who are you", "what are you", "your name"]):
            return LLMResponse(
                text="I'm Alpha, your intelligent companion. Say Alpha to wake me, "
                     "then speak follow-up requests naturally. I can open apps, search the web, control "
                     "your PC, and help with all sorts of tasks.",
                latency_ms=5, is_offline=True,
            )

        # How are you
        if "how are you" in last or "how's it going" in last or "how are things" in last:
            return LLMResponse(
                text="I'm running great — thanks for asking! Ready whenever you are. What's on your mind?",
                latency_ms=5, is_offline=True,
            )

        # Time / date
        if "what time" in last or "current time" in last:
            now = nepal_now().strftime("%I:%M %p").lstrip("0")
            return LLMResponse(text=f"It's {now}.", latency_ms=5, is_offline=True)
        if "what day" in last or "today's date" in last or "the date" in last:
            today = nepal_now().strftime("%A, %B %d, %Y")
            return LLMResponse(text=f"Today is {today}.", latency_ms=5, is_offline=True)

        # Jokes
        if "joke" in last or "tell me a joke" in last or "funny" in last:
            import random
            jokes = [
                "Why don't scientists trust atoms? Because they make up everything!",
                "I told my computer I needed a break, and it said 'No problem — I'll go to sleep.'",
                "Why did the developer go broke? Because he used up all his cache.",
                "Parallel lines have so much in common… it's a shame they'll never meet.",
                "I'm reading a book about anti-gravity. Can't put it down!",
            ]
            return LLMResponse(text=random.choice(jokes), latency_ms=5, is_offline=True)

        # Thanks
        if any(k in last for k in ["thank you", "thanks", "appreciate", "thx"]):
            return LLMResponse(text="Anytime! Just say the word.", latency_ms=5, is_offline=True)

        # Goodbye
        if any(k in last for k in ["bye", "goodbye", "see you", "see ya", "that's all"]):
            return LLMResponse(text="Catch you later!", latency_ms=5, is_offline=True)

        # Command pattern extraction: detect intents and emit [[CMD:...]] tags.
        # The command engine will pick these up if not already handled.
        # (The CommandEngine's registry match happens earlier in Brain; here we handle chat.)

        # Ability questions
        if any(k in last for k in ["what can you do", "help me", "help", "what commands"]):
            return LLMResponse(
                text="I can open apps like Brave, VS Code, and Notepad; search Google or YouTube; "
                     "control volume and brightness; take screenshots; create folders and files; "
                     "shutdown, restart, or sleep your PC; play music; check battery; and more. "
                     "For example, say \"Alpha, open Brave.\"",
                latency_ms=5, is_offline=True,
            )

        # Weather (needs online; tell user)
        if "weather" in last:
            return LLMResponse(
                text="I can check the weather for you — let me search that.",
                command={"action": "search", "params": {"engine": "google", "query": last}},
                latency_ms=5, is_offline=True,
            )

        # Default: acknowledge and offer to search
        return LLMResponse(
            text=(
                (
                    "मैले सुनेँ, तर यो अनुरोधलाई स्थानीय कम्प्युटर "
                    "कमाण्डसँग मिलाउन सकिनँ। कृपया फेरि स्पष्ट रूपमा "
                    "भन्नुहोस्।"
                )
                if is_nepali
                else (
                    "I heard you, but I could not match that to a laptop "
                    "action. Try a direct request such as open Camera, search "
                    "Google, or set volume to 50."
                )
            ),
            latency_ms=5, is_offline=True,
        )
