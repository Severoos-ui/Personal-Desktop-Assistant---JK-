"""Brain: orchestrates LLM, command engine, memory, and conversation context."""

import re
import time
import uuid
import threading
from typing import List, Optional, Callable, Dict, Any
from dataclasses import dataclass, field

from alpha.utils.logger import get_logger, log_ai, log_cmd, log_mem
from alpha.utils.local_time import nepal_now
from alpha.config.settings import ConfigManager
from alpha.ai import AIManager, AIMessage, AIResponse
from alpha.commands.engine import CommandEngine, CommandResult, CommandStatus
from alpha.memory.store import MemoryStore
from alpha.language import (
    detect_language,
    is_affirmative,
    is_negative,
    localize_response,
    normalize_command,
)

log = get_logger("brain")


@dataclass
class Conversation:
    session_id: str
    messages: List[AIMessage] = field(default_factory=list)
    started_at: float = field(default_factory=time.time)
    metadata: Dict = field(default_factory=dict)


class Brain:
    """
    The central reasoning module.
    - Maintains conversation context
    - Routes input to command engine or LLM
    - Saves to long-term memory
    - Handles confirmations and follow-ups
    """

    def __init__(
        self,
        command_engine: CommandEngine,
        memory: Optional[MemoryStore] = None,
        config=None,
        performance=None,
        events=None,
    ):
        self.config = config or ConfigManager.instance().config
        self.performance = performance
        self.events = events
        # Important integration point: all conversational AI now enters
        # through the provider-neutral manager. Alpha still owns memory.
        self.ai_manager = AIManager(self.config)
        self.cmd_engine = command_engine
        self.memory = memory
        self.session = Conversation(session_id=str(uuid.uuid4())[:8])
        self._response_listeners: List[Callable[[str], None]] = []
        self._thinking_listeners: List[Callable[[bool], None]] = []
        self._last_user_input: str = ""
        self.current_language = "en"
        self._lock = threading.RLock()
        # Seed system prompt
        self.session.messages.append(
            AIMessage(role="system", content=self._runtime_system_prompt())
        )

    def on_response(self, cb: Callable[[str], None]):
        self._response_listeners.append(cb)

    def on_thinking(self, cb: Callable[[bool], None]):
        self._thinking_listeners.append(cb)

    def cancel_current(self):
        """Clear pending confirmation/thinking state after a user interrupt."""

        if self.cmd_engine._pending_confirmation:
            self.cmd_engine.confirm(False)
        self._set_thinking(False)

    def new_session(self):
        with self._lock:
            self.session = Conversation(session_id=str(uuid.uuid4())[:8])
            self.session.messages.append(
                AIMessage(role="system", content=self._runtime_system_prompt())
            )
        log_ai(f"New session started: {self.session.session_id}")

    def _runtime_system_prompt(self) -> str:
        """Add the actual local controls to any user-configured personality."""

        command_catalog = self._command_catalog()
        voice = getattr(self.config, "voice", None)
        personality = getattr(self.config, "personality", None)
        wake_phrase = getattr(voice, "wake_phrase", "Alpha")
        assistant_name = getattr(personality, "name", "Alpha")
        return (
            f"{self.config.llm.system_prompt}\n\n"
            f"Runtime behavior: the only wake phrase is exactly '{wake_phrase}'. "
            f"After activation, continue the conversation naturally. {assistant_name} "
            "listens for follow-ups for 10 seconds after every reply; the user "
            "does not repeat the wake phrase during that active window. "
            "Automatically detect English, Nepali Unicode, and mixed "
            "Nepali-English. Always answer in the language of the latest user "
            "message and switch immediately when the user switches. Use "
            "natural Devanagari Nepali, not Hindi. "
            "Do not answer in or translate into any language other than English "
            "or Nepali; politely explain this two-language limit instead. "
            "Available local controls include "
            "opening, closing, and focusing Windows apps; typing ordinary "
            "non-secret text into the focused app; pressing keys; copy, "
            "paste, cut, undo, redo, save, select all, find, browser-tab, "
            "refresh, and print shortcuts; scrolling; bounded coordinate "
            "clicks; switching apps; minimizing, maximizing, and restoring "
            "the foreground window; web and YouTube actions; volume, "
            "brightness, files, screenshots, and explicit screen analysis. "
            "When an actionable request does not match locally, emit up to five "
            "directives using only exact actions and parameters from the "
            "allowlist below. Format each directive exactly as "
            "[[CMD:action|parameter=value]]. Never invent an action or "
            "parameter, never use a command directive for ordinary chat, and "
            "never say an action succeeded before the local result confirms it. "
            "The local confirmation gate still controls dangerous actions.\n"
            f"Local command allowlist:\n{command_catalog}\n"
            "Prefer a concise direct answer. Do not claim an action succeeded "
            "unless a local command result confirms it."
        )

    def _command_catalog(self) -> str:
        """Compact tool schema supplied to the conversational planner."""

        lines = []
        for command in sorted(
            self.cmd_engine.registry.all(),
            key=lambda item: item.name,
        ):
            params = []
            for definition in command.params:
                requirement = "required" if definition.required else "optional"
                params.append(
                    f"{definition.name}:{definition.type.value}:{requirement}"
                )
            param_text = ", ".join(params) if params else "no parameters"
            safety = " [confirmation required]" if (
                command.dangerous or command.requires_confirmation
            ) else ""
            lines.append(
                f"- {command.name}({param_text}){safety}: "
                f"{command.description or command.name}"
            )
        return "\n".join(lines)

    def process(self, user_input: str) -> str:
        """
        Process user input. Returns the text to speak/show to the user.
        Tries command engine first; falls back to LLM chat.
        """
        user_input = user_input.strip()
        if not user_input:
            return "I didn't catch that."

        with self._lock:
            self.current_language = detect_language(user_input)
            command_input = normalize_command(user_input)
            self._set_thinking(True)
            self._last_user_input = user_input

            # Append user message
            self.session.messages.append(
                AIMessage(role="user", content=user_input)
            )
            if self.memory:
                self.memory.add_message(self.session.session_id, "user", user_input)

            # 1. Check pending confirmation
            if self.cmd_engine._pending_confirmation:
                return self._handle_confirmation(user_input)

            # Time and date are deterministic local facts. Answer from Nepal's
            # clock immediately instead of spending an API call or trusting a
            # hosted model's region/timezone assumptions.
            local_clock_response = self._local_clock_response(user_input)
            if local_clock_response:
                self._finalize_response(local_clock_response)
                self._set_thinking(False)
                return local_clock_response

            # 2. Try command engine
            results = self.cmd_engine.execute(
                command_input,
                context={
                    "session": self.session.session_id,
                    "language": self.current_language,
                },
            )

            # If results contain a command that was handled (success or confirmation),
            # use the spoken response. If only UNKNOWN, fall through to LLM.
            recognized = [r for r in results if r.status != CommandStatus.UNKNOWN]
            unknowns = [r for r in results if r.status == CommandStatus.UNKNOWN]

            if recognized and not unknowns:
                response = localize_response(
                    self._compose_response(recognized),
                    self.current_language,
                )
                self._finalize_response(response)
                self._log_commands(user_input, recognized)
                self._set_thinking(False)
                return response

            if recognized and unknowns:
                # Execute recognized commands, chat about the rest
                cmd_response = self._compose_response(recognized)
                # Pass the unknown text to LLM
                unknown_text = " ".join(r.spoken_response for r in unknowns if r.spoken_response).strip()
                llm_resp = self._llm_chat(
                    extra_user_msg=(
                        unknown_text
                        if unknown_text != user_input
                        else None
                    )
                )
                planned = self._execute_planned_commands(llm_resp)
                if planned:
                    planned_response = self._compose_response(planned)
                    self._log_commands(user_input, planned)
                else:
                    planned_response = llm_resp.text
                response = localize_response(
                    (cmd_response + " " + planned_response).strip(),
                    self.current_language,
                )
                self._finalize_response(response)
                self._set_thinking(False)
                return response

            # 3. Pure LLM chat
            llm_resp = self._llm_chat()
            planned = self._execute_planned_commands(llm_resp)
            if planned:
                response = self._compose_response(planned)
                self._log_commands(user_input, planned)
            else:
                response = llm_resp.text
            response = localize_response(
                response,
                self.current_language,
            )
            self._finalize_response(response)
            self._set_thinking(False)
            return response

    def process_stream(self, user_input: str):
        """Yield real provider chunks for chat; buffer actionable requests."""

        if not self._safe_to_stream(user_input):
            yield self.process(user_input)
            return

        user_input = str(user_input or "").strip()
        if not user_input:
            yield "I didn't catch that."
            return

        with self._lock:
            self.current_language = detect_language(user_input)
            self._set_thinking(True)
            self._last_user_input = user_input
            self.session.messages.append(
                AIMessage(role="user", content=user_input)
            )
            if self.memory:
                self.memory.add_message(
                    self.session.session_id,
                    "user",
                    user_input,
                )
            messages = [
                AIMessage(
                    role=message.role,
                    content=(
                        self._runtime_system_prompt()
                        if message.role == "system"
                        else message.content
                    ),
                    timestamp=message.timestamp,
                )
                for message in self.session.messages
            ]
            full_text = ""
            speak_buffer = ""
            try:
                for chunk in self.ai_manager.ask_stream(
                    user_input,
                    history=messages,
                    system_prompt=self._runtime_system_prompt(),
                ):
                    full_text += chunk
                    speak_buffer += chunk
                    if (
                        len(speak_buffer) >= 100
                        or re.search(r"[.!?।]\s*$", speak_buffer)
                    ):
                        visible = speak_buffer.strip()
                        if visible:
                            yield visible
                        speak_buffer = ""
                if speak_buffer.strip():
                    yield speak_buffer.strip()
                clean_text = re.sub(
                    r"\[\[CMD:[^\]]*\]\]",
                    "",
                    full_text,
                ).strip()
                clean_text = localize_response(
                    clean_text
                    or "I'm not sure how to respond to that.",
                    self.current_language,
                )
                self._finalize_response(clean_text)
            finally:
                self._set_thinking(False)

    def _safe_to_stream(self, user_input: str) -> bool:
        """Do not stream requests that may produce a local command plan."""

        text = " ".join(str(user_input or "").casefold().split())
        action_markers = (
            "open ",
            "close ",
            "launch ",
            "start ",
            "play ",
            "type ",
            "write ",
            "click ",
            "press ",
            "scroll ",
            "switch ",
            "create ",
            "delete ",
            "shutdown",
            "restart",
            "remind ",
            "timer",
            "brightness",
            "volume",
            "screenshot",
            "screen",
            "what time",
            "current time",
            "time is it",
            "what date",
            "today's date",
            "todays date",
            "what day",
            "अहिले कति बज्यो",
            "समय कति भयो",
            "आज कति गते",
            "आज कुन बार",
            "खोल",
            "बन्द",
            "गर",
        )
        return not any(marker in text for marker in action_markers)

    @staticmethod
    def _local_clock_response(user_input: str) -> Optional[str]:
        """Return Nepal-local time/date for explicit clock questions."""

        text = " ".join(str(user_input or "").casefold().split())
        time_markers = (
            "what time",
            "current time",
            "time is it",
            "what's the time",
            "whats the time",
            "अहिले कति बज्यो",
            "समय कति भयो",
            "कति बज्यो",
        )
        date_markers = (
            "what date",
            "today's date",
            "todays date",
            "what day",
            "आज कति गते",
            "आज कुन बार",
            "आजको मिति",
        )
        now = nepal_now()
        language = detect_language(user_input)
        if any(marker in text for marker in time_markers):
            clock = now.strftime("%I:%M %p").lstrip("0")
            if language == "ne":
                return f"अहिले नेपालमा {clock} बजेको छ।"
            return f"It is {clock} in Nepal."
        if any(marker in text for marker in date_markers):
            if language == "ne":
                return f"आज नेपालको मिति {now:%Y-%m-%d} हो।"
            return f"Today in Nepal is {now:%A, %B %d, %Y}."
        return None

    # ---- Internals ----

    def _set_thinking(self, on: bool):
        for cb in self._thinking_listeners:
            try: cb(on)
            except Exception: pass

    def _handle_confirmation(self, text: str) -> str:
        yes = is_affirmative(text)
        no = is_negative(text)
        self._set_thinking(False)
        if yes:
            result = self.cmd_engine.confirm(True)
            response = localize_response(
                result.spoken_response or "Done.",
                self.current_language,
            )
            self._finalize_response(response)
            return response
        if no:
            result = self.cmd_engine.confirm(False)
            response = localize_response(
                result.spoken_response or "Cancelled.",
                self.current_language,
            )
            self._finalize_response(response)
            return response
        # Not a yes/no; cancel confirmation and process as new command
        self.cmd_engine.confirm(False)
        return self.process(text)

    def _llm_chat(
        self,
        extra_user_msg: Optional[str] = None,
    ) -> AIResponse:
        # Refresh the dynamic command catalog because screen/plugin commands
        # may be registered after Brain construction.
        messages = [
            AIMessage(
                role=message.role,
                content=(
                    self._runtime_system_prompt()
                    if message.role == "system"
                    else message.content
                ),
                timestamp=message.timestamp,
            )
            for message in self.session.messages
        ]
        request_text = extra_user_msg or self._last_user_input
        try:
            started = time.perf_counter()
            resp: AIResponse = self.ai_manager.ask(
                request_text,
                history=messages,
                system_prompt=self._runtime_system_prompt(),
            )
            text = resp.text or "I'm not sure how to respond to that."
            log_ai(
                f"AI response ({resp.model or 'managed'}): {text[:100]}..."
                if len(text) > 100
                else f"AI response: {text}"
            )
            resp.text = text
            if self.performance is not None:
                self.performance.record(
                    "ai_response",
                    resp.latency_ms or (
                        (time.perf_counter() - started) * 1000
                    ),
                    not bool(resp.error),
                    f"{resp.provider}:{resp.model}",
                )
            if self.events is not None:
                self.events.publish(
                    "ai.response",
                    {
                        "provider": resp.provider,
                        "model": resp.model,
                        "latency_ms": resp.latency_ms,
                        "success": not bool(resp.error),
                    },
                    source="brain",
                )
            return resp
        except Exception as e:
            log.error(f"AI manager failed: {e}")
            return AIResponse(
                text=(
                    "I'm having trouble thinking right now. "
                    "Could you try again?"
                ),
                error=str(e),
            )

    def _execute_planned_commands(
        self,
        response: AIResponse,
    ) -> List[CommandResult]:
        """Execute model plans only through the local registered allowlist."""

        commands = list(response.commands or [])
        if not commands and response.command:
            commands = [response.command]
        results: List[CommandResult] = []
        context = {
            "session": self.session.session_id,
            "language": self.current_language,
        }
        for plan in commands[:5]:
            action = str(plan.get("action", "")).strip()
            params = plan.get("params", {})
            if not action or not isinstance(params, dict):
                continue
            log_cmd(f"LLM allowlisted plan requested: {action} {params}")
            result = self.cmd_engine.execute_planned(
                action,
                params,
                context=context,
            )
            results.append(result)
            if result.status == CommandStatus.CONFIRMATION_REQUIRED:
                break
        return results

    def _compose_response(self, results: List[CommandResult]) -> str:
        parts = []
        for r in results:
            if r.spoken_response:
                parts.append(r.spoken_response)
            elif r.status == CommandStatus.SUCCESS:
                parts.append("Done.")
            elif r.status == CommandStatus.FAILED:
                parts.append(f"Sorry, {r.error or 'that failed'}.")
        return " ".join(parts)

    def _finalize_response(self, text: str):
        # Strip any command tags from spoken text
        text_clean = re.sub(r"\[\[CMD:[^\]]*\]\]", "", text).strip()
        self.session.messages.append(
            AIMessage(role="assistant", content=text_clean)
        )
        if self.memory:
            self.memory.add_message(self.session.session_id, "assistant", text_clean)
        for cb in self._response_listeners:
            try: cb(text_clean)
            except Exception: pass

    def _log_commands(self, user_text: str, results: List[CommandResult]):
        if self.memory:
            for r in results:
                self.memory.log_command(
                    text=user_text, name=r.command_name,
                    success=(r.status == CommandStatus.SUCCESS),
                    response=r.spoken_response
                )
