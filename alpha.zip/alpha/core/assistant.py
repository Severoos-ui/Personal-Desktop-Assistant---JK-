"""Top-level Alpha assistant: wires all subsystems together."""

import os
import time
import asyncio
from typing import Optional, Callable, List

from alpha.config.settings import ConfigManager, AppConfig
from alpha.utils.logger import setup_logger, get_logger
from alpha.utils.sounds import play_activation, play_listening
from alpha.utils.local_time import nepal_now
from alpha.voice.engine import VoiceEngine, VoiceState
from alpha.commands.registry import CommandRegistry
from alpha.commands.engine import CommandEngine
from alpha.automation.desktop import DesktopController
from alpha.automation.browser import BrowserController
from alpha.automation.system import SystemController
from alpha.automation.register_commands import (
    register_desktop_commands,
    register_screen_commands,
)
from alpha.memory.store import MemoryStore
from alpha.productivity.register_commands import (
    register_productivity_commands,
)
from alpha.productivity.service import ProductivityService
from alpha.core.brain import Brain
from alpha.core.llm import LLMClient
from alpha.vision.screen import ScreenVision
from alpha.runtime import EventBus, PerformanceMonitor, ServiceRuntime

log = get_logger("assistant")


class AlphaAssistant:
    """Main assistant orchestrator. Owns all subsystems and the lifecycle."""

    def __init__(self, config: Optional[AppConfig] = None):
        self.config_mgr = ConfigManager.instance()
        if config:
            self.config_mgr.config = config
        self.config = self.config_mgr.config

        # Logger now that config is loaded
        self.log_mgr = setup_logger(self.config.log_file, self.config.log_level)
        performance_cfg = getattr(self.config, "performance", None)
        self.events = EventBus()
        self.performance = PerformanceMonitor(
            history_size=int(
                getattr(performance_cfg, "history_size", 250)
            )
        )
        self.runtime = ServiceRuntime(
            event_bus=self.events,
            performance=self.performance,
        )
        self.runtime.start()

        log.info("=" * 60)
        log.info(f"{self.config.personality.name} AI Assistant v{self._version()} starting...")
        log.info(f"Platform: {os.name} | Python: {__import__('sys').version.split()[0]}")
        log.info(f"Data dir: {self.config.data_dir}")
        log.info("=" * 60)

        # Subsystems
        self.memory = MemoryStore(
            self.config.memory.db_path,
            encrypted=self.config.memory.encrypted,
            key_path=self.config.memory.encryption_key_path,
        )
        self.desktop = DesktopController()
        self.browser = BrowserController(default_browser=self.config.automation.browser_default)
        self.system = SystemController()
        self.productivity = ProductivityService(
            self.memory,
            due_callback=self._on_due_reminder,
        )

        self.registry = CommandRegistry()
        register_desktop_commands(self.registry, self.desktop, self.browser, self.system)
        register_productivity_commands(self.registry, self.productivity)

        self.cmd_engine = CommandEngine(
            self.registry,
            confirmation_callback=self._on_confirmation_needed,
        )

        self.brain = Brain(
            self.cmd_engine,
            self.memory,
            self.config,
            performance=self.performance,
            events=self.events,
        )
        # Screen vision keeps its existing Gemini-capable image client. Text
        # conversation never uses this legacy client.
        self.vision_llm = LLMClient(self.config.llm)
        self.screen_vision = ScreenVision(
            self.desktop,
            self.vision_llm,
            self.config.data_dir,
        )
        register_screen_commands(self.registry, self.screen_vision)
        self.voice = VoiceEngine(
            self.config,
            performance=self.performance,
            events=self.events,
        )
        self.voice.set_command_handler(self._on_voice_command)

        # UI callback hooks (set by UI layer)
        self._state_callbacks: List[Callable[[VoiceState], None]] = []
        self._transcript_callbacks: List[Callable[[str, str], None]] = []
        self._audio_callbacks: List[Callable[[float], None]] = []
        self._response_callbacks: List[Callable[[str], None]] = []
        self._thinking_callbacks: List[Callable[[bool], None]] = []
        self._activation_callbacks: List[Callable[[str], None]] = []
        self._confirmation_listener: Optional[Callable[[str], None]] = None
        self._confirmation_clear_listener: Optional[Callable[[], None]] = None
        import threading
        self._request_lock = threading.Lock()
        self._request_generation = 0
        self._active_request_future = None
        self._health_future = None

        self.running = False
        self._start_time = 0.0
        self._last_state = VoiceState.IDLE
        self._wire_callbacks()

    # ---------- Version ----------
    @staticmethod
    def _version() -> str:
        try:
            from alpha import __version__
            return __version__
        except Exception:
            return "0.1.0"

    # ---------- Lifecycle ----------

    def start(self):
        if self.running:
            return
        self.running = True
        self._start_time = time.time()
        self.voice.start()
        if bool(getattr(self.config.ai, "preload_clients", True)):
            self.runtime.submit(
                self.runtime.run_blocking(
                    self.brain.ai_manager.preload,
                    pool="io",
                )
            )
        self._health_future = self.runtime.submit(
            self._monitor_health()
        )
        # Dormant mode must not run a proactive reminder announcer. Reminders
        # remain persisted and are returned when the user asks after waking.
        self.brain.on_thinking(self._on_brain_thinking)
        # Greet
        log.info(
            '%s is dormant. Only exact "%s" can activate it.',
            self.config.personality.name,
            self.config.voice.wake_phrase,
        )
        self._greet()

    def stop(self):
        if not self.running:
            return
        self.running = False
        self.productivity.stop()
        self.voice.stop()
        if self._health_future is not None:
            self._health_future.cancel()
        self.runtime.stop()
        self.config_mgr.save()
        log.info("%s stopped. Goodbye.", self.config.personality.name)

    def is_running(self) -> bool:
        return self.running

    def uptime(self) -> float:
        return time.time() - self._start_time if self.running else 0

    # ---------- Public interaction ----------

    def say(self, text: str):
        """Directly speak a response."""
        self.voice.respond(text)

    def cancel_current(self):
        """Cancel the current voice interaction without quitting Alpha."""

        self.voice.cancel_current("interface")

    def activate(self) -> bool:
        """Activate listening from the local Alt+F11 lifecycle shortcut."""

        return self.voice.activate_from_hotkey()

    # ---------- UI event subscriptions ----------

    def on_state_change(self, cb: Callable[[VoiceState], None]):
        self._state_callbacks.append(cb)

    def on_transcript(self, cb: Callable[[str, str], None]):
        """(speaker, text) where speaker is 'user' or 'alpha'"""
        self._transcript_callbacks.append(cb)

    def on_audio_level(self, cb: Callable[[float], None]):
        self._audio_callbacks.append(cb)

    def on_response(self, cb: Callable[[str], None]):
        self._response_callbacks.append(cb)

    def on_thinking(self, cb: Callable[[bool], None]):
        self._thinking_callbacks.append(cb)

    def on_activation(self, cb: Callable[[str], None]):
        """Subscribe to exact wake-phrase activation notices."""
        self._activation_callbacks.append(cb)

    def set_confirmation_listener(self, cb: Callable[[str], None]):
        """Called when a dangerous command needs confirmation; CB receives prompt text."""
        self._confirmation_listener = cb

    def set_confirmation_clear_listener(self, cb: Callable[[], None]):
        """Called when a confirmation resolves, is cancelled, or times out."""
        self._confirmation_clear_listener = cb

    # ---------- Internal wiring ----------

    def _wire_callbacks(self):
        self.voice.on_state_change(self._fire_state)
        self.voice.on_audio_level(self._fire_audio)
        self.voice.on_transcript(self._fire_transcript_user)
        self.voice.on_activation(self._fire_activation)
        self.voice.on_cancel(self._on_voice_cancel)

    def _fire_state(self, state: VoiceState):
        # Play sound effects based on state transitions
        previous_state = self._last_state
        if state == VoiceState.LISTENING_CMD and self._last_state != VoiceState.LISTENING_CMD:
            try:
                play_listening()
            except Exception:
                pass
        self._last_state = state
        if (
            state == VoiceState.LISTENING_WAKE
            and previous_state in {
                VoiceState.PREPARING_CMD,
                VoiceState.LISTENING_CMD,
            }
            and self.cmd_engine._pending_confirmation
        ):
            self.brain.cancel_current()
            if self._confirmation_clear_listener:
                self._confirmation_clear_listener()
        for cb in self._state_callbacks:
            try: cb(state)
            except Exception as e: log.error(f"State callback error: {e}")

    def _fire_audio(self, level: float):
        for cb in self._audio_callbacks:
            try: cb(level)
            except Exception: pass

    def _fire_activation(self, source: str):
        if source == "alpha":
            try:
                play_activation()
            except Exception:
                pass
        for cb in self._activation_callbacks:
            try: cb(source)
            except Exception as e: log.error(f"Activation callback error: {e}")

    def _fire_transcript_user(self, text: str, is_final: bool):
        for cb in self._transcript_callbacks:
            try: cb("user", text)
            except Exception: pass

    def _on_voice_command(self, text: str):
        """Called from voice engine when a command is captured."""
        with self._request_lock:
            self._request_generation += 1
            request_generation = self._request_generation

        async def _run():
            started = time.perf_counter()
            success = False
            try:
                def consume_response() -> bool:
                    produced = False
                    display_text = ""
                    self.voice.begin_stream_response()
                    try:
                        for chunk in self.brain.process_stream(text):
                            with self._request_lock:
                                if (
                                    request_generation
                                    != self._request_generation
                                ):
                                    raise RuntimeError(
                                        "interaction cancelled"
                                    )
                            if (
                                self.cmd_engine._pending_confirmation
                                and self._confirmation_listener
                            ):
                                self._confirmation_listener(chunk)
                            elif self._confirmation_clear_listener:
                                self._confirmation_clear_listener()
                            display_text = (
                                f"{display_text} {chunk}".strip()
                            )
                            self._on_brain_response(display_text)
                            self.voice.queue_response_chunk(chunk)
                            produced = True
                    finally:
                        self.voice.end_stream_response()
                    return produced

                success = bool(
                    await self.runtime.run_blocking(
                        consume_response,
                        pool="io",
                    )
                )
            except asyncio.CancelledError:
                log.info("Assistant request task cancelled")
            except Exception as exc:
                with self._request_lock:
                    cancelled = (
                        request_generation != self._request_generation
                    )
                if cancelled:
                    log.info("Discarded response from cancelled interaction")
                else:
                    log.error(
                        "Assistant request failed error_type=%s",
                        type(exc).__name__,
                    )
                    self.voice.respond("Sorry, something went wrong.")
            finally:
                self.performance.record(
                    "total_response",
                    (time.perf_counter() - started) * 1000,
                    success,
                )

        self._active_request_future = self.runtime.submit(_run())

    def _on_voice_cancel(self, source: str):
        with self._request_lock:
            self._request_generation += 1
        self.brain.cancel_current()
        future = self._active_request_future
        if future is not None and not future.done():
            future.cancel()
        if self._confirmation_clear_listener:
            self._confirmation_clear_listener()
        log.info(f"Current interaction cancelled from {source}")

    async def _monitor_health(self) -> None:
        interval = max(
            10.0,
            float(
                getattr(
                    self.config.performance,
                    "log_resource_interval_seconds",
                    30.0,
                )
            ),
        )
        while self.running:
            await asyncio.sleep(interval)
            snapshot = self.runtime.health()
            resources = snapshot.get("resources", {})
            log.info(
                "HEALTH cpu_percent=%s ram_mb=%s threads=%s "
                "runtime_loop_alive=%s",
                resources.get("cpu_percent", 0),
                resources.get("ram_mb", 0),
                resources.get("threads", 0),
                snapshot.get("loop_alive", False),
            )
            self.events.publish(
                "runtime.health",
                snapshot,
                source="assistant",
            )

    def _on_brain_response(self, text: str):
        for cb in self._transcript_callbacks:
            try: cb("alpha", text)
            except Exception: pass
        for cb in self._response_callbacks:
            try: cb(text)
            except Exception: pass

    def _on_brain_thinking(self, thinking: bool):
        for cb in self._thinking_callbacks:
            try: cb(thinking)
            except Exception: pass

    def _on_confirmation_needed(self, message: str):
        if self._confirmation_listener:
            self._confirmation_listener(message)
        self.voice.respond(message)

    def _on_due_reminder(self, reminder: dict) -> bool:
        """Leave due reminders pending without breaking dormant mode."""

        log.info(
            "Reminder is due and remains pending until the user activates "
            "%s: %s",
            self.config.personality.name,
            reminder.get("title", "reminder"),
        )
        return False

    def _greet(self):
        """Startup greeting."""
        hour = nepal_now().hour
        if hour < 12:
            greeting = f"Good morning. {self.config.personality.name} is online."
        elif hour < 18:
            greeting = f"Good afternoon. {self.config.personality.name} is ready."
        else:
            greeting = f"Good evening. {self.config.personality.name} is online."
        # Don't speak automatically on startup to avoid surprise; just log.
        log.info(greeting)

    # ---------- Convenience methods for UI dashboard ----------

    def dashboard_data(self) -> dict:
        return {
            "version": self._version(),
            "uptime_seconds": int(self.uptime()),
            "state": self.voice.state.value if self.voice else "idle",
            "battery": self.system.battery_status(),
            "system": self.system.system_info(),
            "recent_commands": self.memory.recent_commands(limit=10) if self.memory else [],
            "reminders": self.memory.list_reminders() if self.memory else [],
            "pending_tasks": self.memory.list_tasks()[:5] if self.memory else [],
            "performance": self.runtime.health(),
            "ai_providers": self.brain.ai_manager.provider_health(),
        }
