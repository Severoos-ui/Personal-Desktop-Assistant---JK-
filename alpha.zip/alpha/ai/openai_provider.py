"""OpenAI-compatible adapter used through the shared OpenRouter API."""

from __future__ import annotations

import time
from typing import Iterator, Sequence

from alpha.ai.provider_base import (
    AIMessage,
    AIProvider,
    AIProviderError,
    AIResponse,
    parse_command_directives,
)


class OpenAIProvider(AIProvider):
    """Call one OpenRouter model through its OpenAI-compatible endpoint."""

    name = "openai"

    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str,
        max_tokens: int = 800,
        timeout_seconds: float = 45.0,
        provider_name: str = "openai",
    ):
        self.name = provider_name
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.max_tokens = max_tokens
        self.timeout_seconds = timeout_seconds
        self._client = None

    def _get_client(self):
        if self._client is not None:
            return self._client
        try:
            from openai import OpenAI
        except ImportError as exc:
            raise AIProviderError(
                "The OpenAI Python package is not installed."
            ) from exc
        self._client = OpenAI(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout_seconds,
            # Alpha owns provider fallback. SDK retries would silently multiply
            # the configured timeout and leave the UI stuck on "Thinking".
            max_retries=0,
        )
        return self._client

    def ask(
        self,
        messages: Sequence[AIMessage],
        system_prompt: str,
    ) -> AIResponse:
        started = time.perf_counter()
        try:
            response = self._get_client().chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": system_prompt,
                    },
                    *[
                        {
                            "role": message.role,
                            "content": message.content,
                        }
                        for message in messages
                        if message.role in {"user", "assistant"}
                        and message.content.strip()
                    ],
                ],
                max_tokens=self.max_tokens,
            )
            choices = getattr(response, "choices", [])
            text = (
                str(choices[0].message.content or "").strip()
                if choices
                else ""
            )
            if not text:
                raise AIProviderError("The AI service returned an empty response.")
            clean_text, commands = parse_command_directives(text)
            usage = getattr(response, "usage", None)
            total_tokens = int(getattr(usage, "total_tokens", 0) or 0)
            return AIResponse(
                text=clean_text,
                model=self.model,
                provider=self.name,
                tokens_used=total_tokens,
                latency_ms=(time.perf_counter() - started) * 1000,
                command=commands[0] if commands else None,
                commands=commands,
            )
        except AIProviderError:
            raise
        except Exception as exc:
            raise AIProviderError("The AI request failed.") from exc

    def stream(
        self,
        messages: Sequence[AIMessage],
        system_prompt: str,
    ) -> Iterator[str]:
        """Stream visible text from an OpenAI-compatible gateway."""

        try:
            response = self._get_client().chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    *[
                        {"role": message.role, "content": message.content}
                        for message in messages
                        if message.role in {"user", "assistant"}
                        and message.content.strip()
                    ],
                ],
                max_tokens=self.max_tokens,
                stream=True,
            )
            produced = False
            for chunk in response:
                choices = getattr(chunk, "choices", [])
                if not choices:
                    continue
                content = getattr(choices[0].delta, "content", None)
                if content:
                    produced = True
                    yield str(content)
            if not produced:
                raise AIProviderError("The AI service returned an empty stream.")
        except AIProviderError:
            raise
        except Exception as exc:
            raise AIProviderError("The streaming AI request failed.") from exc
