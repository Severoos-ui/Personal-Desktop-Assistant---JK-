"""Lightweight local intent classification for automatic AI routing."""

from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class IntentClassification:
    category: str
    provider: str
    reason: str
    confidence: float


class IntentClassifier:
    """Classify locally so provider choice never adds another API request."""

    _PROGRAMMING = re.compile(
        r"\b("
        r"algorithm|api|backend|bug|class|code|coding|compile|compiler|"
        r"database|debug|developer|exception|frontend|function|git|github|"
        r"html|java(?:script)?|library|linux|npm|program(?:ming)?|python|"
        r"react|refactor|regex|repository|runtime|sdk|software|sql|stack trace|"
        r"typescript|unit test|web app"
        r")\b|```|(?:^|\s)(?:def|class|function)\s+\w+",
        re.IGNORECASE,
    )
    _CREATIVE = re.compile(
        r"\b("
        r"creative writing|essay|fiction|novel|poem|poetry|screenplay|"
        r"short story|story|write a song|write lyrics"
        r")\b",
        re.IGNORECASE,
    )
    _COMPLEX_REASONING = re.compile(
        r"\b("
        r"analy[sz]e|architecture|decision|deep research|derive|diagnose|"
        r"equation|evaluate|investigate|mathematics?|optimi[sz]e|proof|"
        r"reasoning|research|root cause|strateg(?:y|ic)|trade-?offs?|"
        r"step by step|system design|why does"
        r")\b|(?:\d+\s*[\+\-\*/\^]\s*\d+)",
        re.IGNORECASE,
    )
    _OPENAI_KNOWN = re.compile(
        r"\b("
        r"brainstorm|breakfast|calendar|cook|date|dinner|explain|good morning|"
        r"good night|hello|help me feel|hi|how are you|idea|joke|life advice|"
        r"lunch|motivat|movie|music|nice to meet|productivity|recipe|"
        r"relationship|reminder|sad|small talk|time|translate|translation|"
        r"travel|weather|what is|what are|who is|why is"
        r")\b",
        re.IGNORECASE,
    )

    def classify(self, user_input: str) -> IntentClassification:
        text = (user_input or "").strip()
        if self._PROGRAMMING.search(text):
            return IntentClassification(
                category="programming",
                provider="claude",
                reason="programming or software-engineering intent",
                confidence=0.95,
            )
        if self._CREATIVE.search(text):
            return IntentClassification(
                category="creative_writing",
                provider="claude",
                reason="creative-writing intent",
                confidence=0.92,
            )
        if self._COMPLEX_REASONING.search(text):
            return IntentClassification(
                category="complex_reasoning",
                provider="claude",
                reason="complex analysis, research, mathematics, or planning",
                confidence=0.90,
            )
        if self._OPENAI_KNOWN.search(text):
            return IntentClassification(
                category="general_conversation",
                provider="openai",
                reason="general conversation or everyday-assistant intent",
                confidence=0.85,
            )
        return IntentClassification(
            category="general",
            provider="openai",
            reason="uncertain intent; using the configured default",
            confidence=0.50,
        )
