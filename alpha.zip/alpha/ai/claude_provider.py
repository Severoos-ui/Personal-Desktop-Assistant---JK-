"""Claude-model adapter using the shared OpenRouter connection."""

from __future__ import annotations

from alpha.ai.openai_provider import OpenAIProvider


class ClaudeProvider(OpenAIProvider):
    """Select a Claude model without changing gateway credentials or URL."""

    name = "claude"

    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str,
        max_tokens: int = 800,
        timeout_seconds: float = 45.0,
        temperature: float = 0.7,
    ):
        # Temperature remains accepted for configuration compatibility, but
        # the shared OpenRouter request omits it for cross-model compatibility.
        self.temperature = temperature
        super().__init__(
            api_key=api_key,
            model=model,
            base_url=base_url,
            max_tokens=max_tokens,
            timeout_seconds=timeout_seconds,
            provider_name=self.name,
        )
