"""Single entrypoint for every OpenRouter-backed conversation request."""

from __future__ import annotations

import asyncio
import os
import threading
import time
from pathlib import Path
from typing import Dict, Iterator, Optional, Sequence

from alpha.ai.cache import ResponseCache
from alpha.ai.legacy_provider import LegacyLLMProvider
from alpha.ai.claude_provider import ClaudeProvider
from alpha.ai.openai_provider import OpenAIProvider
from alpha.ai.provider_base import (
    AIMessage,
    AIProvider,
    AIResponse,
)
from alpha.ai.router import AIRouter
from alpha.utils.logger import get_logger


log = get_logger("ai.manager")
_ENV_TEMPLATE = (
    "# Alpha uses one OpenRouter credential for every conversational model.\n"
    "OPENROUTER_API_KEY=\n"
    "OPENROUTER_BASE_URL=https://openrouter.ai/api/v1\n"
    "\n"
    "OPENROUTER_OPENAI_MODEL=openai/gpt-oss-120b\n"
    "OPENROUTER_CLAUDE_MODEL=anthropic/claude-sonnet-4.6\n"
    "ALPHA_DEFAULT_PROVIDER=openai\n"
)


def _project_root() -> Path:
    return Path(__file__).resolve().parents[3]


def ensure_env_file(path: Path) -> None:
    """Create a safe placeholder file, never a hardcoded credential."""

    if not path.exists():
        path.write_text(_ENV_TEMPLATE, encoding="utf-8")


def _usable_key(value: str) -> bool:
    cleaned = (value or "").strip()
    return bool(cleaned) and not cleaned.casefold().startswith(
        ("your_", "replace_", "placeholder")
    )


class AIManager:
    """Route, call, log, and transparently fail over between providers."""

    def __init__(
        self,
        config=None,
        env_path: Optional[str | Path] = None,
        providers: Optional[Dict[str, AIProvider]] = None,
    ):
        from alpha.config.settings import ConfigManager

        app_config = config or ConfigManager.instance().config
        self.app_config = app_config
        self.config = getattr(app_config, "ai", app_config)
        self.env_path = Path(env_path) if env_path else _project_root() / ".env"
        ensure_env_file(self.env_path)
        try:
            from dotenv import load_dotenv
        except ImportError:
            log.warning(
                "python-dotenv is not installed; using process environment only"
            )
        else:
            load_dotenv(self.env_path, override=False)

        default_provider = os.environ.get(
            "ALPHA_DEFAULT_PROVIDER",
            getattr(self.config, "default_provider", "openai"),
        ).strip().casefold()
        self.router = AIRouter(default_provider=default_provider)
        self.cache = ResponseCache(
            max_entries=int(getattr(self.config, "cache_max_entries", 128)),
            ttl_seconds=float(
                getattr(self.config, "cache_ttl_seconds", 300.0)
            ),
        )
        self.cache_enabled = bool(
            getattr(self.config, "cache_enabled", True)
        )
        self.circuit_breaker_enabled = bool(
            getattr(self.config, "circuit_breaker_enabled", True)
        )
        self._health_lock = threading.RLock()
        self._failure_count: Dict[str, int] = {}
        self._unhealthy_until: Dict[str, float] = {}

        # Important: both logical providers share exactly one gateway
        # credential and URL. Routing changes only the model name.
        shared_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
        shared_base_url = os.environ.get(
            "OPENROUTER_BASE_URL",
            getattr(
                self.config,
                "base_url",
                "https://openrouter.ai/api/v1",
            ),
        ).strip().rstrip("/")
        gateway_ready = (
            _usable_key(shared_key)
            and shared_base_url.startswith(("https://", "http://"))
        )
        self._configured = {
            "openai": gateway_ready,
            "claude": gateway_ready,
        }
        if providers is None:
            self.providers: Dict[str, AIProvider] = {
                "openai": OpenAIProvider(
                    api_key=shared_key,
                    model=os.environ.get(
                        "OPENROUTER_OPENAI_MODEL",
                        getattr(self.config, "openai_model", "openai/gpt-oss-120b"),
                    ),
                    base_url=shared_base_url,
                    max_tokens=int(
                        getattr(self.config, "max_tokens", 800)
                    ),
                    timeout_seconds=float(
                        getattr(self.config, "timeout_seconds", 45.0)
                    ),
                ),
                "claude": ClaudeProvider(
                    api_key=shared_key,
                    model=os.environ.get(
                        "OPENROUTER_CLAUDE_MODEL",
                        getattr(
                            self.config,
                            "claude_model",
                            "anthropic/claude-sonnet-4.6",
                        ),
                    ),
                    base_url=shared_base_url,
                    max_tokens=int(
                        getattr(self.config, "max_tokens", 800)
                    ),
                    timeout_seconds=float(
                        getattr(self.config, "timeout_seconds", 45.0)
                    ),
                    temperature=float(
                        getattr(self.config, "temperature", 0.7)
                    ),
                ),
            }
            llm_config = getattr(app_config, "llm", None)
            if llm_config is not None:
                if os.environ.get("GEMINI_API_KEY", "").strip():
                    self.providers["gemini"] = LegacyLLMProvider(
                        "gemini",
                        llm_config,
                    )
                    self._configured["gemini"] = True
                if (
                    str(getattr(llm_config, "provider", "")).casefold()
                    == "ollama"
                    or os.environ.get("OLLAMA_ENABLED", "").casefold()
                    in {"1", "true", "yes", "on"}
                ):
                    self.providers["ollama"] = LegacyLLMProvider(
                        "ollama",
                        llm_config,
                    )
                    self._configured["ollama"] = True
        else:
            self.providers = dict(providers)
            # Injected providers are considered available for deterministic
            # tests and future locally hosted provider adapters.
            self._configured.update(
                {name: True for name in self.providers}
            )

    def preload(self) -> None:
        """Construct provider clients without making a network request."""

        for name, provider in self.providers.items():
            if not self._configured.get(name, False):
                continue
            getter = getattr(provider, "_get_client", None)
            if not callable(getter):
                continue
            try:
                getter()
                log.info("AI client preloaded provider=%s", name)
            except Exception as exc:
                log.warning(
                    "AI client preload failed provider=%s error_type=%s",
                    name,
                    type(exc).__name__,
                )

    def register_provider(self, name: str, provider: AIProvider) -> None:
        """Add Gemini, DeepSeek, Grok, Ollama, or another future adapter."""

        normalized = name.strip().casefold()
        self.providers[normalized] = provider
        self._configured[normalized] = True

    def provider_health(self) -> dict[str, dict]:
        now = time.monotonic()
        with self._health_lock:
            return {
                name: {
                    "configured": self._configured.get(name, False),
                    "failures": self._failure_count.get(name, 0),
                    "circuit_open": self._unhealthy_until.get(name, 0.0)
                    > now,
                    "retry_after_seconds": round(
                        max(0.0, self._unhealthy_until.get(name, 0.0) - now),
                        1,
                    ),
                }
                for name in self.providers
            }

    def missing_keys(self) -> list[str]:
        return (
            []
            if self._configured.get("openai", False)
            and self._configured.get("claude", False)
            else ["OPENROUTER_API_KEY"]
        )

    def setup_message(self) -> str:
        missing = self.missing_keys()
        if not missing:
            return ""
        return (
            "Alpha's online conversation needs OPENROUTER_API_KEY in the project "
            ".env file. Local laptop commands will still work."
        )

    def ask(
        self,
        user_input: str,
        history: Optional[Sequence[AIMessage]] = None,
        system_prompt: str = "",
    ) -> AIResponse:
        """Ask Alpha once; routing and fallback remain entirely internal."""

        text = (user_input or "").strip()
        if not text:
            return AIResponse(text="I didn't catch that.")

        decision = self.router.route(text)
        log.info(
            "AI route selected=%s category=%s reason=%s confidence=%.2f",
            decision.provider,
            decision.category,
            decision.reason,
            decision.confidence,
        )

        messages = self._messages(text, history)
        attempted = []
        for provider_name in self._provider_order(decision):
            if provider_name in attempted:
                continue
            attempted.append(provider_name)
            provider = self.providers.get(provider_name)
            if not provider or not self._configured.get(provider_name, False):
                log.warning("AI provider unavailable: %s", provider_name)
                continue
            if self._circuit_open(provider_name):
                log.warning("AI provider circuit open: %s", provider_name)
                continue

            cache_key = ResponseCache.key(
                text,
                messages,
                system_prompt,
                getattr(provider, "model", provider_name),
            )
            if self.cache_enabled and self.cache.cacheable(text):
                cached = self.cache.get(cache_key)
                if cached is not None:
                    log.info(
                        "AI cache hit provider=%s model=%s",
                        provider_name,
                        cached.model,
                    )
                    return cached

            started = time.perf_counter()
            try:
                response = provider.ask(messages, system_prompt)
                elapsed_ms = (time.perf_counter() - started) * 1000
                if not response.latency_ms:
                    response.latency_ms = elapsed_ms
                self._mark_success(provider_name)
                if (
                    self.cache_enabled
                    and self.cache.cacheable(text, response)
                ):
                    self.cache.put(cache_key, response)
                log.info(
                    "AI response provider=%s model=%s response_time_ms=%.1f",
                    provider_name,
                    response.model,
                    response.latency_ms,
                )
                return response
            except Exception as exc:
                elapsed_ms = (time.perf_counter() - started) * 1000
                self._mark_failure(provider_name)
                # Log exception type, never prompts, responses, or credentials.
                log.error(
                    "AI provider error provider=%s response_time_ms=%.1f "
                    "error_type=%s",
                    provider_name,
                    elapsed_ms,
                    type(exc).__name__,
                )

        missing = self.missing_keys()
        if missing:
            return AIResponse(
                text=self.setup_message(),
                error="Missing AI provider credentials",
            )
        return AIResponse(
            text=(
                "I'm having trouble answering that right now. "
                "Please try again in a moment."
            ),
            error="All configured AI providers failed",
        )

    async def ask_async(
        self,
        user_input: str,
        history: Optional[Sequence[AIMessage]] = None,
        system_prompt: str = "",
    ) -> AIResponse:
        """Non-blocking manager entry point for event-driven services."""

        return await asyncio.to_thread(
            self.ask,
            user_input,
            history,
            system_prompt,
        )

    def ask_stream(
        self,
        user_input: str,
        history: Optional[Sequence[AIMessage]] = None,
        system_prompt: str = "",
    ) -> Iterator[str]:
        """Yield native provider chunks and fall back before first output."""

        text = (user_input or "").strip()
        if not text:
            yield "I didn't catch that."
            return
        decision = self.router.route(text)
        log.info(
            "AI stream route selected=%s category=%s reason=%s",
            decision.provider,
            decision.category,
            decision.reason,
        )
        messages = self._messages(text, history)
        for provider_name in self._provider_order(decision):
            provider = self.providers.get(provider_name)
            if (
                not provider
                or not self._configured.get(provider_name, False)
                or self._circuit_open(provider_name)
            ):
                continue
            cache_key = ResponseCache.key(
                text,
                messages,
                system_prompt,
                getattr(provider, "model", provider_name),
            )
            if self.cache_enabled and self.cache.cacheable(text):
                cached = self.cache.get(cache_key)
                if cached is not None:
                    log.info(
                        "AI stream cache hit provider=%s model=%s",
                        provider_name,
                        cached.model,
                    )
                    yield cached.text
                    return
            started = time.perf_counter()
            produced = False
            full_text = ""
            try:
                for chunk in provider.stream(messages, system_prompt):
                    if chunk:
                        produced = True
                        full_text += chunk
                        yield chunk
                if not produced:
                    raise RuntimeError("empty provider stream")
                self._mark_success(provider_name)
                cached_response = AIResponse(
                    text=full_text.strip(),
                    model=getattr(provider, "model", provider_name),
                    provider=provider_name,
                    latency_ms=(time.perf_counter() - started) * 1000,
                )
                if (
                    self.cache_enabled
                    and self.cache.cacheable(text, cached_response)
                ):
                    self.cache.put(cache_key, cached_response)
                log.info(
                    "AI stream complete provider=%s model=%s "
                    "response_time_ms=%.1f",
                    provider_name,
                    getattr(provider, "model", ""),
                    (time.perf_counter() - started) * 1000,
                )
                return
            except Exception as exc:
                self._mark_failure(provider_name)
                log.error(
                    "AI stream error provider=%s partial=%s error_type=%s",
                    provider_name,
                    produced,
                    type(exc).__name__,
                )
                if produced:
                    return
        yield self.setup_message() or (
            "I'm having trouble answering that right now. "
            "Please try again in a moment."
        )

    def _messages(
        self,
        text: str,
        history: Optional[Sequence[AIMessage]],
    ) -> list[AIMessage]:
        prior = [
            AIMessage(message.role, message.content, message.timestamp)
            for message in (history or [])
            if message.role in {"user", "assistant"}
            and message.content.strip()
        ]
        # Brain already stores the latest user turn. Avoid sending it twice.
        if (
            prior
            and prior[-1].role == "user"
            and prior[-1].content.strip() == text
        ):
            prior.pop()
        return [*prior, AIMessage(role="user", content=text)]

    def _provider_order(self, decision) -> tuple[str, ...]:
        if decision.category in {
            "programming",
            "creative_writing",
            "complex_reasoning",
        }:
            preferred = (
                decision.provider,
                "openai",
                "gemini",
                "ollama",
            )
        else:
            preferred = (
                decision.provider,
                "openai",
                "gemini",
                "claude",
                "ollama",
            )
        return tuple(dict.fromkeys(preferred))

    def _circuit_open(self, provider_name: str) -> bool:
        if not self.circuit_breaker_enabled:
            return False
        with self._health_lock:
            return self._unhealthy_until.get(provider_name, 0.0) > time.monotonic()

    def _mark_success(self, provider_name: str) -> None:
        with self._health_lock:
            self._failure_count[provider_name] = 0
            self._unhealthy_until[provider_name] = 0.0

    def _mark_failure(self, provider_name: str) -> None:
        if not self.circuit_breaker_enabled:
            return
        with self._health_lock:
            count = self._failure_count.get(provider_name, 0) + 1
            self._failure_count[provider_name] = count
            backoff = min(300.0, 15.0 * (2 ** min(count - 1, 4)))
            self._unhealthy_until[provider_name] = time.monotonic() + backoff
