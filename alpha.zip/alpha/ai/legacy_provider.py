"""Adapters for optional Gemini and local Ollama backends."""

from __future__ import annotations

import os
import threading
from copy import deepcopy
from typing import Iterator, Sequence

from alpha.ai.provider_base import (
    AIMessage,
    AIProvider,
    AIProviderError,
    AIResponse,
)


class LegacyLLMProvider(AIProvider):
    """Expose the existing Gemini/Ollama client through AIProvider."""

    def __init__(self, name: str, config):
        self.name = str(name).casefold()
        self.config = deepcopy(config)
        self.config.provider = self.name
        if self.name == "gemini":
            self.config.model = os.environ.get(
                "GEMINI_MODEL",
                "gemini-flash-latest",
            )
            self.config.base_url = (
                "https://generativelanguage.googleapis.com/v1beta"
            )
        self.model = str(self.config.model)
        self._client = None
        self._lock = threading.Lock()

    def _get_client(self):
        if self._client is None:
            with self._lock:
                if self._client is None:
                    from alpha.core.llm import LLMClient

                    self._client = LLMClient(self.config)
        if self._client.provider != self.name:
            raise AIProviderError(f"{self.name} is not currently available")
        return self._client

    @staticmethod
    def _messages(messages: Sequence[AIMessage], system_prompt: str):
        from alpha.core.llm import Message

        return [
            Message(role="system", content=system_prompt),
            *[
                Message(role=message.role, content=message.content)
                for message in messages
                if message.role in {"user", "assistant"}
                and message.content.strip()
            ],
        ]

    def ask(
        self,
        messages: Sequence[AIMessage],
        system_prompt: str,
    ) -> AIResponse:
        response = self._get_client().chat(
            self._messages(messages, system_prompt)
        )
        if response.error:
            raise AIProviderError(response.error)
        return AIResponse(
            text=response.text,
            model=response.model or self.model,
            provider=self.name,
            tokens_used=response.tokens_used,
            latency_ms=response.latency_ms,
            error=response.error,
            command=response.command,
            commands=list(response.commands or []),
        )

    def stream(
        self,
        messages: Sequence[AIMessage],
        system_prompt: str,
    ) -> Iterator[str]:
        yield from self._get_client().chat_stream(
            self._messages(messages, system_prompt)
        )
