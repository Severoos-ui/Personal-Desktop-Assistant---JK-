"""Small bounded response cache for safe, repeatable AI requests."""

from __future__ import annotations

import hashlib
import json
import threading
import time
from collections import OrderedDict
from dataclasses import asdict
from typing import Sequence

from alpha.ai.provider_base import AIMessage, AIResponse


class ResponseCache:
    """TTL/LRU cache that never writes prompts or responses to disk."""

    _VOLATILE_MARKERS = (
        "time",
        "date",
        "today",
        "tomorrow",
        "weather",
        "news",
        "current",
        "latest",
        "open ",
        "close ",
        "delete ",
        "type ",
        "remind",
        "my ",
        "i ",
    )

    def __init__(self, max_entries: int = 128, ttl_seconds: float = 300.0):
        self.max_entries = max(8, int(max_entries))
        self.ttl_seconds = max(1.0, float(ttl_seconds))
        self._items: OrderedDict[str, tuple[float, AIResponse]] = OrderedDict()
        self._lock = threading.RLock()

    def cacheable(self, user_input: str, response: AIResponse | None = None) -> bool:
        text = " ".join(str(user_input or "").casefold().split())
        if not text or len(text) > 240:
            return False
        if any(marker in text for marker in self._VOLATILE_MARKERS):
            return False
        if response and (response.commands or response.command or response.error):
            return False
        return True

    @staticmethod
    def key(
        user_input: str,
        messages: Sequence[AIMessage],
        system_prompt: str,
        model: str,
    ) -> str:
        context = [
            (message.role, message.content)
            for message in messages[-6:]
            if message.role in {"user", "assistant"}
        ]
        raw = json.dumps(
            {
                "input": user_input,
                "context": context,
                "system": system_prompt,
                "model": model,
            },
            sort_keys=True,
            ensure_ascii=False,
        ).encode("utf-8")
        return hashlib.sha256(raw).hexdigest()

    def get(self, key: str) -> AIResponse | None:
        now = time.monotonic()
        with self._lock:
            item = self._items.get(key)
            if item is None:
                return None
            expires, response = item
            if expires <= now:
                self._items.pop(key, None)
                return None
            self._items.move_to_end(key)
            clone = AIResponse(**asdict(response))
            clone.latency_ms = 0.0
            return clone

    def put(self, key: str, response: AIResponse) -> None:
        with self._lock:
            self._items[key] = (
                time.monotonic() + self.ttl_seconds,
                AIResponse(**asdict(response)),
            )
            self._items.move_to_end(key)
            while len(self._items) > self.max_entries:
                self._items.popitem(last=False)

    def clear(self) -> None:
        with self._lock:
            self._items.clear()
