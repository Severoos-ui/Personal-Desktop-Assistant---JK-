"""Intent-based provider routing independent of provider implementations."""

from __future__ import annotations

from dataclasses import dataclass

from alpha.ai.intent_classifier import (
    IntentClassification,
    IntentClassifier,
)


@dataclass(frozen=True)
class RouteDecision:
    provider: str
    category: str
    reason: str
    confidence: float


class AIRouter:
    """Select a provider while keeping fallback policy in the manager."""

    def __init__(
        self,
        classifier: IntentClassifier | None = None,
        default_provider: str = "openai",
    ):
        self.classifier = classifier or IntentClassifier()
        self.default_provider = (
            default_provider
            if default_provider in {"openai", "claude"}
            else "openai"
        )

    def route(self, user_input: str) -> RouteDecision:
        classification: IntentClassification = self.classifier.classify(
            user_input
        )
        provider = classification.provider or self.default_provider
        if classification.confidence <= 0.50:
            provider = self.default_provider
        return RouteDecision(
            provider=provider,
            category=classification.category,
            reason=classification.reason,
            confidence=classification.confidence,
        )
