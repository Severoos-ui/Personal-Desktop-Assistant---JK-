"""Stable provider contract used by Alpha's AI orchestrator."""

from __future__ import annotations

import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional, Sequence


@dataclass(frozen=True)
class AIMessage:
    """One Alpha-owned conversation turn passed to any provider."""

    role: str
    content: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class AIResponse:
    """Provider-neutral result consumed by Alpha's existing brain."""

    text: str
    model: str = ""
    provider: str = ""
    tokens_used: int = 0
    latency_ms: float = 0.0
    error: Optional[str] = None
    command: Optional[Dict] = None
    commands: List[Dict] = field(default_factory=list)


class AIProviderError(RuntimeError):
    """A provider failed in a way that allows transparent fallback."""


class AIProvider(ABC):
    """Interface every current or future AI provider must implement."""

    name: str

    @abstractmethod
    def ask(
        self,
        messages: Sequence[AIMessage],
        system_prompt: str,
    ) -> AIResponse:
        """Return a response without owning Alpha's conversation memory."""

    def stream(
        self,
        messages: Sequence[AIMessage],
        system_prompt: str,
    ) -> Iterator[str]:
        """Yield visible response chunks.

        Providers without native streaming remain compatible through the
        regular request path.
        """

        response = self.ask(messages, system_prompt)
        if response.text:
            yield response.text


_COMMAND_PATTERN = re.compile(r"\[\[CMD:([^\]]+)\]\]")


def parse_command_directives(text: str) -> tuple[str, List[Dict]]:
    """Extract only the existing allowlisted command-directive syntax."""

    commands: List[Dict] = []
    for match in _COMMAND_PATTERN.finditer(text or ""):
        raw = match.group(1).strip()
        parts = raw.split("|")
        action = parts[0].strip()
        if not action:
            continue
        params: Dict[str, str] = {}
        for part in parts[1:]:
            if "=" not in part:
                continue
            key, value = part.split("=", 1)
            key = key.strip()
            if key:
                params[key] = value.strip()
        commands.append({"action": action, "params": params, "raw": raw})
    clean_text = _COMMAND_PATTERN.sub("", text or "").strip()
    return clean_text, commands
