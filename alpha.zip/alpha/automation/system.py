"""System control: volume, brightness, power, Wi-Fi, processes."""

import os
import subprocess
import platform
import ctypes
from typing import Optional

from alpha.utils.logger import get_logger, log_cmd
from alpha.config.settings import IS_WINDOWS, IS_LINUX, IS_MACOS

log = get_logger("system")


class SystemController:
    """Controls system-level functions: power, volume, brightness."""

    def __init__(self):
        self._pycaw = None
        self._screen_brightness = None
        self._init_backends()

    def _init_backends(self):
        if IS_WINDOWS:
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                from ctypes import POINTER, cast
                from comtypes import CLSCTX_ALL
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                self._volume = cast(interface, POINTER(IAudioEndpointVolume))
                self._pycaw = True
                log.info("pycaw volume control loaded")
            except Exception as e:
                log.info(f"pycaw not available ({e}); using Windows native volume fallback")
                self._pycaw = False
            try:
                import screen_brightness_control as sbc
                self._sbc = sbc
                self._screen_brightness = True
            except Exception:
                self._sbc = None
        elif IS_LINUX:
            try:
                import pulsectl
                self._pulse = pulsectl.Pulse("alpha")
            except Exception:
                self._pulse = None
            try:
                import screen_brightness_control as sbc
                self._sbc = sbc
            except Exception:
                self._sbc = None

    # ---- Power ----

    def shutdown(self, delay_sec: int = 0) -> str:
        try:
            if IS_WINDOWS:
                subprocess.run(["shutdown", "/s", "/t", str(delay_sec)], check=True)
            elif IS_MACOS:
                subprocess.run(["sudo", "shutdown", "-h", "now"], check=True)
            else:
                subprocess.run(["shutdown", "now"], check=True)
            log_cmd(f"Shutdown initiated (delay={delay_sec}s)")
            return "Shutting down." if delay_sec == 0 else f"Shutting down in {delay_sec} seconds."
        except Exception as e:
            return f"Couldn't shutdown: {e}"

    def restart(self, delay_sec: int = 0) -> str:
        try:
            if IS_WINDOWS:
                subprocess.run(["shutdown", "/r", "/t", str(delay_sec)], check=True)
            elif IS_MACOS:
                subprocess.run(["sudo", "shutdown", "-r", "now"], check=True)
            else:
                subprocess.run(["reboot"], check=True)
            log_cmd(f"Restart initiated")
            return "Restarting."
        except Exception as e:
            return f"Couldn't restart: {e}"

    def sleep(self) -> str:
        try:
            if IS_WINDOWS:
                ctypes.windll.powrprof.SetSuspendState(0, 0, 0)
            elif IS_MACOS:
                subprocess.run(["pmset", "sleepnow"], check=True)
            else:
                subprocess.run(["systemctl", "suspend"], check=True)
            log_cmd("Sleep")
            return "Putting PC to sleep."
        except Exception as e:
            return f"Couldn't sleep: {e}"

    def lock(self) -> str:
        try:
            if IS_WINDOWS:
                ctypes.windll.user32.LockWorkStation()
            elif IS_MACOS:
                subprocess.run(["pmset", "displaysleepnow"], check=True)
            else:
                subprocess.run(["xdg-screensaver", "lock"], check=True)
            return "Locked."
        except Exception as e:
            return f"Couldn't lock: {e}"

    def hibernate(self) -> str:
        try:
            if IS_WINDOWS:
                subprocess.run(["shutdown", "/h"], check=True)
                return "Hibernating."
            return "Hibernate not supported on this platform."
        except Exception as e:
            return f"Couldn't hibernate: {e}"

    # ---- Volume ----

    def set_volume(self, percent: int) -> str:
        percent = max(0, min(100, int(percent)))
        try:
            if IS_WINDOWS and self._pycaw:
                self._volume.SetMasterVolumeLevelScalar(percent / 100.0, None)
            elif IS_WINDOWS:
                # Native Windows fallback via PowerShell (no extra software needed)
                ps_cmd = (
                    "$wsh = New-Object -ComObject WScript.Shell;"
                    f"# set volume to {percent}%"
                )
                # Use SendKeys to press volumeup ~50 times then volumedown/up to reach target
                # More reliable: use nircmd-style SendMessage via pyautogui, or Key presses
                import pyautogui
                # Press volumedown 50 times to mute completely, then volumeup to target
                for _ in range(50):
                    pyautogui.press("volumedown")
                for _ in range(percent // 2):
                    pyautogui.press("volumeup")
            elif IS_LINUX and self._pulse:
                for sink in self._pulse.sink_list():
                    self._pulse.volume_set_all_chans(sink, percent / 100.0)
            else:
                self._volume_amixer(percent)
            log_cmd(f"Volume set to {percent}%")
            return f"Volume set to {percent} percent."
        except Exception as e:
            return f"Couldn't set volume: {e}"

    def mute(self) -> str:
        try:
            if IS_WINDOWS and self._pycaw:
                self._volume.SetMute(1, None)
            elif IS_WINDOWS:
                import pyautogui
                pyautogui.press("volumemute")
            elif IS_LINUX and self._pulse:
                for sink in self._pulse.sink_list():
                    self._pulse.mute(sink, True)
            else:
                subprocess.run(["amixer", "-q", "set", "Master", "mute"], check=False)
            log_cmd("Volume muted")
            return "Muted."
        except Exception as e:
            return f"Couldn't mute: {e}"

    def unmute(self) -> str:
        try:
            if IS_WINDOWS and self._pycaw:
                self._volume.SetMute(0, None)
            elif IS_WINDOWS:
                import pyautogui
                pyautogui.press("volumemute")
            elif IS_LINUX and self._pulse:
                for sink in self._pulse.sink_list():
                    self._pulse.mute(sink, False)
            else:
                subprocess.run(["amixer", "-q", "set", "Master", "unmute"], check=False)
            log_cmd("Volume unmuted")
            return "Unmuted."
        except Exception as e:
            return f"Couldn't unmute: {e}"

    def volume_up(self, step: int = 10) -> str:
        try:
            if IS_WINDOWS:
                import pyautogui
                presses = max(1, step // 2)
                for _ in range(presses):
                    pyautogui.press("volumeup")
                log_cmd(f"Volume up {step}%")
                return f"Volume up {step} percent."
        except Exception:
            pass
        cur = self.get_volume()
        return self.set_volume(min(100, cur + step))

    def volume_down(self, step: int = 10) -> str:
        try:
            if IS_WINDOWS:
                import pyautogui
                presses = max(1, step // 2)
                for _ in range(presses):
                    pyautogui.press("volumedown")
                log_cmd(f"Volume down {step}%")
                return f"Volume down {step} percent."
        except Exception:
            pass
        cur = self.get_volume()
        return self.set_volume(max(0, cur - step))

    def get_volume(self) -> int:
        try:
            if IS_WINDOWS and self._pycaw:
                return int(self._volume.GetMasterVolumeLevelScalar() * 100)
            if IS_LINUX and self._pulse:
                for sink in self._pulse.sink_list():
                    return int(sink.volume.value_flat * 100)
        except Exception:
            pass
        return 50

    def _volume_amixer(self, percent: int):
        subprocess.run(["amixer", "-q", "set", "Master", f"{percent}%"], check=False)

    # ---- Brightness ----

    def set_brightness(self, percent: int) -> str:
        percent = max(0, min(100, int(percent)))
        try:
            if self._sbc:
                self._sbc.set_brightness(percent)
            elif IS_LINUX:
                # try direct sysfs
                subprocess.run(["xbacklight", "-set", str(percent)], check=False,
                               capture_output=True)
            else:
                return "Brightness control requires screen_brightness_control library."
            log_cmd(f"Brightness set to {percent}%")
            return f"Brightness set to {percent} percent."
        except Exception as e:
            return f"Couldn't set brightness: {e}"

    def brightness_up(self, step: int = 10) -> str:
        cur = self.get_brightness()
        return self.set_brightness(min(100, cur + step))

    def brightness_down(self, step: int = 10) -> str:
        cur = self.get_brightness()
        return self.set_brightness(max(0, cur - step))

    def get_brightness(self) -> int:
        try:
            if self._sbc:
                b = self._sbc.get_brightness()
                return b[0] if isinstance(b, list) else int(b)
        except Exception:
            pass
        return 70

    # ---- Wi-Fi & Network ----

    def wifi_list(self) -> list:
        try:
            if IS_WINDOWS:
                r = subprocess.run(["netsh", "wlan", "show", "networks"], capture_output=True, text=True)
                return r.stdout.splitlines()
        except Exception:
            pass
        return []

    def wifi_connect(self, ssid: str) -> str:
        try:
            if IS_WINDOWS:
                subprocess.run(["netsh", "wlan", "connect", f"name={ssid}"], check=True)
            return f"Connecting to {ssid}."
        except Exception as e:
            return f"Couldn't connect: {e}"

    def toggle_bluetooth(self, enable: bool = True) -> str:
        # Platform-specific; best effort
        action = "on" if enable else "off"
        try:
            if IS_WINDOWS:
                # Uses bluetooth service
                subprocess.run(["sc", "config", "bthserv", "start=", "auto"], capture_output=True)
            return f"Bluetooth turned {action}."
        except Exception as e:
            return f"Couldn't toggle Bluetooth: {e}"

    # ---- System Info ----

    def battery_status(self) -> dict:
        info = {"percent": None, "plugged": False, "remaining": None}
        try:
            import psutil
            batt = psutil.sensors_battery()
            if batt:
                info["percent"] = batt.percent
                info["plugged"] = batt.power_plugged
                info["remaining"] = batt.secsleft if batt.secsleft > 0 else None
        except Exception:
            pass
        return info

    def system_info(self) -> dict:
        import psutil
        try:
            return {
                "platform": platform.platform(),
                "cpu_percent": psutil.cpu_percent(interval=0.2),
                "ram_percent": psutil.virtual_memory().percent,
                "ram_total_gb": round(psutil.virtual_memory().total / (1024 ** 3), 1),
                "ram_available_gb": round(psutil.virtual_memory().available / (1024 ** 3), 1),
                "battery": self.battery_status(),
                "disk_free_gb": round(psutil.disk_usage("/").free / (1024 ** 3), 1),
            }
        except Exception:
            return {"platform": platform.platform()}
