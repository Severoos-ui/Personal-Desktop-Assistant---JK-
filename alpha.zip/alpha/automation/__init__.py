from alpha.automation.desktop import DesktopController
from alpha.automation.browser import BrowserController
from alpha.automation.system import SystemController
from alpha.automation.register_commands import register_desktop_commands
