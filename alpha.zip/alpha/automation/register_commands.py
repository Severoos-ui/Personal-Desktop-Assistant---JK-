"""Register all desktop/browser/system commands with the command registry."""

import re
from typing import Optional
from alpha.commands.registry import CommandRegistry, CommandDef, ParamDef, ParamType
from alpha.automation.desktop import DesktopController
from alpha.automation.browser import BrowserController
from alpha.automation.system import SystemController


# Known app/folder/website keywords used by the smart open dispatcher
KNOWN_FOLDERS = {
    "downloads", "documents", "desktop", "pictures", "music", "videos",
    "home", "download", "my documents", "my downloads",
}
KNOWN_WEBSITE_TRIGGERS = (".com", ".org", ".net", ".io", ".dev", ".ai", "http://", "https://", "www.")


def _smart_open(target: str, desktop: DesktopController, browser: BrowserController) -> str:
    """
    Smart dispatcher for 'open X' commands:
    - If X is a URL/domain -> open website
    - If X is a known folder -> open folder
    - If X is a known app alias -> open app
    - If X contains 'folder'/'directory' keywords -> open as folder
    - If X contains 'website'/'url'/'site' -> open as website
    - Otherwise: try as app, fallback to folder
    """
    t = target.strip().strip(".!?,")
    tl = t.lower()
    # URL detection
    if any(kw in tl for kw in KNOWN_WEBSITE_TRIGGERS) or " " not in tl and "." in tl.split("/")[0]:
        return browser.open_url(t)
    # Website keyword
    if any(w in tl for w in ("website", "url", "site")):
        # strip keyword
        for kw in ("website", "url", "site"):
            tl = tl.replace(kw, "").strip()
        if tl:
            return browser.open_url(tl)
    # Folder keyword
    if "folder" in tl or "directory" in tl:
        for kw in ("folder", "directory", "the "):
            tl = tl.replace(kw, "").strip()
        return desktop.open_folder(tl or "~")
    # Known special folders
    if tl in KNOWN_FOLDERS:
        if tl in ("downloads", "download", "my downloads"):
            return desktop.open_downloads()
        if tl in ("documents", "my documents"):
            return desktop.open_documents()
        if tl in ("desktop",):
            return desktop.open_desktop()
        if tl in ("home",):
            return desktop.open_folder("~")
        if tl in ("pictures", "music", "videos"):
            from pathlib import Path
            return desktop.open_folder(str(Path.home() / tl.capitalize()))
    # Try as app
    return desktop.open_app(t)


def register_desktop_commands(reg: CommandRegistry,
                              desktop: DesktopController,
                              browser: BrowserController,
                              system: SystemController) -> None:
    """Register all Phase 1 desktop commands."""

    # -------- Compound browser/media actions --------
    reg.register(CommandDef(
        name="open_browser_play_youtube_music",
        handler=lambda browser_name, query: browser.play_youtube_music(
            query,
            browser_name=browser_name,
        ),
        description="open a browser and play music on YouTube",
        category="media",
        triggers=[
            "open brave and play music on youtube",
            "open chrome and play music on youtube",
            "open edge and play music on youtube",
        ],
        params=[
            ParamDef(
                name="browser_name",
                type=ParamType.APP,
                required=True,
            ),
            ParamDef(
                name="query",
                type=ParamType.QUERY,
                required=True,
            ),
        ],
        patterns=[
            r"(?:open|launch|start)\s+(?:the\s+)?"
            r"(?P<browser_name>brave|brave\s+browser|chrome|google\s+chrome|"
            r"edge|microsoft\s+edge|firefox)"
            r"(?:\s+browser)?\s+(?:and\s+then|and|then)\s+"
            r"(?:play|start)\s+"
            r"(?P<query>.+?(?:music|songs?|playlist|mix))\s+"
            r"(?:on|in|within|with\s+in)\s+(?:youtube|you\s+tube)\s*$"
        ],
        examples=[
            "Alpha, open Brave and play some music within YouTube",
            "Alpha, open Chrome and play a focus music mix on YouTube",
        ],
    ))

    reg.register(CommandDef(
        name="play_youtube_music",
        handler=lambda query: browser.play_youtube_music(query),
        description="play music on YouTube",
        category="media",
        triggers=[
            "play some music on youtube",
            "play music within youtube",
            "start music on youtube",
        ],
        params=[
            ParamDef(
                name="query",
                type=ParamType.QUERY,
                required=True,
            )
        ],
        patterns=[
            r"(?:play|start)\s+"
            r"(?P<query>.+?(?:music|songs?|playlist|mix))\s+"
            r"(?:on|in|within|with\s+in)\s+(?:youtube|you\s+tube)\s*$"
        ],
        examples=["Alpha, play some music on YouTube"],
    ))

    # -------- Application/File/Web OPEN (smart dispatcher) --------
    reg.register(CommandDef(
        name="open_smart",
        handler=lambda target: _smart_open(target, desktop, browser),
        description="open an app, folder, or website",
        category="general",
        triggers=["open", "launch", "start", "run", "go to"],
        params=[ParamDef(name="target", type=ParamType.STRING, required=True)],
        examples=[
            "Alpha open Brave", "Alpha open Downloads", "Alpha open github.com",
            "Alpha launch VS Code", "Alpha open folder Projects", "Alpha start calculator"
        ],
        patterns=[
            r"(?:open|launch|start|run|go\s+to)\s+(?:the\s+|app\s+|website\s+|folder\s+|directory\s+)?(?P<target>.+?)(?:\s+(?:please|now|for me))?\s*$"
        ],
    ))

    reg.register(CommandDef(
        name="close_app",
        handler=lambda app: desktop.close_app(app),
        description="close an application",
        category="apps",
        triggers=["close", "exit", "quit", "kill"],
        params=[ParamDef(name="app", type=ParamType.APP, required=True)],
        examples=["Alpha close Brave", "Alpha exit notepad"],
        patterns=[
            r"(?:close|exit|quit|kill)\s+(?:the\s+)?(?P<app>.+?)"
            r"(?:\s+(?:app|application|program|window))?"
            r"(?:\s+(?:please|now|for\s+me))?\s*$"
        ],
    ))

    # -------- Foreground app control --------
    # These commands intentionally act on the application the user has
    # focused.  This keeps them useful across editors, browsers, media apps,
    # and ordinary Windows dialogs without granting arbitrary shell access.
    reg.register(CommandDef(
        name="type_text",
        handler=lambda text: desktop.type_text(text),
        description="type dictated text in the focused application",
        category="apps",
        triggers=["type", "write", "enter text"],
        params=[ParamDef(name="text", type=ParamType.STRING, required=True)],
        patterns=[
            r"(?:type|write|enter\s+text)\s+(?P<text>.+?)\s*$",
        ],
        examples=["Alpha, type meeting notes"],
    ))

    reg.register(CommandDef(
        name="press_key",
        handler=lambda key: desktop.press_key(key),
        description="press a keyboard key in the focused application",
        category="apps",
        triggers=["press enter", "press escape", "press tab", "press key"],
        params=[ParamDef(name="key", type=ParamType.STRING, required=True)],
        patterns=[
            r"(?:press|hit)\s+(?:the\s+)?(?P<key>"
            r"enter|return|escape|esc|tab|space(?:\s+bar)?|"
            r"back\s*space|delete(?:\s+key)?|home|end|"
            r"page\s+up|page\s+down|up|down|left|right)\s*$",
        ],
        examples=["Alpha, press Enter"],
    ))

    reg.register(CommandDef(
        name="keyboard_shortcut",
        handler=lambda action: desktop.keyboard_shortcut(action),
        description="use a common keyboard shortcut",
        category="apps",
        triggers=[
            "copy", "paste", "cut", "undo", "redo", "save", "select all",
            "find", "new tab", "close tab", "reopen tab", "refresh", "print",
        ],
        params=[ParamDef(name="action", type=ParamType.STRING, required=True)],
        patterns=[
            r"(?:do\s+|please\s+)?(?P<action>copy|paste|cut|undo|redo|"
            r"save|select\s+all|find|new\s+tab|close\s+tab|"
            r"reopen\s+tab|refresh|print)\s*$",
        ],
        examples=["Alpha, save", "Alpha, close tab"],
    ))

    reg.register(CommandDef(
        name="scroll_screen",
        handler=lambda direction, amount=5: desktop.scroll_screen(
            direction,
            _spoken_amount(amount, default=5),
        ),
        description="scroll the focused application",
        category="apps",
        triggers=["scroll up", "scroll down"],
        params=[
            ParamDef(name="direction", type=ParamType.STRING, required=True),
            ParamDef(name="amount", type=ParamType.STRING, default="5"),
        ],
        patterns=[
            r"scroll\s+(?P<direction>up|down)"
            r"(?:\s+(?:by\s+)?(?P<amount>\d+|one|two|three|four|five|"
            r"six|seven|eight|nine|ten))?\s*$",
        ],
        examples=["Alpha, scroll down five"],
    ))

    reg.register(CommandDef(
        name="click_at",
        handler=lambda x, y: desktop.click_at(int(x), int(y)),
        description="click screen coordinates",
        category="apps",
        triggers=["click at"],
        params=[
            ParamDef(name="x", type=ParamType.INT, required=True),
            ParamDef(name="y", type=ParamType.INT, required=True),
        ],
        patterns=[
            r"click(?:\s+at)?\s+(?P<x>\d+)(?:\s*,\s*|\s+)"
            r"(?P<y>\d+)\s*$",
        ],
        examples=["Alpha, click at 500 300"],
    ))

    reg.register(CommandDef(
        name="double_click_at",
        handler=lambda x, y: desktop.click_at(int(x), int(y), double=True),
        description="double-click screen coordinates",
        category="apps",
        triggers=["double click at"],
        params=[
            ParamDef(name="x", type=ParamType.INT, required=True),
            ParamDef(name="y", type=ParamType.INT, required=True),
        ],
        patterns=[
            r"double\s+click(?:\s+at)?\s+(?P<x>\d+)"
            r"(?:\s*,\s*|\s+)(?P<y>\d+)\s*$",
        ],
        examples=["Alpha, double click at 500 300"],
    ))

    reg.register(CommandDef(
        name="switch_app",
        handler=lambda: desktop.switch_app(),
        description="switch to the next application",
        category="apps",
        triggers=["switch app", "next app", "next window", "alt tab"],
        patterns=[
            r"(?:switch\s+(?:app|application|window)|"
            r"next\s+(?:app|application|window)|alt\s+tab)\s*$",
        ],
        examples=["Alpha, switch app"],
    ))

    reg.register(CommandDef(
        name="focus_app",
        handler=lambda app: desktop.focus_app(app),
        description="bring a running application to the foreground",
        category="apps",
        triggers=["switch to", "focus", "bring up"],
        params=[ParamDef(name="app", type=ParamType.APP, required=True)],
        patterns=[
            r"(?:switch\s+to|focus|bring\s+up)\s+(?:the\s+)?"
            r"(?P<app>.+?)(?:\s+(?:app|application|window))?\s*$",
        ],
        examples=["Alpha, switch to Brave"],
    ))

    reg.register(CommandDef(
        name="window_action",
        handler=lambda action: desktop.window_action(action),
        description="change the state of the focused window",
        category="apps",
        triggers=["minimize window", "maximize window", "restore window"],
        params=[ParamDef(name="action", type=ParamType.STRING, required=True)],
        patterns=[
            r"(?P<action>minimize|maximize|restore)"
            r"(?:\s+(?:this|the|current))?"
            r"(?:\s+(?:window|app|application))?\s*$",
        ],
        examples=["Alpha, maximize this window"],
    ))

    # -------- File & Folder (specific actions) --------
    reg.register(CommandDef(
        name="open_folder",
        handler=lambda path: desktop.open_folder(path),
        description="open a folder by path",
        category="files",
        triggers=["open folder", "open directory", "go to folder"],
        params=[ParamDef(name="path", type=ParamType.PATH, required=True)],
        examples=["Alpha open folder Projects"],
        patterns=[r"(?:open|go\s+to)\s+(?:the\s+)?(?:folder|directory)\s+(?P<path>.+?)\s*$"],
    ))

    reg.register(CommandDef(
        name="open_downloads",
        handler=lambda: desktop.open_downloads(),
        description="open Downloads folder",
        category="files",
        triggers=["open downloads", "show downloads", "go to downloads", "my downloads"],
        examples=["Alpha open Downloads"],
    ))

    reg.register(CommandDef(
        name="open_documents",
        handler=lambda: desktop.open_documents(),
        description="open Documents folder",
        category="files",
        triggers=["open documents", "my documents"],
    ))

    reg.register(CommandDef(
        name="open_desktop",
        handler=lambda: desktop.open_desktop(),
        description="open Desktop folder",
        category="files",
        triggers=["open desktop", "show desktop"],
    ))

    reg.register(CommandDef(
        name="create_folder",
        handler=lambda name, parent=None: desktop.create_folder(name, parent),
        description="create a new folder",
        category="files",
        triggers=["create folder", "make folder", "new folder", "create directory"],
        params=[ParamDef(name="name", type=ParamType.STRING, required=True)],
        examples=["Alpha create folder Projects", "Alpha make folder AI Projects"],
        patterns=[r"(?:create|make|new)\s+(?:folder|directory)\s+(?:called\s+|named\s+)?(?P<name>.+?)\s*$"],
    ))

    reg.register(CommandDef(
        name="create_text_file",
        handler=lambda name="untitled": desktop.create_text_file(name),
        description="create a new text file",
        category="files",
        triggers=["create text file", "new text file", "create note", "make text file"],
        params=[ParamDef(name="name", type=ParamType.STRING)],
        examples=["Alpha create text file notes", "Alpha new text file"],
        patterns=[r"(?:create|make|new)\s+(?:text\s+)?file\s*(?:called\s+|named\s+)?(?P<name>.*)?\s*$"],
    ))

    # -------- Power --------
    reg.register(CommandDef(
        name="shutdown",
        handler=lambda: system.shutdown(),
        description="shutdown the computer",
        category="power",
        triggers=["shutdown", "shut down", "turn off pc", "power off"],
        dangerous=True, requires_confirmation=True,
        examples=["Alpha shutdown computer", "Alpha turn off PC"],
    ))

    reg.register(CommandDef(
        name="restart",
        handler=lambda: system.restart(),
        description="restart the computer",
        category="power",
        triggers=["restart", "reboot"],
        dangerous=True, requires_confirmation=True,
        examples=["Alpha restart", "Alpha reboot"],
    ))

    reg.register(CommandDef(
        name="sleep",
        handler=lambda: system.sleep(),
        description="put PC to sleep",
        category="power",
        triggers=["sleep", "go to sleep", "put to sleep", "sleep pc"],
        dangerous=True, requires_confirmation=True,
        examples=["Alpha sleep PC"],
    ))

    reg.register(CommandDef(
        name="lock",
        handler=lambda: system.lock(),
        description="lock the PC",
        category="power",
        triggers=["lock", "lock pc", "lock computer", "lock screen"],
        examples=["Alpha lock PC"],
    ))

    reg.register(CommandDef(
        name="hibernate",
        handler=lambda: system.hibernate(),
        description="hibernate the computer",
        category="power",
        triggers=["hibernate"],
        dangerous=True, requires_confirmation=True,
    ))

    # -------- Volume --------
    reg.register(CommandDef(
        name="mute",
        handler=lambda: system.mute(),
        description="mute volume",
        category="media",
        triggers=["mute", "mute volume", "sound off", "silence"],
        examples=["Alpha mute volume"],
    ))

    reg.register(CommandDef(
        name="unmute",
        handler=lambda: system.unmute(),
        description="unmute volume",
        category="media",
        triggers=["unmute", "sound on", "unmute volume"],
    ))

    reg.register(CommandDef(
        name="volume_up",
        handler=lambda step=10: system.volume_up(int(step) if step else 10),
        description="increase volume",
        category="media",
        triggers=["volume up", "increase volume", "turn up volume", "louder"],
        patterns=[
            r"(?:volume\s+up|turn\s+up|louder|increase\s+volume)(?:\s+(?:by\s+)?(?P<step>\d+)(?:\s*percent|%)?)?\s*$"
        ],
        params=[ParamDef(name="step", type=ParamType.INT)],
    ))

    reg.register(CommandDef(
        name="volume_down",
        handler=lambda step=10: system.volume_down(int(step) if step else 10),
        description="decrease volume",
        category="media",
        triggers=["volume down", "decrease volume", "turn down volume", "quieter", "softer"],
        patterns=[
            r"(?:volume\s+down|turn\s+down|quieter|softer|decrease\s+volume)(?:\s+(?:by\s+)?(?P<step>\d+)(?:\s*percent|%)?)?\s*$"
        ],
        params=[ParamDef(name="step", type=ParamType.INT)],
    ))

    reg.register(CommandDef(
        name="set_volume",
        handler=lambda percent: system.set_volume(int(percent)),
        description="set volume to specific level",
        category="media",
        triggers=["set volume to"],
        patterns=[r"(?:set\s+volume|volume)\s+(?:to\s+)?(?P<percent>\d+)(?:\s*percent|%|$)"],
        params=[ParamDef(name="percent", type=ParamType.INT, required=True)],
    ))

    # -------- Brightness --------
    reg.register(CommandDef(
        name="brightness_up",
        handler=lambda step=10: system.brightness_up(int(step) if step else 10),
        description="increase brightness",
        category="media",
        triggers=["brightness up", "increase brightness", "brighter"],
        patterns=[r"(?:brightness\s+up|increase\s+brightness|brighter)(?:\s+(?:by\s+)?(?P<step>\d+))?\s*$"],
        params=[ParamDef(name="step", type=ParamType.INT)],
    ))

    reg.register(CommandDef(
        name="brightness_down",
        handler=lambda step=10: system.brightness_down(int(step) if step else 10),
        description="decrease brightness",
        category="media",
        triggers=["brightness down", "decrease brightness", "dimmer"],
        patterns=[r"(?:brightness\s+down|decrease\s+brightness|dimmer)(?:\s+(?:by\s+)?(?P<step>\d+))?\s*$"],
        params=[ParamDef(name="step", type=ParamType.INT)],
    ))

    reg.register(CommandDef(
        name="set_brightness",
        handler=lambda percent: system.set_brightness(int(percent)),
        description="set brightness",
        category="media",
        triggers=["set brightness to"],
        patterns=[r"(?:set\s+)?brightness\s+(?:to\s+)?(?P<percent>\d+)(?:\s*percent|%|$)"],
        params=[ParamDef(name="percent", type=ParamType.INT, required=True)],
        examples=["Alpha increase brightness", "Alpha set brightness to 80"],
    ))

    # -------- Screenshot --------
    reg.register(CommandDef(
        name="screenshot",
        handler=lambda: desktop.take_screenshot(),
        description="take a screenshot",
        category="utility",
        triggers=["screenshot", "take screenshot", "screen capture", "capture screen"],
        examples=["Alpha take screenshot"],
    ))

    # -------- Browser / Web --------
    reg.register(CommandDef(
        name="open_url",
        handler=lambda url: browser.open_url(url),
        description="open a website URL",
        category="web",
        triggers=["open website", "go to website", "navigate to", "open url"],
        params=[ParamDef(name="url", type=ParamType.WEBSITE, required=True)],
        patterns=[r"(?:open|go\s+to|navigate\s+to)\s+(?:website\s+|url\s+)?(?P<url>(?:https?://)?[\w\-\.]+\.\w{2,}[\w/\-?=&%.#]*)\s*$"],
    ))

    reg.register(CommandDef(
        name="open_site",
        handler=lambda site: browser.open_site(site),
        description="open a popular website",
        category="web",
        triggers=["open youtube", "open github", "open twitter", "open instagram",
                  "open facebook", "open reddit", "open netflix", "open spotify",
                  "open maps", "open gmail", "open amazon", "open linkedin"],
        params=[ParamDef(name="site", type=ParamType.STRING, required=True)],
    ))

    reg.register(CommandDef(
        name="search_google",
        handler=lambda query: browser.search_google(query),
        description="search Google",
        category="web",
        triggers=["search google for", "google", "search for"],
        params=[ParamDef(name="query", type=ParamType.QUERY, required=True)],
        patterns=[
            r"(?:search\s+)?(?:google(?:\s+for)?|search(?:\s+for)?)\s+(?P<query>.+?)\s*$"
        ],
        examples=["Alpha search Google for AI", "Alpha search for best laptops"],
    ))

    reg.register(CommandDef(
        name="search_youtube",
        handler=lambda query: browser.search_youtube(query),
        description="search YouTube",
        category="web",
        triggers=["search youtube for", "youtube search", "find on youtube",
                  "play on youtube", "watch", "youtube"],
        params=[ParamDef(name="query", type=ParamType.QUERY, required=True)],
        patterns=[
            r"(?:search\s+)?(?:youtube(?:\s+for)?|find\s+on\s+youtube)\s+(?P<query>.+?)\s*$",
            r"play\s+(?P<query>.+?)\s*(?:on\s+youtube)?\s*$",
        ],
        examples=["Alpha search YouTube for trip to Thailand"],
    ))

    reg.register(CommandDef(
        name="play_music",
        handler=lambda query="": browser.play_music(query),
        description="play music",
        category="media",
        triggers=["play music", "play relaxing music", "play some music",
                  "play focus music", "start music"],
        params=[ParamDef(name="query", type=ParamType.QUERY)],
        patterns=[r"play\s+(?:(?P<query>.+?)\s+)?music\s*$"],
        examples=["Alpha play relaxing music"],
    ))

    reg.register(CommandDef(
        name="search_wikipedia",
        handler=lambda query: browser.search_wikipedia(query),
        description="search Wikipedia",
        category="web",
        triggers=["search wikipedia for", "wikipedia", "look up on wikipedia"],
        params=[ParamDef(name="query", type=ParamType.QUERY, required=True)],
    ))

    reg.register(CommandDef(
        name="search_maps",
        handler=lambda query: browser.search_maps(query),
        description="search Maps",
        category="web",
        triggers=["maps", "navigate to", "where is", "directions to", "show on map"],
        params=[ParamDef(name="query", type=ParamType.QUERY, required=True)],
    ))

    # -------- Utility --------
    reg.register(CommandDef(
        name="calculate",
        handler=lambda: desktop.open_app("calculator"),
        description="open calculator",
        category="utility",
        triggers=["calculator", "open calculator", "calc", "open calc"],
        examples=["Alpha open calculator"],
    ))

    reg.register(CommandDef(
        name="notepad",
        handler=lambda: desktop.open_app("notepad"),
        description="open notepad",
        category="utility",
        triggers=["notepad", "open notepad", "open text editor"],
        examples=["Alpha open Notepad"],
    ))

    reg.register(CommandDef(
        name="task_manager",
        handler=lambda: desktop.open_app("task manager"),
        description="open task manager",
        category="utility",
        triggers=["task manager", "open task manager", "show tasks"],
    ))
    reg.register(CommandDef(
        name="settings",
        handler=lambda: desktop.open_app("settings"),
        description="open Settings",
        category="utility",
        triggers=["settings", "open settings", "show settings"],
    ))

    reg.register(CommandDef(
        name="terminal",
        handler=lambda: desktop.open_app("terminal"),
        description="open terminal",
        category="utility",
        triggers=["terminal", "open terminal", "command prompt", "cmd", "open cmd"],
    ))

    # -------- Conversational/Utility responses --------
    reg.register(CommandDef(
        name="hello",
        handler=lambda: "Hello! How can I help you?",
        description="greet Alpha",
        category="chat",
        triggers=["hello", "hi", "hey", "hey there", "good morning", "good afternoon",
                  "good evening", "yo", "what's up", "sup"],
        examples=["Alpha, hello"],
    ))

    reg.register(CommandDef(
        name="thanks",
        handler=lambda: "You're welcome! Anytime.",
        description="respond to thanks",
        category="chat",
        triggers=["thanks", "thank you", "appreciate it", "thx"],
    ))

    reg.register(CommandDef(
        name="goodbye",
        handler=lambda: "Goodbye! Talk to you soon.",
        description="say goodbye",
        category="chat",
        triggers=["goodbye", "bye", "see you", "see ya", "that's all", "exit conversation"],
    ))

    reg.register(CommandDef(
        name="battery",
        handler=lambda: _battery_status(system),
        description="check battery status",
        category="system",
        triggers=["battery", "battery status", "how much battery", "battery level"],
    ))

    reg.register(CommandDef(
        name="system_info",
        handler=lambda: _system_info_str(system),
        description="show system info",
        category="system",
        triggers=["system info", "system status", "computer status", "how's the pc",
                  "cpu usage", "ram usage"],
    ))


def register_screen_commands(reg: CommandRegistry, screen_vision) -> None:
    """Register Iris-style, explicitly voice-triggered screen awareness."""

    reg.register(CommandDef(
        name="analyze_screen",
        handler=lambda: screen_vision.analyze(),
        description="describe and read the current screen",
        category="vision",
        triggers=[
            "what is on my screen",
            "what's on my screen",
            "describe my screen",
            "read my screen",
            "summarize my screen",
            "analyze my screen",
            "can you see my screen",
        ],
        patterns=[
            r"(?:what(?:'s|\s+is)\s+(?:currently\s+)?on\s+"
            r"(?:my|the)\s+screen|"
            r"(?:describe|read|summari[sz]e|analy[sz]e)\s+"
            r"(?:what(?:'s|\s+is)\s+on\s+)?(?:my|the)\s+screen|"
            r"can\s+you\s+see\s+(?:my|the)\s+screen)\s*$"
        ],
        examples=[
            "Alpha, what is on my screen?",
            "Alpha, read my screen",
            "Alpha, summarize my screen",
        ],
    ))


def _battery_status(system: SystemController) -> str:
    b = system.battery_status()
    if b["percent"] is None:
        return "Battery information not available."
    pct = b["percent"]
    if b["plugged"]:
        return f"Battery is at {pct}% and charging."
    return f"Battery is at {pct} percent."


def _system_info_str(system: SystemController) -> str:
    info = system.system_info()
    parts = []
    if info.get("cpu_percent") is not None:
        parts.append(f"CPU at {info['cpu_percent']}%")
    if info.get("ram_percent") is not None:
        parts.append(f"RAM at {info['ram_percent']}%")
    b = info.get("battery", {})
    if b and b.get("percent") is not None:
        parts.append(f"Battery {b['percent']}%")
    if not parts:
        return "System is running."
    return "System status: " + ", ".join(parts) + "."


def _spoken_amount(value, default: int = 5) -> int:
    """Convert a small spoken number or digit string to an integer."""

    words = {
        "one": 1,
        "two": 2,
        "three": 3,
        "four": 4,
        "five": 5,
        "six": 6,
        "seven": 7,
        "eight": 8,
        "nine": 9,
        "ten": 10,
    }
    normalized = str(value or "").casefold().strip()
    if normalized in words:
        return words[normalized]
    try:
        return int(normalized)
    except (TypeError, ValueError):
        return default
