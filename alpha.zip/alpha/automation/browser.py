"""Browser automation: searches, URL opening, optional Playwright/Selenium."""

import os
import webbrowser
import urllib.parse
import urllib.request
import subprocess
import re
import shutil
from typing import Optional, Dict
from pathlib import Path

from alpha.utils.logger import get_logger, log_cmd
from alpha.config.settings import IS_WINDOWS, IS_LINUX, IS_MACOS

log = get_logger("browser")

# Search engine URL templates
SEARCH_ENGINES: Dict[str, str] = {
    "google": "https://www.google.com/search?q={query}",
    "youtube": "https://www.youtube.com/results?search_query={query}",
    "bing": "https://www.bing.com/search?q={query}",
    "duckduckgo": "https://duckduckgo.com/?q={query}",
    "wikipedia": "https://en.wikipedia.org/wiki/Special:Search?search={query}",
    "github": "https://github.com/search?q={query}",
    "amazon": "https://www.amazon.com/s?k={query}",
    "maps": "https://www.google.com/maps/search/{query}",
    "images": "https://www.google.com/images?q={query}",
    "news": "https://news.google.com/search?q={query}",
    "weather": "https://www.google.com/search?q=weather+{query}",
    "stackoverflow": "https://stackoverflow.com/search?q={query}",
}

SITE_SHORTENERS: Dict[str, str] = {
    "youtube": "https://youtube.com",
    "yt": "https://youtube.com",
    "google": "https://google.com",
    "gmail": "https://mail.google.com",
    "github": "https://github.com",
    "twitter": "https://twitter.com",
    "x": "https://x.com",
    "facebook": "https://facebook.com",
    "instagram": "https://instagram.com",
    "reddit": "https://reddit.com",
    "netflix": "https://netflix.com",
    "spotify": "https://open.spotify.com",
    "amazon": "https://amazon.com",
    "linkedin": "https://linkedin.com",
    "maps": "https://maps.google.com",
}


class BrowserController:
    """Cross-platform browser control using webbrowser module + OS-native launch."""

    def __init__(self, default_browser: str = "system"):
        self.default_browser = default_browser
        self._driver = None  # playwright/selenium when available

    def open_url(self, url: str, browser_name: Optional[str] = None) -> str:
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        try:
            selected_browser = (
                browser_name
                or (
                    self.default_browser
                    if self.default_browser not in {"", "default", "system"}
                    else None
                )
            )
            if selected_browser and self._open_in_named_browser(
                url,
                selected_browser,
            ):
                log_cmd(f"Opened URL in {selected_browser}: {url}")
                return f"Opening {url} in {selected_browser}."
            webbrowser.open(url, new=2)
            log_cmd(f"Opened URL: {url}")
            return f"Opening {url}."
        except Exception as e:
            return f"Couldn't open URL: {e}"

    def _open_in_named_browser(self, url: str, browser_name: str) -> bool:
        """Open a URL in a requested installed browser without shell strings."""

        name = " ".join(browser_name.casefold().strip().split())
        name = {
            "google chrome": "chrome",
            "microsoft edge": "edge",
            "brave browser": "brave",
        }.get(name, name)

        if IS_WINDOWS:
            local_app_data = os.environ.get("LOCALAPPDATA", "")
            program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
            program_files_x86 = os.environ.get(
                "ProgramFiles(x86)",
                r"C:\Program Files (x86)",
            )
            candidates = {
                "brave": [
                    os.path.join(
                        program_files,
                        "BraveSoftware",
                        "Brave-Browser",
                        "Application",
                        "brave.exe",
                    ),
                    os.path.join(
                        program_files_x86,
                        "BraveSoftware",
                        "Brave-Browser",
                        "Application",
                        "brave.exe",
                    ),
                    os.path.join(
                        local_app_data,
                        "BraveSoftware",
                        "Brave-Browser",
                        "Application",
                        "brave.exe",
                    ),
                    "brave.exe",
                ],
                "chrome": [
                    os.path.join(
                        program_files,
                        "Google",
                        "Chrome",
                        "Application",
                        "chrome.exe",
                    ),
                    os.path.join(
                        program_files_x86,
                        "Google",
                        "Chrome",
                        "Application",
                        "chrome.exe",
                    ),
                    os.path.join(
                        local_app_data,
                        "Google",
                        "Chrome",
                        "Application",
                        "chrome.exe",
                    ),
                    "chrome.exe",
                ],
                "edge": [
                    os.path.join(
                        program_files_x86,
                        "Microsoft",
                        "Edge",
                        "Application",
                        "msedge.exe",
                    ),
                    os.path.join(
                        program_files,
                        "Microsoft",
                        "Edge",
                        "Application",
                        "msedge.exe",
                    ),
                    "msedge.exe",
                ],
                "firefox": [
                    os.path.join(
                        program_files,
                        "Mozilla Firefox",
                        "firefox.exe",
                    ),
                    "firefox.exe",
                ],
            }.get(name, [f"{name}.exe"])

            for candidate in candidates:
                executable = (
                    candidate
                    if os.path.isfile(candidate)
                    else shutil.which(candidate)
                )
                if executable:
                    subprocess.Popen(
                        [executable, url],
                        creationflags=getattr(
                            subprocess,
                            "CREATE_NO_WINDOW",
                            0,
                        ),
                    )
                    return True
            return False

        if IS_MACOS:
            app_name = {
                "brave": "Brave Browser",
                "chrome": "Google Chrome",
                "edge": "Microsoft Edge",
                "firefox": "Firefox",
            }.get(name, browser_name)
            subprocess.Popen(["open", "-a", app_name, url])
            return True

        executable = {
            "brave": "brave-browser",
            "chrome": "google-chrome",
            "edge": "microsoft-edge",
            "firefox": "firefox",
        }.get(name, name)
        resolved = shutil.which(executable)
        if resolved:
            subprocess.Popen([resolved, url])
            return True
        return False

    def open_site(self, site: str) -> str:
        name = site.lower().strip()
        if name in SITE_SHORTENERS:
            return self.open_url(SITE_SHORTENERS[name])
        if "." in name:
            return self.open_url(f"https://{name}")
        return self.open_url(f"https://{name}.com")

    def search(self, query: str, engine: str = "google") -> str:
        eng = engine.lower()
        if eng in SEARCH_ENGINES:
            url = SEARCH_ENGINES[eng].format(query=urllib.parse.quote_plus(query))
        else:
            url = SEARCH_ENGINES["google"].format(query=urllib.parse.quote_plus(query))
        log_cmd(f"Search {engine} for: {query}")
        return self.open_url(url)

    def search_google(self, query: str) -> str:
        return self.search(query, "google")

    def search_youtube(self, query: str) -> str:
        return self.search(query, "youtube")

    def search_maps(self, query: str) -> str:
        return self.search(query, "maps")

    def search_wikipedia(self, query: str) -> str:
        return self.search(query, "wikipedia")

    @staticmethod
    def _normalise_music_query(query: str) -> str:
        text = " ".join((query or "").strip().strip(".!?,").split())
        text = re.sub(
            r"\s+(?:on|in|within|with\s+in)\s+(?:youtube|you\s+tube)\s*$",
            "",
            text,
            flags=re.IGNORECASE,
        ).strip()
        if text.casefold() in {
            "",
            "music",
            "some",
            "some music",
            "any music",
            "a song",
            "something",
        }:
            return "relaxing music mix"
        if not re.search(r"\bmusic\b|\bsong\b|\bmix\b", text, re.IGNORECASE):
            text = f"{text} music"
        return text

    @staticmethod
    def _first_youtube_video_id(search_url: str) -> Optional[str]:
        """Best-effort first-result lookup; callers fall back to search."""

        try:
            request = urllib.request.Request(
                search_url,
                headers={
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 Chrome/124 Safari/537.36"
                    )
                },
            )
            with urllib.request.urlopen(request, timeout=8) as response:
                page = response.read().decode("utf-8", errors="ignore")
            match = re.search(r'"videoId":"([A-Za-z0-9_-]{11})"', page)
            return match.group(1) if match else None
        except Exception as exc:
            log.debug(f"YouTube first-result lookup failed: {exc}")
            return None

    def play_youtube_music(
        self,
        query: str = "",
        browser_name: Optional[str] = None,
    ) -> str:
        """Open the first YouTube music result, with a search-page fallback."""

        music_query = self._normalise_music_query(query)
        encoded = urllib.parse.quote_plus(music_query)
        search_url = (
            "https://www.youtube.com/results?search_query="
            f"{encoded}"
        )
        video_id = self._first_youtube_video_id(search_url)
        target_url = (
            f"https://www.youtube.com/watch?v={video_id}&autoplay=1"
            if video_id
            else search_url
        )
        result = self.open_url(target_url, browser_name=browser_name)
        if result.startswith("Couldn't"):
            return result
        browser_text = f" in {browser_name}" if browser_name else ""
        if video_id:
            return f"Playing {music_query} on YouTube{browser_text}."
        return (
            f"Opening YouTube{browser_text} with results for "
            f"{music_query}."
        )

    def play_music(self, query: str = "") -> str:
        """Play a music result on YouTube in the configured browser."""

        return self.play_youtube_music(query)

    def play_video(self, query: str) -> str:
        return self.search_youtube(query)

    def open_new_tab(self):
        try:
            webbrowser.open_new_tab("https://www.google.com")
        except Exception:
            pass

    # ---- Optional Playwright for advanced automation ----

    def enable_playwright(self) -> bool:
        try:
            from playwright.sync_api import sync_playwright
            self._pw = sync_playwright().start()
            self._driver = self._pw.chromium.launch(headless=False)
            log.info("Playwright automation enabled")
            return True
        except Exception as e:
            log.warning(f"Playwright unavailable: {e}")
            return False

    def close(self):
        if self._driver:
            try:
                self._driver.close()
                self._pw.stop()
            except Exception:
                pass
