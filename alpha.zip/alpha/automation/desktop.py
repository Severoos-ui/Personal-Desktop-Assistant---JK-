"""Cross-platform desktop automation: app launching, files, windows, input."""

import os
import re
import sys
import subprocess
import shutil
import platform
import webbrowser
import time
from pathlib import Path
from typing import Optional, List, Dict

from alpha.utils.logger import get_logger, log_cmd
from alpha.config.settings import IS_WINDOWS, IS_LINUX, IS_MACOS

log = get_logger("desktop")


# Common app aliases mapped to launch commands per platform
APP_ALIASES: Dict[str, Dict[str, str]] = {
    "brave": {
        "windows": r"C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe",
        "linux": "brave-browser",
        "darwin": "open -a Brave\\ Browser",
    },
    "chrome": {
        "windows": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        "linux": "google-chrome",
        "darwin": "open -a Google\\ Chrome",
    },
    "firefox": {"windows": "firefox.exe", "linux": "firefox", "darwin": "open -a Firefox"},
    "edge": {"windows": "msedge.exe", "linux": "microsoft-edge", "darwin": "open -a Microsoft\\ Edge"},
    "vscode": {
        "windows": r"C:\Users\%USERNAME%\AppData\Local\Programs\Microsoft VS Code\Code.exe",
        "linux": "code",
        "darwin": "open -a Visual\\ Studio\\ Code",
    },
    "code": {
        "windows": r"C:\Users\%USERNAME%\AppData\Local\Programs\Microsoft VS Code\Code.exe",
        "linux": "code", "darwin": "open -a Visual\\ Studio\\ Code",
    },
    "notepad": {"windows": "notepad.exe", "linux": "gedit", "darwin": "open -a TextEdit"},
    "calculator": {"windows": "calc.exe", "linux": "gnome-calculator", "darwin": "open -a Calculator"},
    "calc": {"windows": "calc.exe", "linux": "gnome-calculator", "darwin": "open -a Calculator"},
    "terminal": {"windows": "cmd.exe", "linux": "gnome-terminal", "darwin": "open -a Terminal"},
    "cmd": {"windows": "cmd.exe", "linux": "gnome-terminal", "darwin": "open -a Terminal"},
    "powershell": {"windows": "powershell.exe", "linux": "pwsh", "darwin": "open -a Terminal"},
    "explorer": {"windows": "explorer.exe", "linux": "xdg-open", "darwin": "open"},
    "files": {"windows": "explorer.exe", "linux": "xdg-open .", "darwin": "open ."},
    "spotify": {"windows": "spotify.exe", "linux": "spotify", "darwin": "open -a Spotify"},
    "discord": {"windows": "discord.exe", "linux": "discord", "darwin": "open -a Discord"},
    "steam": {"windows": "steam://", "linux": "steam", "darwin": "open -a Steam"},
    "settings": {"windows": "ms-settings:", "linux": "gnome-control-center", "darwin": "open -a System\\ Settings"},
    "task manager": {"windows": "taskmgr.exe", "linux": "gnome-system-monitor", "darwin": "open -a Activity\\ Monitor"},
    "paint": {"windows": "mspaint.exe", "linux": "pinta", "darwin": "open -a Paintbrush"},
    "camera": {
        "windows": "microsoft.windows.camera:",
        "linux": "cheese",
        "darwin": "open -a Photo\\ Booth",
    },
    "word": {"windows": "winword.exe", "linux": "libreoffice --writer", "darwin": "open -a Microsoft\\ Word"},
    "excel": {"windows": "excel.exe", "linux": "libreoffice --calc", "darwin": "open -a Microsoft\\ Excel"},
    "powerpoint": {"windows": "powerpnt.exe", "linux": "libreoffice --impress", "darwin": "open -a Microsoft\\ PowerPoint"},
}

APP_NAME_CORRECTIONS = {
    "braves": "brave",
    "brave browser": "brave",
    "google chrome": "chrome",
    "visual studio code": "vscode",
    "vs code": "vscode",
    "note pad": "notepad",
    "calculators": "calculator",
    "cameras": "camera",
    "browser": "brave",
}

WINDOWS_PROCESS_ALIASES = {
    "brave": ("brave",),
    "chrome": ("chrome",),
    "firefox": ("firefox",),
    "edge": ("msedge",),
    "vscode": ("code",),
    "code": ("code",),
    "notepad": ("notepad",),
    "calculator": ("calculatorapp", "calculator", "calc"),
    "calc": ("calculatorapp", "calculator", "calc"),
    "camera": ("windowscamera", "camera"),
    "settings": ("systemsettings",),
    "spotify": ("spotify",),
    "discord": ("discord",),
    "steam": ("steam",),
    "task manager": ("taskmgr",),
    "paint": ("mspaint",),
    "word": ("winword",),
    "excel": ("excel",),
    "powerpoint": ("powerpnt",),
    "terminal": ("windowsterminal", "wt"),
    "cmd": ("cmd",),
    "powershell": ("powershell", "pwsh"),
}

# Alpha may close ordinary user applications, but it must never terminate the
# Windows shell, sign-in/security components, or its own background listener.
WINDOWS_PROTECTED_PROCESSES = {
    "system",
    "registry",
    "smss",
    "csrss",
    "wininit",
    "services",
    "lsass",
    "svchost",
    "winlogon",
    "dwm",
    "fontdrvhost",
    "sihost",
    "explorer",
    "shellexperiencehost",
    "startmenuexperiencehost",
    "searchhost",
    "pythonw",
}

WINDOWS_PROTECTED_APP_REQUESTS = {
    "alpha",
    "windows",
    "system",
    "desktop",
    "computer",
    "laptop",
    "file explorer",
    "explorer",
}


class DesktopController:
    """Cross-platform desktop automation with graceful fallbacks."""

    def __init__(self):
        self._pyautogui = None
        self._init_pyautogui()

    def _init_pyautogui(self):
        try:
            import pyautogui
            pyautogui.FAILSAFE = True
            pyautogui.PAUSE = 0.05
            self._pyautogui = pyautogui
        except ImportError:
            log.info("pyautogui not installed - mouse/keyboard automation limited")
        except Exception as e:
            log.warning(f"pyautogui init failed: {e}")

    # ---- Applications ----

    def open_app(self, app_name: str) -> str:
        name = self._normalise_app_name(app_name)
        plat = "windows" if IS_WINDOWS else ("darwin" if IS_MACOS else "linux")
        # Exact alias lookup
        if name in APP_ALIASES:
            cmd_str = APP_ALIASES[name].get(plat, name)
            return self._launch(cmd_str, name)
        # Resolve other installed applications by executable or Start-menu name.
        return self._launch(name, name)

    @staticmethod
    def _normalise_app_name(app_name: str) -> str:
        name = " ".join(str(app_name).lower().strip().strip(".!?,").split())
        name = re.sub(
            r"\s+(?:app|application|program|window)\s*$",
            "",
            name,
        ).strip()
        corrected = APP_NAME_CORRECTIONS.get(name)
        if corrected:
            return corrected
        # Whisper often adds a plural "s" to short application names.
        if name.endswith("s") and name[:-1] in APP_ALIASES:
            return name[:-1]
        return name

    def _launch(self, cmd_str: str, label: str) -> str:
        try:
            if IS_WINDOWS:
                expanded = os.path.expandvars(cmd_str)
                if os.path.exists(expanded):
                    subprocess.Popen([expanded])
                elif (
                    "://" in cmd_str
                    or (
                        ":" in cmd_str
                        and not (
                            len(cmd_str) >= 3
                            and cmd_str[1] == ":"
                            and cmd_str[2] in ("\\", "/")
                        )
                    )
                ):
                    os.startfile(cmd_str)
                else:
                    executable = shutil.which(expanded)
                    if executable:
                        subprocess.Popen([executable])
                    else:
                        app_id = self._find_windows_start_app(label)
                        if not app_id:
                            raise FileNotFoundError(
                                f'Windows could not find an installed app named "{label}"'
                            )
                        os.startfile(f"shell:AppsFolder\\{app_id}")
            elif IS_MACOS:
                subprocess.Popen(cmd_str, shell=True)
            else:
                # Linux: prefer xdg-open for URIs, else direct exec
                if "://" in cmd_str:
                    subprocess.Popen(["xdg-open", cmd_str])
                else:
                    subprocess.Popen(cmd_str, shell=True)
            log_cmd(f"Opened app: {label}")
            return f"Opening {label}."
        except Exception as e:
            log.error(f"Failed to open {label}: {e}")
            return f"Sorry, I couldn't open {label}: {e}"

    def _find_windows_start_app(self, app_name: str) -> Optional[str]:
        """Resolve an installed Windows application without shell injection."""

        if not IS_WINDOWS or not app_name:
            return None
        script = (
            "$needle=$env:ALPHA_APP_QUERY;"
            "$apps=Get-StartApps;"
            "$m=$apps|Where-Object {$_.Name -ieq $needle}|Select-Object -First 1;"
            "if(-not $m){$m=$apps|Where-Object "
            "{$_.Name.StartsWith($needle,[System.StringComparison]::"
            "InvariantCultureIgnoreCase)}|Select-Object -First 1};"
            "if(-not $m){$m=$apps|Where-Object "
            "{$_.Name.IndexOf($needle,[System.StringComparison]::"
            "InvariantCultureIgnoreCase) -ge 0}|Select-Object -First 1};"
            "if($m){$m.AppID}"
        )
        env = os.environ.copy()
        env["ALPHA_APP_QUERY"] = app_name
        try:
            result = subprocess.run(
                [
                    "powershell.exe",
                    "-NoLogo",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    script,
                ],
                capture_output=True,
                text=True,
                timeout=8,
                env=env,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            if result.returncode == 0:
                app_id = result.stdout.strip().splitlines()
                return app_id[0].strip() if app_id else None
        except Exception as exc:
            log.debug(f"Start-menu app lookup failed for {app_name}: {exc}")
        return None

    def close_app(self, app_name: str) -> str:
        name = self._normalise_app_name(app_name)
        try:
            if IS_WINDOWS:
                if name in WINDOWS_PROTECTED_APP_REQUESTS:
                    return (
                        f"I won't close {name} because it is part of Windows "
                        "or Alpha's background listener."
                    )

                candidates = set(WINDOWS_PROCESS_ALIASES.get(name, ()))
                compact_name = re.sub(r"[^a-z0-9]+", "", name)
                if compact_name:
                    candidates.add(compact_name)

                script = (
                    "$query=$env:ALPHA_APP_QUERY;"
                    "$candidates=@($env:ALPHA_PROCESS_CANDIDATES -split ';'|"
                    "Where-Object {$_});"
                    "$blocked=@($env:ALPHA_PROTECTED_PROCESSES -split ';'|"
                    "Where-Object {$_});"
                    "$session=(Get-Process -Id $PID).SessionId;"
                    "$matches=@(Get-Process -ErrorAction SilentlyContinue|"
                    "Where-Object {"
                    "$pn=$_.ProcessName.ToLowerInvariant();"
                    "$title=$_.MainWindowTitle;"
                    "$_.SessionId -eq $session -and "
                    "$blocked -notcontains $pn -and "
                    "(($candidates -contains $pn) -or "
                    "($title -and $title.IndexOf($query,"
                    "[System.StringComparison]::OrdinalIgnoreCase) -ge 0))"
                    "});"
                    "if(-not $matches){exit 3};"
                    "$closed=0;$pending=0;"
                    "foreach($proc in ($matches|Sort-Object Id -Unique)){"
                    "try{"
                    "if($proc.MainWindowHandle -ne 0){"
                    "$requested=$proc.CloseMainWindow();"
                    "if($requested){"
                    "$null=$proc.WaitForExit(1200);"
                    "$closed++;"
                    "if(Get-Process -Id $proc.Id -ErrorAction SilentlyContinue){"
                    "$pending++"
                    "};"
                    "continue"
                    "}"
                    "};"
                    "$live=Get-Process -Id $proc.Id -ErrorAction SilentlyContinue;"
                    "if($live){Stop-Process -Id $proc.Id -Force -ErrorAction Stop};"
                    "$closed++"
                    "}catch{}"
                    "};"
                    "if($closed -gt 0){"
                    "Write-Output ($closed.ToString()+'|'+$pending.ToString());"
                    "exit 0"
                    "};exit 3"
                )
                env = os.environ.copy()
                env["ALPHA_APP_QUERY"] = name
                env["ALPHA_PROCESS_CANDIDATES"] = ";".join(sorted(candidates))
                env["ALPHA_PROTECTED_PROCESSES"] = ";".join(
                    sorted(WINDOWS_PROTECTED_PROCESSES)
                )
                result = subprocess.run(
                    [
                        "powershell.exe",
                        "-NoLogo",
                        "-NoProfile",
                        "-NonInteractive",
                        "-Command",
                        script,
                    ],
                    capture_output=True,
                    text=True,
                    timeout=10,
                    env=env,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                if result.returncode != 0:
                    return f"I couldn't find a running app named {name}."
                result_parts = result.stdout.strip().split("|", 1)
                if (
                    len(result_parts) == 2
                    and result_parts[1].strip().isdigit()
                    and int(result_parts[1].strip()) > 0
                ):
                    log_cmd(f"Close requested for app with pending window: {name}")
                    return (
                        f"I asked {name} to close. It may be waiting for you "
                        "to save your work."
                    )
            elif IS_MACOS:
                result = subprocess.run(
                    ["pkill", "-x", name],
                    capture_output=True,
                    timeout=5,
                )
                if result.returncode != 0:
                    return f"I couldn't find a running app named {name}."
            else:
                result = subprocess.run(
                    ["pkill", "-f", name],
                    capture_output=True,
                    timeout=5,
                )
                if result.returncode != 0:
                    return f"I couldn't find a running app named {name}."
            log_cmd(f"Closed app: {name}")
            return f"Closed {name}."
        except Exception as e:
            return f"Couldn't close {name}: {e}"

    # ---- Files & Folders ----

    def open_folder(self, path: str) -> str:
        p = self._resolve_path(path)
        try:
            if IS_WINDOWS:
                os.startfile(str(p))
            elif IS_MACOS:
                subprocess.Popen(["open", str(p)])
            else:
                subprocess.Popen(["xdg-open", str(p)])
            return f"Opening {p.name}."
        except Exception as e:
            return f"Couldn't open folder: {e}"

    def create_folder(self, name: str, parent: Optional[str] = None) -> str:
        base = Path(parent) if parent else Path.home()
        p = base / name
        try:
            p.mkdir(parents=True, exist_ok=True)
            log_cmd(f"Created folder: {p}")
            return f"Created folder {name}."
        except Exception as e:
            return f"Couldn't create folder: {e}"

    def create_text_file(self, name: str = "untitled.txt", parent: Optional[str] = None,
                         content: str = "") -> str:
        base = Path(parent) if parent else Path.home() / "Documents"
        base.mkdir(parents=True, exist_ok=True)
        p = base / (name if name.endswith(".txt") else f"{name}.txt")
        try:
            p.write_text(content, encoding="utf-8")
            log_cmd(f"Created file: {p}")
            # Open it
            if IS_WINDOWS:
                os.startfile(str(p))
            elif IS_MACOS:
                subprocess.Popen(["open", str(p)])
            else:
                subprocess.Popen(["xdg-open", str(p)])
            return f"Created and opened {p.name}."
        except Exception as e:
            return f"Couldn't create file: {e}"

    def open_downloads(self) -> str:
        downloads = Path.home() / "Downloads"
        return self.open_folder(str(downloads))

    def open_documents(self) -> str:
        return self.open_folder(str(Path.home() / "Documents"))

    def open_desktop(self) -> str:
        return self.open_folder(str(Path.home() / "Desktop"))

    # ---- Screenshot ----

    def capture_screen_image(self, path: str | Path) -> Path:
        """Capture the current desktop to a caller-managed PNG path."""

        if self._pyautogui is None:
            raise RuntimeError(
                "Screen capture requires pyautogui to be installed"
            )
        output_path = Path(path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        screenshot = self._pyautogui.screenshot()
        screenshot.save(str(output_path))
        return output_path

    def take_screenshot(self, save_dir: Optional[str] = None) -> str:
        if self._pyautogui is None:
            return "Screenshot requires pyautogui to be installed."
        try:
            save_dir = Path(save_dir) if save_dir else Path.home() / "Pictures" / "Screenshots"
            save_dir.mkdir(parents=True, exist_ok=True)
            ts = time.strftime("%Y%m%d_%H%M%S")
            path = save_dir / f"screenshot_{ts}.png"
            self.capture_screen_image(path)
            log_cmd(f"Screenshot saved to {path}")
            return f"Screenshot saved to Pictures."
        except Exception as e:
            return f"Couldn't take screenshot: {e}"

    # ---- Input ----

    def type_text(self, text: str) -> str:
        """Type ordinary dictated text into the currently focused app."""

        if self._pyautogui is None:
            return "Keyboard control is unavailable."
        content = str(text).strip()
        if not content:
            return "Tell me what you want typed."
        if re.search(
            r"\b(?:password|passcode|security\s+code|api\s+key|"
            r"authentication\s+token|secret)\b",
            content,
            flags=re.IGNORECASE,
        ):
            return (
                "I won't type secrets from voice because spoken commands "
                "may appear in local logs."
            )
        try:
            # Give a newly opened application a moment to receive focus.
            time.sleep(0.35)
            self._pyautogui.write(content, interval=0.015)
            return "Typed it."
        except Exception as exc:
            return f"I couldn't type that: {exc}"

    def press_key(self, key: str) -> str:
        if self._pyautogui is None:
            return "Keyboard control is unavailable."
        normalized = " ".join(str(key).casefold().strip().split())
        normalized = {
            "return": "enter",
            "escape": "esc",
            "space bar": "space",
            "page up": "pgup",
            "page down": "pgdn",
            "delete key": "delete",
            "back space": "backspace",
        }.get(normalized, normalized.replace(" ", ""))
        allowed = set(getattr(self._pyautogui, "KEYBOARD_KEYS", ()))
        if allowed and normalized not in allowed:
            return f"I don't recognize the {key} key."
        try:
            self._pyautogui.press(normalized)
            return f"Pressed {key}."
        except Exception as exc:
            return f"I couldn't press {key}: {exc}"

    def hotkey(self, *keys) -> str:
        if self._pyautogui is None:
            return "Keyboard control is unavailable."
        try:
            self._pyautogui.hotkey(*keys)
            return "Done."
        except Exception as exc:
            return f"I couldn't use that shortcut: {exc}"

    def keyboard_shortcut(self, action: str) -> str:
        normalized = " ".join(str(action).casefold().strip().split())
        shortcuts = {
            "copy": ("ctrl", "c"),
            "paste": ("ctrl", "v"),
            "cut": ("ctrl", "x"),
            "undo": ("ctrl", "z"),
            "redo": ("ctrl", "y"),
            "save": ("ctrl", "s"),
            "select all": ("ctrl", "a"),
            "find": ("ctrl", "f"),
            "new tab": ("ctrl", "t"),
            "close tab": ("ctrl", "w"),
            "reopen tab": ("ctrl", "shift", "t"),
            "refresh": ("ctrl", "r"),
            "print": ("ctrl", "p"),
        }
        keys = shortcuts.get(normalized)
        if not keys:
            return f"I don't know the {action} shortcut."
        result = self.hotkey(*keys)
        return f"{action.capitalize()}." if result == "Done." else result

    def scroll_screen(self, direction: str, amount: int = 5) -> str:
        if self._pyautogui is None:
            return "Mouse control is unavailable."
        normalized = str(direction).casefold().strip()
        if normalized not in {"up", "down"}:
            return "Say scroll up or scroll down."
        steps = max(1, min(50, int(amount or 5)))
        try:
            self._pyautogui.scroll(
                steps if normalized == "up" else -steps
            )
            return f"Scrolled {normalized}."
        except Exception as exc:
            return f"I couldn't scroll: {exc}"

    def click_at(
        self,
        x: int,
        y: int,
        double: bool = False,
    ) -> str:
        if self._pyautogui is None:
            return "Mouse control is unavailable."
        try:
            width, height = self._pyautogui.size()
            x_pos = int(x)
            y_pos = int(y)
            if not (0 <= x_pos < width and 0 <= y_pos < height):
                return "Those coordinates are outside the screen."
            self._pyautogui.click(
                x=x_pos,
                y=y_pos,
                clicks=2 if double else 1,
                interval=0.12,
            )
            return (
                f"{'Double-clicked' if double else 'Clicked'} "
                f"at {x_pos}, {y_pos}."
            )
        except Exception as exc:
            return f"I couldn't click there: {exc}"

    def switch_app(self) -> str:
        result = self.hotkey("alt", "tab")
        return "Switched applications." if result == "Done." else result

    def focus_app(self, app_name: str) -> str:
        """Bring a running application window to the foreground."""

        name = self._normalise_app_name(app_name)
        if not IS_WINDOWS:
            return (
                "Focusing an application by name is currently available "
                "on Windows."
            )
        script = (
            "$query=$env:ALPHA_APP_QUERY;"
            "$compact=($query -replace '[^a-zA-Z0-9]','');"
            "$p=Get-Process -ErrorAction SilentlyContinue|Where-Object {"
            "$_.MainWindowHandle -ne 0 -and "
            "(($_.ProcessName -replace '[^a-zA-Z0-9]','') -ieq $compact "
            "-or $_.MainWindowTitle.IndexOf($query,"
            "[System.StringComparison]::OrdinalIgnoreCase) -ge 0)"
            "}|Select-Object -First 1;"
            "if(-not $p){exit 3};"
            "$shell=New-Object -ComObject WScript.Shell;"
            "if($shell.AppActivate($p.Id)){exit 0};exit 4"
        )
        env = os.environ.copy()
        env["ALPHA_APP_QUERY"] = name
        try:
            result = subprocess.run(
                [
                    "powershell.exe",
                    "-NoLogo",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    script,
                ],
                capture_output=True,
                text=True,
                timeout=8,
                env=env,
                creationflags=getattr(
                    subprocess,
                    "CREATE_NO_WINDOW",
                    0,
                ),
            )
            if result.returncode == 0:
                return f"Switched to {name}."
            return f"I couldn't find a running window named {name}."
        except Exception as exc:
            return f"I couldn't switch to {name}: {exc}"

    def window_action(self, action: str) -> str:
        """Minimize, maximize, or restore the foreground application."""

        normalized = str(action).casefold().strip()
        show_codes = {
            "minimize": 6,
            "maximize": 3,
            "restore": 9,
        }
        if normalized not in show_codes:
            return "Say minimize, maximize, or restore the window."
        if not IS_WINDOWS:
            return "Window-state control is currently available on Windows."
        try:
            import ctypes

            user32 = ctypes.windll.user32
            foreground = user32.GetForegroundWindow()
            if not foreground:
                return "I couldn't find the active window."
            user32.ShowWindow(foreground, show_codes[normalized])
            return f"{normalized.capitalize()}d the current window."
        except Exception as exc:
            return f"I couldn't {normalized} the window: {exc}"

    # ---- Helpers ----

    def _resolve_path(self, path: str) -> Path:
        p = Path(os.path.expandvars(os.path.expanduser(path)))
        if not p.is_absolute():
            # Check common locations
            candidates = [Path.cwd() / p, Path.home() / p, Path.home() / "Documents" / p,
                          Path.home() / "Downloads" / p, Path.home() / "Desktop" / p]
            for c in candidates:
                if c.exists():
                    return c
        return p

    def search_files(self, query: str, root: Optional[str] = None, limit: int = 20) -> List[str]:
        root_dir = Path(root) if root else Path.home()
        results = []
        q = query.lower()
        try:
            for dirpath, dirnames, filenames in os.walk(root_dir):
                # Skip hidden and system dirs for speed
                dirnames[:] = [d for d in dirnames if not d.startswith(".") and d not in
                               ("node_modules", "__pycache__", ".venv", "venv", ".git")]
                for f in filenames:
                    if q in f.lower():
                        results.append(str(Path(dirpath) / f))
                        if len(results) >= limit:
                            return results
        except Exception as e:
            log.error(f"Search error: {e}")
        return results
